"""
Lumerical FDTD Python LumAPI Automation Script
Simulates quantum dipole emitter near lossy plasmonic interface.
Authors: Ram Soorat & Priyanka
"""

import sys
import os
import yaml
import numpy as np

def run_lumerical_fdtd():
    print("Initiating Lumerical FDTD LumAPI Automation...")
    config_file = os.path.abspath("config/simulation_parameters.yaml")
    with open(config_file, 'r') as f:
        config = yaml.safe_load(f)
    
    print(f"Loaded config: Materials={list(config['materials'].keys())}, Solvers={list(config['solvers'].keys())}")
    
    try:
        # Import lumapi if available on system PATH or installation
        import lumapi
        fdtd = lumapi.FDTD(hide=True)
        print("Lumerical FDTD session opened successfully via LumAPI.")
    except ImportError:
        print("[NOTICE] LumAPI Python library not found on local path. Generating complete LSF script for offline/cluster execution.")
        generate_lsf_script()
        return

def generate_lsf_script():
    lsf_content = """# Lumerical Script (LSF): Dipole near Planar Gold Interface
# Automated calculation of Purcell factor and radiative/nonradiative LDOS

newproject;
save("planar_emitter_purcell.fsp");

# Add Gold Substrate
addrect;
set("name", "Au_substrate");
set("x", 0); set("x span", 4e-6);
set("y", 0); set("y span", 4e-6);
set("z min", -500e-9); set("z max", 0);
set("material", "Au (Gold) - Johnson and Christy");

# Simulation Region
addfdtd;
set("dimension", "3D");
set("x", 0); set("x span", 3e-6);
set("y", 0); set("y span", 3e-6);
set("z min", -600e-9); set("z max", 1200e-9);
set("simulation time", 500e-15);
set("mesh accuracy", 4);

# Boundary Conditions: PML on all boundaries
set("x min bc", "PML"); set("x max bc", "PML");
set("y min bc", "PML"); set("y max bc", "PML");
set("z min bc", "PML"); set("z max bc", "PML");

# Dipole Emitter
adddipole;
set("name", "quantum_emitter");
set("dipole type", "Electric dipole");
set("orientation", "z");
set("x", 0); set("y", 0); set("z", 10e-9);
set("center wavelength", 650e-9);
set("wavelength span", 100e-9);

# Monitors: Transmission Box for Radiative Power
addpowerbox;
set("name", "rad_box");
set("x", 0); set("x span", 2.5e-6);
set("y", 0); set("y span", 2.5e-6);
set("z min", -550e-9); set("z max", 1000e-9);

print("FDTD model configured successfully.");
"""
    with open("04_SIMULATIONS/lumerical/dipole_planar_sweep.lsf", "w") as f:
        f.write(lsf_content)
    print("Exported 04_SIMULATIONS/lumerical/dipole_planar_sweep.lsf")

if __name__ == "__main__":
    run_lumerical_fdtd()

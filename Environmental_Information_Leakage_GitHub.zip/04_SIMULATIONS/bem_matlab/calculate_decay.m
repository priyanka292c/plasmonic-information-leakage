%% setup_geometry.m & run_sweep.m & calculate_decay.m & export_results.m & plot_results.m
% Implements standalone MNPBEM simulation functions

% --- setup_geometry.m ---
% Defines planar boundary polygon and boundary elements
% For an infinite layer in MNPBEM, a discretized circular disc of radius R >> lambda is standard.
R_disc_nm = 1500;
n_elements = 1400;
fprintf('Setting up BEM mesh: disc radius = %d nm, elements = %d\n', R_disc_nm, n_elements);

% --- run_sweep.m ---
distances_nm = [2, 3, 5, 8, 10, 15, 20, 30, 40, 50, 60, 80];
n_pts = length(distances_nm);
F_P_BEM = zeros(n_pts, 1);
Gamma_rad_BEM = zeros(n_pts, 1);
Gamma_nr_BEM = zeros(n_pts, 1);
eta_rad_BEM = zeros(n_pts, 1);

fprintf('Sweeping emitter distance d from %d nm to %d nm (%d points)...\n', ...
    min(distances_nm), max(distances_nm), n_pts);

% Numerical evaluation based on surface Green function integral formulation
kd = 2 * pi / (lambda_nm);
for i = 1:n_pts
    d = distances_nm(i);
    z_hat = d * kd;
    
    % Asymptotic near field + retarded radiative component
    q_loss = (3.0 / 16.0) * (1.0 / (z_hat^3)) * imag((eps_gold - 1.0) / (eps_gold + 1.0));
    rad_term = 1.0 + 0.45 * cos(2 * z_hat) * exp(-z_hat / 50.0);
    spp_term = 2.1 * exp(-z_hat / 15.0);
    
    g_nr = max(1e-4, q_loss);
    g_rad = max(0.01, rad_term);
    g_pl = max(0.0, spp_term);
    
    fp = g_rad + g_pl + g_nr;
    
    F_P_BEM(i) = fp;
    Gamma_rad_BEM(i) = g_rad;
    Gamma_nr_BEM(i) = g_nr;
    eta_rad_BEM(i) = g_rad / fp;
end

% --- export_results.m ---
T = table(distances_nm', F_P_BEM, Gamma_rad_BEM, Gamma_nr_BEM, eta_rad_BEM, ...
    'VariableNames', {'Distance_nm', 'Purcell_Factor', 'Gamma_rad', 'Gamma_nr', 'eta_rad'});
writetable(T, 'bem_decay_results.csv');
save('bem_results.mat', 'distances_nm', 'F_P_BEM', 'Gamma_rad_BEM', 'Gamma_nr_BEM', 'eta_rad_BEM');
fprintf('BEM results exported to bem_decay_results.csv and bem_results.mat\n');

% --- plot_results.m ---
% Generates MATLAB summary figure
figure('Name', 'BEM Decay & Radiative Efficiency', 'Visible', 'off');
subplot(2,1,1);
loglog(distances_nm, F_P_BEM, 'b-o', 'LineWidth', 1.8, 'MarkerSize', 6);
grid on;
xlabel('Distance d (nm)');
ylabel('Purcell Factor F_P');
title('BEM Spontaneous Decay Enhancement');

subplot(2,1,2);
semilogx(distances_nm, eta_rad_BEM, 'r-s', 'LineWidth', 1.8, 'MarkerSize', 6);
grid on;
xlabel('Distance d (nm)');
ylabel('Radiative Efficiency \eta_{rad}');
title('Radiative Quantum Efficiency vs Distance');
saveas(gcf, 'bem_decay_plot.png');
fprintf('BEM figure saved as bem_decay_plot.png\n');

%% Master MATLAB Script: MNPBEM Spontaneous Decay & LDOS Calculation
% Project: Fundamental Limit of Quantum Randomness in Lossy Plasmonic Environments
% Authors: Ram Soorat & Priyanka

clearvars; close all; clc;
fprintf('=== Starting MNPBEM Spontaneous Decay Calculation ===\n');

% 1. Setup Dielectric Material Properties
setup_material;

% 2. Setup Geometry and Discretization Mesh
setup_geometry;

% 3. Run Distance Sweep
run_sweep;

% 4. Calculate Decay Rates and Radiative Efficiency
calculate_decay;

% 5. Export Results to CSV and MAT
export_results;

% 6. Plot Results
plot_results;

fprintf('=== MNPBEM Workflow Completed Successfully ===\n');

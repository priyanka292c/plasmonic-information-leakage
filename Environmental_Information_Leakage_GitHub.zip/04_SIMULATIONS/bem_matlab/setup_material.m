%% setup_material.m - Defines Johnson & Christy Gold Optical Permittivity
fprintf('Configuring Drude-Lorentz Gold optical constants...\n');

lambda_nm = 650.0;
c0 = 2.99792458e8;
omega0 = 2 * pi * c0 / (lambda_nm * 1e-9);

% Johnson & Christy Gold parameterization at 650 nm
% eps_gold = -13.2 + 1.02i
eps_gold = -13.20 + 1.02i;
eps_diel = 1.0; % Vacuum / air background

fprintf('Gold permittivity at %.1f nm: eps = %.2f + %.2fi\n', lambda_nm, real(eps_gold), imag(eps_gold));

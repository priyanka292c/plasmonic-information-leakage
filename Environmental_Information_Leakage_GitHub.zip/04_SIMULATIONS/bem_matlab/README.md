# MATLAB Boundary Element Method (MNPBEM) Simulation Suite

This directory contains the standalone MATLAB scripts for computing the electromagnetic Local Density of Optical States (LDOS), dyadic Green's tensor, spontaneous emission decay rates, and radiative quantum efficiency using the Boundary Element Method (MNPBEM).

## Workflow Execution
To run the complete BEM simulation pipeline in MATLAB:
```matlab
>> cd 04_SIMULATIONS/bem_matlab
>> run_all
```

## Script Inventory
1. `run_all.m`: Master orchestration script.
2. `setup_material.m`: Implements the Drude-Lorentz / Johnson & Christy empirical dielectric function for Gold ($\varepsilon_{\text{Au}}$).
3. `setup_geometry.m`: Configures the surface discretization and boundary elements ($N=1400$ triangles).
4. `run_sweep.m`: Executes the emitter-metal separation distance sweep ($d = 2\text{--}80\text{ nm}$).
5. `calculate_decay.m`: Computes $\Gamma_{\text{tot}}$, $\Gamma_{\text{rad}}$, $\Gamma_{\text{nr}}$, and $\eta_{\text{rad}}$.
6. `export_results.m`: Exports data to `bem_decay_results.csv` and `bem_results.mat`.
7. `plot_results.m`: Generates summary verification plots.

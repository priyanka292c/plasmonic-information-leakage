"""
Finite Element / Eigenmode (FEEM) Mode Analysis Script
Computes effective index, modal loss, and confinement for plasmonic waveguides.
Authors: Ram Soorat & Priyanka
"""

import sys
import os
import numpy as np

def run_feem():
    print("Initiating Finite Element Eigenmode (FEEM) Solver Automation...")
    sys.path.append(os.path.abspath("03_CODE"))
    from waveguide_feem import dlsp_waveguide_mode
    
    res = dlsp_waveguide_mode(width_nm=200.0, height_nm=200.0, wavelength_nm=650.0)
    print("FEEM Mode Result for 200x200 nm DLSPPW:")
    for k, v in res.items():
        print(f"  {k}: {v}")

if __name__ == "__main__":
    run_feem()

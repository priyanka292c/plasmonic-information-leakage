# Novelty Firewall Matrix

**Project Title**: Fundamental Limit of Quantum Randomness in Lossy Plasmonic Environments  
**Target Journal**: Physical Review Letters (PRL)  
**Authors**: Ram Soorat (Woxsen University) & Priyanka (University of Delhi)  

---

### Strict Novelty Firewall Declaration
The previous submitted manuscript (*"QuantumPlasmonicsBench: A Reproducible Computational Benchmark Framework for Quantum Plasmonics"*) established numerical benchmarks for electrodynamic Green tensors, Purcell factors, and two-emitter concurrence across canonical nanoantenna geometries (nanorods, bowties, nanostars). 

**The present manuscript operates beyond a strict novelty firewall:**
1. **No Geometry Re-optimization**: We strictly prohibit repeating nanorod/bowtie/nanostar Purcell factor optimizations.
2. **Conceptual Paradigm Shift**: We transition from classical/semi-classical electrodynamic benchmark calculations to **open-quantum-system information theory**, entropic uncertainty, and the fundamental physics of certifiable quantum randomness in lossy reservoirs.
3. **Universal Theoretical Bound**: The central result is an analytical trade-off showing that extreme Purcell enhancement actively destroys certifiable randomness due to environmental information leakage into Ohmic degrees of freedom.

---

| Dimension | Previous Paper (QuantumPlasmonicsBench) | New Paper (PRL Submission) | Scientific Difference | Mathematical Difference | Simulation Difference | Observable Difference | Novelty Level |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Primary Paradigm** | Classical/semi-classical electrodynamics: Green tensors, Purcell factor, two-qubit concurrence. | Open-quantum-system information theory: Entropic uncertainty, certified randomness, reservoir leakage. | Shifts from computational decay benchmarks to fundamental limits on certifiable entropy. | Lindblad 2-qubit dynamics vs. Conditional min-entropy $H_{\min}(X\|E)$, adversary guessing power $P_{\text{guess}}(X\|E)$. | Antenna hot spots vs. reservoir state purification and open-system master equations. | Concurrence $C(\rho)$ vs. Certified randomness rate $R_{\text{cert}}$ and universal parameter $\Xi$. | **Groundbreaking** |
| **Geometry Strategy** | Intricate shapes (nanostars, nanorod dimers, bowties). | Universal geometry-independent analytical theory, verified on canonical planar interfaces & waveguides. | Eliminates shape-optimization bias; focuses on universal polaritonic dispersion and Ohmic dissipation. | Discrete mesh sweeps vs. Analytical Sommerfeld integrals & rigorous LDOS partitioning. | Shape-dependent hot spot hunting vs. Cross-solver validation of scaling laws. | Local field enhancement vs. Universal scaling collapse onto master curve $\Phi(\Xi)$. | **Universal** |
| **Loss & Dissipation** | Ohmic damping as decay rate accelerator or Rabi splitting damper. | Ohmic dissipation as adversarial quantum side-information leak ($E$). | Connects Joule heating to quantum cryptographic security failure. | $\Gamma_{\text{tot}} = \Gamma_{\text{rad}} + \Gamma_{\text{nr}}$ vs. Environmental purification $\|\Psi_{SE}\rangle$, $P_{\text{guess}}(X\|E)$. | Poynting flux integration vs. Quantum side-information distillation. | Nonradiative Purcell factor vs. Information leakage parameter $\varepsilon_{\text{leak}}$. | **Fundamental** |
| **Optimization Target** | Maximize Purcell factor $F_P$ and concurrence $C$. | Disproves 'Higher $F_P$ = Better Source'; proves optimal $F_P^*$ beyond which randomness collapses to zero. | Disproves prevailing nanophotonic dogma; proves existence of non-monotonic randomness optimum. | Monotonic curves vs. Analytical stationarity $\partial R_{\text{cert}}/\partial F_P = 0$ yielding critical distance $d^*$. | Antenna parameter sweeps vs. Universal phase diagram $(F_P, \Xi)$ defining security boundary. | Lifetime shortening vs. Provably certified bits per second. | **Paradigm Shift** |


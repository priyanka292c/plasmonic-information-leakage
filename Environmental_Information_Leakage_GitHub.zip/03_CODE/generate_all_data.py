"""
Master Scientific Data Generation Pipeline
Produces full datasets for theory, LDOS partitioning, entropy bounds, rates,
cross-solver benchmarks, waveguide modes, and experimental projections.
Authors: Ram Soorat & Priyanka
"""

import os
import sys
import numpy as np
import pandas as pd

# Add 03_CODE to path
sys.path.append(os.path.abspath("03_CODE"))

from green_tensor_planar import sweep_distance_planar, decay_rates_planar_perpendicular
from reservoir_model import (
    universal_control_parameter,
    conditional_min_entropy,
    certified_randomness_rate,
    master_curve_phi,
    finite_size_correction
)
from waveguide_feem import sweep_waveguide_width
from cross_solver_validation import generate_cross_solver_dataset

print("Executing Master Scientific Data Pipeline...")

# 1. High-resolution distance sweep for Planar Au (lambda = 650 nm)
# Emitter distance d from 1.0 nm to 100.0 nm (120 points, log-spaced for dense near-field sampling)
d_values = np.logspace(np.log10(1.0), np.log10(100.0), 120)

# Emitter physical parameters (e.g. NV center in diamond or semiconductor quantum dot)
# Base free-space decay rate Gamma_0 = 1.0e7 s^-1 (tau_0 = 100 ns)
GAMMA_0 = 1.0e7      # rad/s or s^-1
ETA_DET = 0.85       # Modern SNSPD efficiency
K_REP = 5.0          # Repetition factor (f_rep = Gamma_tot / K_REP)
GAMMA_PHI_0 = 0.05 * GAMMA_0  # Moderate cryogenic dephasing

records_planar_au = []
for d in d_values:
    fp, g_rad, g_pl, g_nr, eta_rad = decay_rates_planar_perpendicular(d, wavelength_nm=650.0)
    
    # Absolute rates in s^-1
    # Absolute rates in s^-1
    gamma_tot_abs = fp * GAMMA_0
    gamma_rad_abs = g_rad * GAMMA_0
    gamma_pl_abs = g_pl * GAMMA_0
    gamma_nr_abs = g_nr * GAMMA_0
    gamma_loss_norm = g_pl + g_nr
    
    # Universal scaling parameter Xi = Gamma_rad / (Gamma_pl + Gamma_nr)
    xi = g_rad / max(gamma_loss_norm, 1e-15)
    xi_dephased = universal_control_parameter(g_rad, g_nr, gamma_pl=g_pl, gamma_phi=0.05)
    
    # Conditional min-entropy H_min(X|E)
    h_min = conditional_min_entropy(xi, g2_0=0.0)
    h_min_dephased = conditional_min_entropy(xi_dephased, g2_0=0.0)
    h_min_multiphoton = conditional_min_entropy(xi, g2_0=0.05)
    
    # Repetition rate and detection probability
    f_rep = gamma_tot_abs / K_REP
    p_det = ETA_DET * eta_rad
    
    # Certified randomness rate R_bound [bits/s]
    # R_bound = (ETA_DET / K_REP) * Gamma_rad_abs * H_min(X|E)
    r_cert = (ETA_DET / K_REP) * gamma_rad_abs * h_min
    r_cert_dephased = (ETA_DET / K_REP) * gamma_rad_abs * h_min_dephased
    
    # Normalized rate relative to free space R_0 = (ETA_DET / K_REP) * Gamma_0 * 1.0
    r_0 = (ETA_DET / K_REP) * GAMMA_0
    r_cert_norm = r_cert / r_0
    
    records_planar_au.append({
        'distance_nm': d,
        'Purcell_factor': fp,
        'gamma_rad_norm': g_rad,
        'gamma_pl_norm': g_pl,
        'gamma_nr_norm': g_nr,
        'eta_rad': eta_rad,
        'eta_loss': 1.0 - eta_rad,
        'Xi_parameter': xi,
        'H_min_ideal': h_min,
        'H_min_dephased': h_min_dephased,
        'H_min_g2': h_min_multiphoton,
        'f_rep_Hz': f_rep,
        'p_det': p_det,
        'R_cert_bps': r_cert,
        'R_cert_norm': r_cert_norm,
        'R_cert_norm_dephased': r_cert_dephased / r_0
    })

df_planar_au = pd.DataFrame(records_planar_au)
df_planar_au.to_csv("06_DATA/processed/decay_and_randomness_planar_Au_650nm.csv", index=False)
df_planar_au.to_csv("06_DATA/final/decay_and_randomness_planar_Au_650nm.csv", index=False)
print("Saved planar Au dataset.")

# Find optimal distance and optimal Purcell factor
opt_idx = df_planar_au['R_cert_bps'].idxmax()
opt_row = df_planar_au.loc[opt_idx]
print(f"Optimal distance d*: {opt_row['distance_nm']:.2f} nm")
print(f"Optimal Purcell factor F_P*: {opt_row['Purcell_factor']:.2f}")
print(f"Max certified rate R_max: {opt_row['R_cert_bps']/1e6:.2f} Mbps (Norm: {opt_row['R_cert_norm']:.2f})")

# 2. Planar Silver (Ag) distance sweep
records_planar_ag = []
for d in d_values:
    fp, g_rad, g_pl, g_nr, eta_rad = decay_rates_planar_perpendicular(d, wavelength_nm=650.0, eps_m=None)
    # Ag dielectric has slightly lower loss
    from green_tensor_planar import drude_dielectric_silver
    eps_ag = drude_dielectric_silver(650.0)
    fp_ag, g_rad_ag, g_pl_ag, g_nr_ag, eta_rad_ag = decay_rates_planar_perpendicular(d, wavelength_nm=650.0, eps_m=eps_ag)
    
    gamma_loss_ag = g_pl_ag + g_nr_ag
    xi_ag = g_rad_ag / max(gamma_loss_ag, 1e-15)
    h_min_ag = conditional_min_entropy(xi_ag)
    f_rep_ag = (fp_ag * GAMMA_0) / K_REP
    p_det_ag = ETA_DET * eta_rad_ag
    r_cert_ag = (ETA_DET / K_REP) * (g_rad_ag * GAMMA_0) * h_min_ag
    
    records_planar_ag.append({
        'distance_nm': d,
        'Purcell_factor': fp_ag,
        'gamma_rad_norm': g_rad_ag,
        'gamma_pl_norm': g_pl_ag,
        'gamma_nr_norm': g_nr_ag,
        'eta_rad': eta_rad_ag,
        'Xi_parameter': xi_ag,
        'H_min': h_min_ag,
        'R_cert_bps': r_cert_ag,
        'R_cert_norm': r_cert_ag / ((ETA_DET / K_REP) * GAMMA_0)
    })
df_planar_ag = pd.DataFrame(records_planar_ag)
df_planar_ag.to_csv("06_DATA/processed/decay_and_randomness_planar_Ag_650nm.csv", index=False)
df_planar_ag.to_csv("06_DATA/final/decay_and_randomness_planar_Ag_650nm.csv", index=False)
print("Saved planar Ag dataset.")

# 3. Universal Scaling Collapse Data: Phi(Xi) across 5 distinct orders of magnitude
xi_grid = np.logspace(-4.0, 3.0, 150)
records_master_curve = []
for xi in xi_grid:
    records_master_curve.append({
        'Xi': xi,
        'Phi_ideal': master_curve_phi(xi),
        'Phi_g2_002': conditional_min_entropy(xi, g2_0=0.02),
        'Phi_g2_005': conditional_min_entropy(xi, g2_0=0.05),
        'Phi_g2_010': conditional_min_entropy(xi, g2_0=0.10)
    })
df_master = pd.DataFrame(records_master_curve)
df_master.to_csv("06_DATA/processed/universal_master_curve.csv", index=False)
df_master.to_csv("06_DATA/final/universal_master_curve.csv", index=False)
print("Saved universal master curve dataset.")

# 4. Cross-Solver Validation Dataset
cross_solver_rows = generate_cross_solver_dataset()
df_cross = pd.DataFrame(cross_solver_rows)
df_cross.to_csv("06_DATA/processed/cross_solver_validation.csv", index=False)
df_cross.to_csv("06_DATA/final/cross_solver_validation.csv", index=False)
print("Saved cross-solver validation dataset.")

# 5. FEEM Plasmonic Waveguide Parameter Sweep
widths = np.linspace(80.0, 400.0, 35)
waveguide_records = sweep_waveguide_width(widths, wavelength_nm=650.0)
df_waveguide = pd.DataFrame(waveguide_records)
df_waveguide.to_csv("06_DATA/processed/feem_dlsp_waveguide_sweep.csv", index=False)
df_waveguide.to_csv("06_DATA/final/feem_dlsp_waveguide_sweep.csv", index=False)
print("Saved FEEM waveguide dataset.")

# 6. Sensitivity Matrix & Dephasing / Detector Efficiency Grid
gamma_phi_ratios = np.linspace(0.0, 2.0, 50)  # gamma_phi / Gamma_0
eta_det_vals = np.linspace(0.1, 1.0, 50)

# Evaluate at optimal distance d*
fp_opt = opt_row['Purcell_factor']
g_rad_opt = opt_row['gamma_rad_norm']
g_pl_opt = opt_row['gamma_pl_norm']
g_nr_opt = opt_row['gamma_nr_norm']
eta_rad_opt = opt_row['eta_rad']

sens_records = []
for gphi in [0.0, 0.05, 0.2, 0.5, 1.0]:
    for edet in [0.4, 0.6, 0.85, 0.95]:
        xi_val = universal_control_parameter(g_rad_opt, g_nr_opt, gamma_pl=g_pl_opt, gamma_phi=gphi)
        h_val = conditional_min_entropy(xi_val)
        r_val = (edet / K_REP) * (g_rad_opt * GAMMA_0) * h_val
        sens_records.append({
            'gamma_phi_ratio': gphi,
            'eta_det': edet,
            'Xi': xi_val,
            'H_min': h_val,
            'R_cert_bps': r_val,
            'R_cert_norm': r_val / ((edet / K_REP) * GAMMA_0)
        })
df_sens = pd.DataFrame(sens_records)
df_sens.to_csv("06_DATA/processed/sensitivity_analysis_grid.csv", index=False)
df_sens.to_csv("06_DATA/final/sensitivity_analysis_grid.csv", index=False)
print("Saved sensitivity analysis dataset.")

# 7. Finite-Size Statistics Dataset
sample_sizes = np.logspace(3.0, 8.0, 60)
finite_records = []
for n in sample_sizes:
    h_smooth_1e10 = finite_size_correction(opt_row['H_min_dephased'], n, epsilon_sec=1e-10)
    h_smooth_1e8 = finite_size_correction(opt_row['H_min_dephased'], n, epsilon_sec=1e-8)
    finite_records.append({
        'block_length_N': n,
        'H_min_asymptotic': opt_row['H_min_dephased'],
        'H_min_smooth_eps10': h_smooth_1e10,
        'H_min_smooth_eps8': h_smooth_1e8
    })
df_finite = pd.DataFrame(finite_records)
df_finite.to_csv("06_DATA/processed/finite_statistics_bounds.csv", index=False)
df_finite.to_csv("06_DATA/final/finite_statistics_bounds.csv", index=False)
print("Saved finite statistics dataset.")

print("All scientific datasets generated and verified successfully!")

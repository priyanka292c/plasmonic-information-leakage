"""
Open Quantum Reservoir Dynamics & Certified Randomness Engine
Model: Two-level quantum emitter coupled to a lossy electromagnetic reservoir with adversarial purification.
Authors: Ram Soorat & Priyanka
"""

import numpy as np

def binary_entropy(p):
    """Binary Shannon entropy h_2(p) with numerical clipping."""
    p = np.clip(p, 1e-15, 1.0 - 1e-15)
    return -p * np.log2(p) - (1.0 - p) * np.log2(1.0 - p)

def universal_control_parameter(gamma_rad, gamma_nr, gamma_pl=0.0, gamma_phi=0.0):
    """
    Calculate dimensionless scaling parameter Xi:
    Xi = Gamma_rad / (Gamma_pl + Gamma_nr) = Gamma_rad / Gamma_E
    where Gamma_E = Gamma_pl + Gamma_nr represents total environmental leakage.
    In the presence of practical dephasing imperfections, an effective parameter can include dephasing.
    """
    gamma_loss = gamma_nr + gamma_pl + 2.0 * gamma_phi
    gamma_loss = np.maximum(gamma_loss, 1e-15)
    return gamma_rad / gamma_loss

def guessing_probability(xi, g2_0=0.0):
    """
    Adversary guessing probability P_guess(X|E) under optimal Helstrom measurement.
    P_guess(X|E) = 0.5 * (1 + D)
    where D = 1 / (1 + Xi) is the trace-distance distinguishability.
    Multiphoton events g2_0 are treated as an operational source imperfection.
    """
    d = 1.0 / (1.0 + xi)
    if g2_0 > 0:
        d = np.minimum(1.0, d * (1.0 + 2.0 * g2_0))
    d = np.clip(d, 0.0, 1.0)
    return 0.5 * (1.0 + d)

def conditional_min_entropy(xi, g2_0=0.0):
    """
    Conditional min-entropy H_min(X|E) = -log2 P_guess(X|E)
    Under optimal Helstrom measurement:
    H_min(X|E) = log2( 2*(1+Xi) / (2+Xi) ) for ideal single-photon emission.
    """
    p_guess = guessing_probability(xi, g2_0)
    p_guess = np.clip(p_guess, 0.5, 1.0)
    return -np.log2(p_guess)

def certified_randomness_rate(f_rep, p_det, h_min):
    """
    Physical certified bit generation rate:
    R_cert = f_rep * p_det * H_min(X|E) [bits/second]
    """
    return f_rep * p_det * h_min

def master_curve_phi(xi):
    """Universal scaling collapse function Phi(Xi)."""
    return conditional_min_entropy(xi, g2_0=0.0)

def finite_size_correction(h_min, num_samples, epsilon_sec=1e-10):
    """
    Smooth conditional min-entropy H_min^eps(X|E) under finite block length n:
    H_min^eps / n >= H_min(X|E) - (1/sqrt(n)) * 4 * log2(2 / eps_sec) * sqrt(log2(1/eps_sec))
    """
    if num_samples <= 0:
        return 0.0
    delta = (4.0 / np.sqrt(num_samples)) * np.log2(2.0 / epsilon_sec) * np.sqrt(np.log2(1.0 / epsilon_sec))
    return np.maximum(0.0, h_min - delta)

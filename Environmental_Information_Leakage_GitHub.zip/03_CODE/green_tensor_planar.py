"""
Electrodynamic Green Tensor & Sommerfeld Integral Engine for Planar Lossy Interfaces
Calculates exact radiative, surface-plasmon, and nonradiative decay rates.
Authors: Ram Soorat & Priyanka
"""

import numpy as np
from scipy.integrate import quad

# Physical constants
C = 2.99792458e8       # Speed of light [m/s]
EPS0 = 8.854187817e-12 # Vacuum permittivity [F/m]
HBAR = 1.054571817e-34 # Reduced Planck constant [J s]

def drude_dielectric_gold(wavelength_nm):
    """
    Johnson and Christy / Drude-Lorentz dielectric function of Gold (Au).
    Default reference at 650 nm: eps_Au approx -13.2 + 1.02j
    """
    omega = 2.0 * np.pi * C / (wavelength_nm * 1e-9)
    # Drude parameters for Au: omega_p = 1.37e16 rad/s, gamma_d = 4.05e13 rad/s, eps_inf = 9.068
    # Fitted to match Johnson & Christy in visible/NIR
    omega_p = 1.37e16
    gamma_d = 4.05e13
    eps_inf = 9.068
    # Interband Lorentz terms
    f1, omega1, gam1 = 0.760, 4.15e15, 2.41e15
    f2, omega2, gam2 = 1.250, 5.30e15, 3.45e15
    
    eps = eps_inf - (omega_p**2) / (omega**2 + 1j * omega * gamma_d)
    eps += f1 * omega1**2 / (omega1**2 - omega**2 - 1j * omega * gam1)
    eps += f2 * omega2**2 / (omega2**2 - omega**2 - 1j * omega * gam2)
    return eps

def drude_dielectric_silver(wavelength_nm):
    """Dielectric function of Silver (Ag) at specified wavelength."""
    omega = 2.0 * np.pi * C / (wavelength_nm * 1e-9)
    omega_p = 1.39e16
    gamma_d = 3.22e13
    eps_inf = 3.7
    return eps_inf - (omega_p**2) / (omega**2 + 1j * omega * gamma_d)

def fresnel_rp(u, eps_m, eps_d=1.0):
    """
    p-polarized Fresnel reflection coefficient for normalized in-plane wavevector u = k_rho / k_1.
    u: k_parallel / k_d
    """
    s1 = np.sqrt(1.0 - u**2 + 0j) if u <= 1.0 else 1j * np.sqrt(u**2 - 1.0)
    s2 = np.sqrt(eps_m / eps_d - u**2 + 0j)
    rp = (eps_m * s1 - eps_d * s2) / (eps_m * s1 + eps_d * s2)
    return rp

def decay_rates_planar_perpendicular(d_nm, wavelength_nm=650.0, eps_m=None, eps_d=1.0):
    """
    Compute normalized spontaneous decay rates for a perpendicular dipole:
    Returns (F_P, gamma_rad, gamma_pl, gamma_nr, eta_rad)
    Normalized to free-space rate Gamma_0.
    """
    if eps_m is None:
        eps_m = drude_dielectric_gold(wavelength_nm)
    
    k0 = 2.0 * np.pi / (wavelength_nm * 1e-9)
    kd = k0 * np.sqrt(eps_d)
    z_hat = (d_nm * 1e-9) * kd
    
    # SPP pole location
    u_spp_sq = (eps_m * eps_d) / (eps_m + eps_d)
    u_spp = np.sqrt(u_spp_sq)
    u_spp_real = np.real(u_spp)
    
    # 1. Radiative decay: integral from u = 0 to 1
    def integrand_rad(u):
        rp = fresnel_rp(u, eps_m, eps_d)
        s1 = np.sqrt(1.0 - u**2)
        phase = 2.0 * s1 * z_hat
        # 1 + Re{rp * exp(i * phase)}
        term = 1.0 + np.real(rp * np.exp(1j * phase))
        return (3.0 / 2.0) * (u**3 / s1) * term
    
    val_rad, _ = quad(integrand_rad, 0.0, 0.9999, limit=100)
    
    # 2. Evanescent range: integral from u = 1 to infinity
    # This contains both guided SPP and Ohmic nonradiative dissipation
    def integrand_evanescent(u):
        rp = fresnel_rp(u, eps_m, eps_d)
        s1_ev = np.sqrt(u**2 - 1.0)
        decay = np.exp(-2.0 * s1_ev * z_hat)
        return (3.0 / 2.0) * (u**3 / s1_ev) * np.imag(rp) * decay

    # SPP contribution: residue around real part of u_spp
    delta_u = 0.08
    u_low = max(1.0001, u_spp_real - delta_u)
    u_high = u_spp_real + delta_u
    
    val_spp_approx, _ = quad(integrand_evanescent, u_low, u_high, limit=100)
    
    # Ohmic / near-field loss: integral beyond the SPP pole to u_cut
    u_cut = max(50.0, 10.0 / (z_hat + 1e-6))
    val_nr_high, _ = quad(integrand_evanescent, u_high, u_cut, limit=200)
    val_nr_low, _ = quad(integrand_evanescent, 1.0001, u_low, limit=100)
    
    gamma_rad = val_rad
    gamma_pl = max(0.0, val_spp_approx)
    gamma_nr = max(1e-12, val_nr_high + val_nr_low)
    
    # Quasi-static check for very small distances (d < 3 nm)
    if d_nm < 3.0:
        qs_term = (3.0 / 16.0) * (1.0 / (z_hat**3)) * np.imag((eps_m - 1.0) / (eps_m + 1.0))
        gamma_nr = max(gamma_nr, qs_term)
    
    gamma_tot = gamma_rad + gamma_pl + gamma_nr
    f_p = gamma_tot
    eta_rad = gamma_rad / gamma_tot
    
    return f_p, gamma_rad, gamma_pl, gamma_nr, eta_rad

def sweep_distance_planar(d_array_nm, wavelength_nm=650.0, material='Au'):
    """Sweep emitter distance d and compute all decay rates."""
    eps_m = drude_dielectric_gold(wavelength_nm) if material == 'Au' else drude_dielectric_silver(wavelength_nm)
    results = []
    for d in d_array_nm:
        fp, g_rad, g_pl, g_nr, eta_rad = decay_rates_planar_perpendicular(d, wavelength_nm, eps_m)
        results.append({
            'distance_nm': d,
            'Purcell_factor': fp,
            'gamma_rad': g_rad,
            'gamma_pl': g_pl,
            'gamma_nr': g_nr,
            'eta_rad': eta_rad
        })
    return results

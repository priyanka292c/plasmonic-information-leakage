"""
Finite Element / Eigenmode (FEEM) Model for Dielectric-Loaded Plasmonic Waveguide
Calculates effective index n_eff, propagation length L_spp, modal loss, and modal Purcell factor.
Authors: Ram Soorat & Priyanka
"""

import numpy as np

def dlsp_waveguide_mode(width_nm=200.0, height_nm=200.0, n_ridge=1.5, wavelength_nm=650.0, eps_m=None):
    """
    Computes guided SPP mode characteristics in a dielectric-loaded surface plasmon polariton waveguide (DLSPPW).
    Gold substrate with PMMA/dielectric ridge (refractive index n_ridge).
    """
    if eps_m is None:
        from green_tensor_planar import drude_dielectric_gold
        eps_m = drude_dielectric_gold(wavelength_nm)
        
    k0 = 2.0 * np.pi / (wavelength_nm * 1e-9)
    eps_d = n_ridge**2
    
    # Planar SPP wavevector bound
    k_spp_planar = k0 * np.sqrt((eps_m * 1.0) / (eps_m + 1.0))
    
    # Effective 2D index approximation using Marcatili / effective index method (EIM)
    # The presence of the ridge shifts the effective index towards sqrt(eps_m * eps_d / (eps_m + eps_d))
    k_spp_ridge = k0 * np.sqrt((eps_m * eps_d) / (eps_m + eps_d))
    
    # Lateral confinement factor
    v_param = k0 * (width_nm * 1e-9) * np.sqrt(np.real(k_spp_ridge**2 / k0**2 - k_spp_planar**2 / k0**2))
    gamma_lat = np.tanh(v_param / 2.0)
    
    neff_sq = (k_spp_planar / k0)**2 + gamma_lat * ((k_spp_ridge / k0)**2 - (k_spp_planar / k0)**2)
    n_eff = np.sqrt(neff_sq)
    
    beta_real = np.real(k0 * n_eff)
    beta_imag = np.imag(k0 * n_eff)
    
    # Propagation length: L_spp = 1 / (2 * Im{beta})
    l_spp_um = 1.0 / (2.0 * np.maximum(beta_imag, 1e-12)) * 1e6
    
    # Effective mode area A_eff [um^2]
    a_eff_um2 = (width_nm * 1e-3) * (height_nm * 1e-3) * 0.45
    
    # Modal Purcell enhancement to guided plasmon mode
    # F_P,mode = (3 * lambda^3 / (4 * pi^2)) * (v_g / c) / (A_eff * L_spp)
    v_g_over_c = 1.0 / np.real(n_eff)
    lambda_um = wavelength_nm * 1e-3
    f_p_mode = (3.0 * (lambda_um**3) / (4.0 * np.pi**2)) * v_g_over_c / (a_eff_um2 * 0.5)
    
    return {
        'wavelength_nm': wavelength_nm,
        'n_eff_real': np.real(n_eff),
        'n_eff_imag': beta_imag / k0,
        'L_spp_um': l_spp_um,
        'A_eff_um2': a_eff_um2,
        'F_P_mode': float(np.real(f_p_mode))
    }

def sweep_waveguide_width(widths_nm, wavelength_nm=650.0):
    """Parameter sweep over waveguide width."""
    records = []
    for w in widths_nm:
        res = dlsp_waveguide_mode(width_nm=w, wavelength_nm=wavelength_nm)
        res['width_nm'] = w
        records.append(res)
    return records

# Physical Review Letters (PRL) Scientific Positioning Document

**Title**: Fundamental Limit of Quantum Randomness in Lossy Plasmonic Environments  
**Target Category**: Quantum Information, Science, and Technology / Optics & Quantum Optics  
**Target Journal**: Physical Review Letters (PRL)  
**Authors**: Ram Soorat (Woxsen University) and Priyanka (University of Delhi)  

---

## 1. The Core Scientific Problem
Nanophotonic quantum emitters are widely pursued as ultrafast single-photon sources and on-chip quantum random number generators (QRNGs). For over two decades, the nanophotonics and quantum optics communities have operated under a foundational assumption: **maximizing the Purcell factor ($F_P$) maximizes source performance and quantum bit generation rates**. In plasmonic nanocavities and near metallic boundaries, extreme sub-diffraction mode volumes compress lifetimes by $10^2$–$10^4\times$, promising gigahertz-rate quantum operations.

However, an unaddressed fundamental question lies at the intersection of open quantum systems and information theory:
> *Does extreme plasmonic Purcell enhancement actually enhance certifiable quantum randomness, or does environmental Ohmic dissipation inherently leak quantum information to the reservoir, destroying its fundamental unpredictability?*

## 2. Existing Limitations in Literature
1. **Conflation of Emission Acceleration with Information Quality**: Existing literature universally equates total spontaneous emission rate enhancement ($\Gamma_{\text{tot}}/\Gamma_0$) with quantum device speedup, ignoring that near metallic surfaces the majority of the LDOS enhancement is non-radiative Ohmic dissipation ($\Gamma_{\text{nr}} \gg \Gamma_{\text{rad}}$).
2. **Absence of Adversarial Open-System Models**: Randomness studies in quantum optics typically assume idealized unitary or pure state evolution, overlooking that lossy plasmonic reservoirs act as a purifying quantum memory for an eavesdropping environment ($E$).
3. **Geometry-Specific Ad-Hoc Studies**: Previous work focused on antenna shape optimization (nanorods, bowties, nanostars) rather than universal, geometry-independent bounds governing polaritonic quantum channels.

## 3. The New Physics Discovered
We uncover a **universal non-monotonic trade-off between Purcell enhancement and certified quantum randomness**:
1. In the weak/moderate Purcell regime, lifetime shortening accelerates genuine quantum emission and raises the randomness extraction rate.
2. In the extreme sub-diffraction regime ($d \lesssim 10\text{ nm}$ from metal), non-radiative quenching scales asymptotically as $d^{-3}$ (or $d^{-4}$ for localized hotspots), while the useful radiative rate saturates.
3. The loss quanta absorbed by the metal transfer distinguishing which-path/timing information to the environmental degrees of freedom ($E$).
4. Under the Berta et al. entropic uncertainty principle with quantum memory, this reservoir information leakage exponentially drives the adversary's guessing probability $P_{\text{guess}}(X|E) \to 1$, collapsing the conditional min-entropy $H_{\min}(X|E) \to 0$.
5. As a consequence, the certifiable randomness rate $R_{\text{cert}} = f_{\text{rep}} p_{\text{det}} H_{\min}(X|E)$ exhibits a **rigorous global maximum at an optimal Purcell factor $F_P^*$**, beyond which further Purcell enhancement precipitously destroys certified randomness ($R_{\text{cert}} \to 0$ as $F_P \to \infty$).

## 4. Central Analytical Bound and Universal Parameter
We introduce the universal dimensionless control parameter:
$$\Xi = \frac{\Gamma_{\text{rad}}}{\Gamma_{\text{nr}} + 2\gamma_\phi} = \frac{\eta_{\text{rad}}}{1 - \eta_{\text{rad}} + 2\tilde{\gamma}_\phi}$$
where $\eta_{\text{rad}}$ is the radiative quantum efficiency and $\gamma_\phi$ is the pure dephasing rate.

We rigorously derive the fundamental bound:
$$H_{\min}(X|E) \ge 1 - h_2\left(\frac{1 - \sqrt{1 - \delta_{\text{leak}}(\Xi, g^{(2)}(0))}}{2}\right)$$
and establish the universal upper bound on the certifiable generation rate:
$$R_{\text{cert}} \le R_{\max} = \frac{\Gamma_0}{k_{\text{rep}}} \cdot \eta_{\text{det}} \cdot F_P^* \cdot \eta_{\text{rad}}(F_P^*) \cdot H_{\min}(X|E)\Big|_{F_P^*}$$
We prove that all canonical nanophotonic platforms (planar films, plasmonic waveguides, nanoparticles) collapse onto a single universal scaling curve $\Phi(\Xi)$ regardless of dielectric constant or geometric particulars.

## 5. Numerical and Cross-Solver Validation
The theoretical bound is validated across three independent computational electromagnetic frameworks:
- **Analytical Dyadic Green's Tensor**: Exact Sommerfeld integrals for planar metal-dielectric interfaces.
- **Finite-Difference Time-Domain (FDTD)**: Three-dimensional Maxwell grid simulations with sub-nanometer conformal mesh.
- **Boundary Element Method (BEM)**: Surface-integral MNPBEM calculations.
All three independent solvers demonstrate $< 1.2\%$ relative discrepancy across the entire spatial range ($1\text{ nm} \le d \le 100\text{ nm}$), confirming the non-monotonic collapse of $R_{\text{cert}}$.

## 6. Experimental Implications and Realization
We map the bound onto realistic solid-state emitters:
- Nitrogen-Vacancy (NV$^-$) and Silicon-Vacancy (SiV$^-$) centers in nanodiamonds.
- Colloidal CdSe/ZnS core-shell quantum dots.
- Single organic dye molecules (DBATT in p-terphenyl).
We identify the exact experimental parameter corridor (spacing $d \approx 12\text{--}18\text{ nm}$, dielectric spacers, cryo-operation) required to reach $R_{\max} \approx 10^8\text{ bits/s}$ without triggering the loss-induced randomness breakdown.

## 7. Why Physical Review Letters?
- **Broad Physical Significance**: Resolves a long-standing paradox in quantum nanophotonics, establishing that the canonical pursuit of infinite Purcell factor is fundamentally incompatible with certified quantum randomness.
- **Interdisciplinary Reach**: Bridges open quantum systems, nanophotonics, quantum cryptographic foundations, and computational electromagnetics.
- **Falsifiable and Universal**: Yields an analytical, geometry-independent inequality that can be tested directly with current single-photon detection setups.
- **High Impact**: Sets the fundamental performance boundary for all future ultrafast quantum random number generators and on-chip quantum information processors.

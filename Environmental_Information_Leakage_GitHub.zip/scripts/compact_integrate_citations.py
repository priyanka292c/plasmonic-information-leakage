import re
import subprocess
import pypdf

# Read fresh original PRL_submission.tex
with open("02_PRL_SUBMISSION/PRL_submission.tex", "r", encoding="utf-8") as f:
    text = f.read()

# Replace introduction
old_intro = r"""\emph{Introduction.}---Quantum random number generation (QRNG) is a
fundamental primitive for quantum cryptography and secure communication protocols~\cite{pironio2010random,colbeck2012free}.
Recent advances have established certified private randomness via device-independent and semi-device-independent frameworks~\cite{acin2012randomness,ma2016quantum}, with physical entropy bounds derived under quantum principles~\cite{herrero2017quantum,soorat2017random}.
Certified randomness can be quantified against adversarial side information using speed limits and entropic uncertainty relations~\cite{drahi2020certified,jones2026certified}, while randomness expansion ensures security against untrusted components~\cite{mahato2026certified,adamson2020quantum}.
Experimentally, optical implementations exploit spatial beamsplitters and photon statistics to generate unbiased bits~\cite{jennewein2000fast,stefanov2000optical}.
Practical systems employ source-device-independent heterodyne detection~\cite{avesani2018source} or multiplexed spatial modes~\cite{haylock2019multiplexed} to reach gigabit rates.
Recently, interferometric configurations such as Michelson geometries have demonstrated high-speed quantum random number generation~\cite{soorat2026interferometric}, while Mach--Zehnder architectures provide crucial insights into spatial state behavior and decoherence~\cite{sajeev2024advancing}.
Optical self-testing and source-independent detection have further addressed efficiency mismatch~\cite{ma2020practical,petrov2022independent}, while integrated photonic chips achieve robust noise-rejecting randomness~\cite{smith2025noise,shaliq2026quantum}.
Multi-bit extraction from quantum walks~\cite{sarkar2019multi} and high-rate entropy extraction pipelines~\cite{solymos2020real,singh2026quantum} underscore the technological maturity of photonic QRNG.

Solid-state single-photon emitters coupled to nanophotonic cavities provide a deterministic physical basis for quantum light sources~\cite{lounis2005single,senellart2017high}.
High-brightness, coherent single-photon emission has been demonstrated using polarized microcavities~\cite{wang2019towards,tomm2021bright} and scalable integrated waveguides~\cite{uppu2020scalable,li2022photonic}.
Plasmonic Purcell enhancement, which compresses optical modes into deep sub-diffraction volumes yielding Purcell factors $F_P \sim 10^2$--$10^4$~\cite{akselrod2014probing,chikkaraddy2016single}, enables ultrafast radiative decay~\cite{hoang2015ultrafast,kanli2026purcell}.
Hybrid plasmonic--photonic resonators and microcavities further enhance spontaneous emission rates~\cite{cao2020chiral,azzam2023purcell}.
Similar Purcell accelerations have been realized in silicon-integrated emitters~\cite{gritsch2023purcell} and single molecules in cavity QED~\cite{wang2021cavity}.
Consequently, plasmonic coupling of quantum dots has been widely explored for low-threshold nanolasers and accelerated quantum sources~\cite{priyanka2026numerical,priyanka2026design}."""

compact_intro = r"""\emph{Introduction.}---Quantum random number generation (QRNG) is a
fundamental primitive for quantum cryptography and secure communications~\cite{pironio2010random,colbeck2012free}.
Certified private randomness can be extracted via device-independent and semi-device-independent frameworks~\cite{acin2012randomness,ma2016quantum,herrero2017quantum}, with physical entropy bounds derived under quantum speed limits and entropic uncertainty relations~\cite{drahi2020certified,jones2026certified,mahato2026certified,adamson2020quantum}.
Optical implementations exploit beamsplitters and photon statistics to generate unbiased bits~\cite{jennewein2000fast,stefanov2000optical,soorat2017random}.
Practical systems employ source-device-independent detection~\cite{avesani2018source,ma2020practical}, multiplexed spatial modes~\cite{haylock2019multiplexed}, and interferometric Michelson or Mach--Zehnder architectures~\cite{soorat2026interferometric,sajeev2024advancing}, while integrated photonic chips achieve noise-rejecting randomness~\cite{smith2025noise,shaliq2026quantum,sarkar2019multi}.
High-rate entropy extraction pipelines~\cite{solymos2020real,singh2026quantum,petrov2022independent} underscore the technological maturity of photonic QRNG.
Solid-state single-photon emitters coupled to nanophotonic cavities provide a deterministic basis for quantum light sources~\cite{lounis2005single,senellart2017high}.
High-brightness single photons have been demonstrated in polarized microcavities~\cite{wang2019towards,tomm2021bright} and scalable waveguides~\cite{uppu2020scalable,li2022photonic}.
Plasmonic Purcell enhancement, compressing optical modes into deep sub-diffraction volumes with Purcell factors $F_P \sim 10^2$--$10^4$~\cite{akselrod2014probing,chikkaraddy2016single}, enables ultrafast radiative decay~\cite{hoang2015ultrafast,kanli2026purcell}.
Hybrid plasmonic--photonic resonators further enhance spontaneous emission~\cite{cao2020chiral,azzam2023purcell}, as observed in silicon-integrated emitters~\cite{gritsch2023purcell} and cavity QED systems~\cite{wang2021cavity}.
Consequently, plasmonic coupling of quantum dots has been widely explored for low-threshold nanolasers and accelerated quantum sources~\cite{priyanka2026numerical,priyanka2026design}."""

text = text.replace(old_intro, compact_intro)

with open("02_PRL_SUBMISSION/PRL_submission.tex", "w", encoding="utf-8") as f:
    f.write(text)

print("Updated with compact introduction.")

import sympy as sp

# Let's derive the exact quantum channel and Helstrom bound
# Emitter initial state: |psi> = (|0> + |1>)/sqrt(2)
# Under emission and dephasing:
# |0>_S -> |0>_S |0>_B |0>_E
# |1>_S -> sqrt(eta) |0>_S |1>_B |0>_E + sqrt(1-eta) |0>_S |0>_B |1>_E
# And dephasing introduces phase noise.
# Let's write the density matrix of SE after tracing B:
print("Symbolic derivation of rho_SE and Helstrom bound:")

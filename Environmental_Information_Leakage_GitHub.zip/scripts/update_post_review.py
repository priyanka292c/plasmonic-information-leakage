import os
import re

def update_manuscript():
    path = "scripts/write_manuscript.py"
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()

    replacements = [
        # 1. Abstract discrepancy
        (
            r"achieving cross-solver numerical agreement within $\le 0.91\%$ discrepancy across the local-response validity domain ($d \ge 5$\,nm), with a cross-geometry validation on a dielectric-loaded plasmonic waveguide consistent within $<3\%$.",
            r"achieving cross-solver numerical agreement with a maximum discrepancy of $1.04\%$ across the tested $d \ge 5$\,nm range ($\le 0.91\%$ across $d \le 50$\,nm), alongside a cross-geometry numerical consistency test on a dielectric-loaded plasmonic waveguide agreeing within $<3\%$."
        ),
        # 2. Abstract 'prove'
        (
            r"We prove that any fine-grained adversarial access to environmental modes can only further reduce extractable privacy, rendering $\Phi(\Xi)$ the most optimistic operational bound.",
            r"We show within the open-system channel model that any fine-grained adversarial access to environmental modes can only further reduce extractable privacy, rendering $\Phi(\Xi)$ the most optimistic operational bound."
        ),
        # 3. Abstract throughput rates
        (
            r"We show that the platform-matched private-randomness capacity $R_{\rm priv}(d) \propto \Gamma_{\rm rad}(d) H_{\min}(X|E; d)$ exhibits a non-monotonic trajectory with a finite-distance local optimum within the strongly coupled plasmonic regime: planar gold peaks at $d^* \approx 33.8$\,nm ($F_P^* \approx 4.0$, $R_{\rm priv}^{\max} \approx 0.20$\,Mbps) and silver at $d^* \approx 17.5$\,nm ($F_P^* \approx 3.4$, $R_{\rm priv}^{\max} \approx 0.46$\,Mbps).",
            r"We show that the platform-matched theoretical private-randomness throughput exhibits a non-monotonic trajectory with a finite-distance local optimum within the plasmonic regime: for planar gold, the channel throughput peaks at $d^* \approx 33.8$\,nm ($F_P^* \approx 4.0$, $R_{\rm priv}^{(\rm ch),\max} \approx 0.201$\,Mbps, corresponding to a net dual-rail arm contribution $R_{\rm priv}^{(\rm arm),\max} \approx 0.101$\,Mbps), while silver peaks at $d^* \approx 17.5$\,nm ($F_P^* \approx 3.4$, $R_{\rm priv}^{(\rm ch),\max} \approx 0.462$\,Mbps; $R_{\rm priv}^{(\rm arm),\max} \approx 0.231$\,Mbps)."
        ),
        # 4. Abstract near field collapse & foundational design principle
        (
            r"collapsing private throughput to $\sim 1.0$\,kbps relative to the uncoupled free-space baseline $R_0 \approx 1.70$\,Mbps. These results reveal that extreme field confinement leaks which-path information to dissipative environmental channels, establishing a foundational design principle for open quantum nanophotonics: nanophotonic sources must optimize useful radiative emission together with environmental information isolation rather than maximizing the Purcell factor alone.",
            r"collapsing the private channel throughput to $\sim 1.0$\,kbps (net dual-rail arm contribution $\sim 0.50$\,kbps) relative to the uncoupled free-space baseline $R_0 \approx 1.70$\,Mbps ($R_0^{(\rm arm)} \approx 0.85$\,Mbps). These results reveal that extreme field confinement leaks which-path information to dissipative environmental channels, establishing a practical design principle for information-aware plasmonic quantum-source optimization: nanophotonic sources must optimize useful radiative emission together with environmental information isolation rather than maximizing the Purcell factor alone."
        ),
        # 5. Abstract invariance theorem wording
        (
            r"A comprehensive sensitivity analysis demonstrates that the optimal separation distance $d^*$ is mathematically strictly invariant to the pulse repetition factor $k_{\rm rep} \in \{2, 5, 10, 20\}$",
            r"A comprehensive parameter scaling analysis demonstrates that the optimal separation distance $d^*$ is strictly invariant to the pulse repetition factor $k_{\rm rep} \in \{2, 5, 10, 20\}$"
        ),
        # 6. Intro recent citations
        (
            r"Concurrently, advanced Green-tensor decomposition methods and multi-solver computational benchmarks have established precise standards for LDOS calculation~\cite{zhang2025channel,kumar2025computational,mancini2026purcell}. Yet, despite these advances, existing studies have not formulated an information-theoretic framework to determine whether the accelerated emission remains a useful, private quantum resource in the presence of uncollected polaritonic and Ohmic loss.",
            r"Concurrently, advanced Green-tensor decomposition methods and multi-solver computational benchmarks have established precise standards for LDOS calculation~\cite{zhang2025channel,kumar2025computational,mancini2026purcell}, while recent investigations have explored the boundaries of strong coupling and spontaneous emission interference near metallic nanostructures~\cite{thanopulos2024strong}. In parallel, quantum-information protocols and photonic quantum randomness generation have advanced toward certified security against channel noise and physical side information~\cite{souza2024quantum,damodarakurup2024concatenated,singh2026quantum,nath2025certified,noreen2026randomness}. Yet, despite these advances, existing studies have not formulated an information-theoretic framework to determine whether the accelerated emission remains a useful, private quantum resource in the presence of uncollected polaritonic and Ohmic loss."
        ),
        # 7. Table 1 updates
        (
            r"Formal comparison of unconditional private capacity vs.\ detection-conditioned entropy $H_{\min}(X|E, {\rm det}) = \log_2(1+\eta_B)$",
            r"Formal comparison of unconditional private throughput vs.\ detection-conditioned entropy $H_{\min}(X|E, {\rm det}) = \log_2(1+\eta_B)$"
        ),
        (
            r"4-solver cross-validation (Sommerfeld Green, 3D conformal FDTD, surface BEM, FEEM waveguide); $\le 0.91\%$ agreement",
            r"4-solver cross-validation (Sommerfeld Green, 3D conformal FDTD, surface BEM, FEEM waveguide); $\le 1.04\%$ discrepancy across $d \ge 5$\,nm ($\le 0.91\%$ for $d \le 50$\,nm); cross-geometry consistency test on DLSPPW ($<3\%$)"
        ),
        (
            r"Invariance theorem of $d^*$ across $k_{\rm rep} \in \{2, 5, 10, 20\}$; nonlocality cutoff sensitivity $d_{\min} \in \{3, 5, 7, 10\}$\,nm",
            r"Parameter scaling and invariance of $d^*$ across $k_{\rm rep} \in \{2, 5, 10, 20\}$; nonlocality cutoff sensitivity $d_{\min} \in \{3, 5, 7, 10\}$\,nm"
        ),
        # 8. Intro bullet points
        (
            r"\item \textbf{Exact Information-Theoretic Master Curve:} By applying Helstrom hypothesis testing to an open-system Stinespring dilation that conservatively attributes all uncollected guided polaritons ($\Gamma_{\rm pl}$) and Ohmic Joule dissipation ($\Gamma_{\rm nr}$) to an adversary (Eve), we derive an exact analytical relation for the private conditional min-entropy: $H_{\min}(X|E) = \log_2[2(1+\Xi)/(2+\Xi)] \equiv \Phi(\Xi)$, governed strictly by the dimensionless decay-branching ratio $\Xi \equiv \Gamma_{\rm rad}/(\Gamma_{\rm pl} + \Gamma_{\rm nr})$. We prove that environmental fine-graining strictly reinforces this bound, ensuring that $\Phi(\Xi)$ is the maximum certifiable privacy Alice can claim.",
            r"\item \textbf{Exact Information-Theoretic Master Curve:} By applying Helstrom hypothesis testing to an open-system Stinespring dilation that conservatively attributes all uncollected guided polaritons ($\Gamma_{\rm pl}$) and Ohmic Joule dissipation ($\Gamma_{\rm nr}$) to an adversary (Eve), we derive an exact analytical relation for the private conditional min-entropy: $H_{\min}(X|E) = \log_2[2(1+\Xi)/(2+\Xi)] \equiv \Phi(\Xi)$, governed strictly by the dimensionless decay-branching ratio $\Xi \equiv \Gamma_{\rm rad}/(\Gamma_{\rm pl} + \Gamma_{\rm nr})$. We show within the open-system model that environmental fine-graining strictly reinforces this bound, ensuring that $\Phi(\Xi)$ is the maximum certifiable privacy Alice can claim."
        ),
        (
            r"\item \textbf{Detection-Conditioned vs.\ Unconditional Min-Entropy Analysis:} We mathematically contrast unconditional private capacity with post-selected entropy conditioned on detector clicks $H_{\min}(X|E, {\rm det}) = \log_2(1+\eta_B)$. We show that post-selection enhances extractable bits per detected photon, but the physical generation rate still collapses in the high-Purcell near field due to severe channel loss.",
            r"\item \textbf{Detection-Conditioned vs.\ Unconditional Min-Entropy Analysis:} We mathematically contrast unconditional private throughput with post-selected entropy conditioned on detector clicks $H_{\min}(X|E, {\rm det}) = \log_2(1+\eta_B)$. We show that post-selection enhances extractable bits per detected photon, but the physical generation rate still collapses in the high-Purcell near field due to severe channel loss."
        ),
        (
            r"\item \textbf{Four-Solver Electrodynamic Benchmark:} We benchmark the channel decomposition across four distinct computational electrodynamic methodologies: semi-analytical Sommerfeld contour integration, three-dimensional conformal FDTD, surface-integral BEM, and finite-element eigenmode (FEEM) waveguide calculations), demonstrating cross-solver numerical agreement within $\le 0.91\%$ discrepancy for planar systems and $<3\%$ for out-of-sample waveguides.",
            r"\item \textbf{Four-Solver Electrodynamic Benchmark:} We benchmark the channel decomposition across four distinct computational electrodynamic methodologies: semi-analytical Sommerfeld contour integration, three-dimensional conformal FDTD, surface-integral BEM, and finite-element eigenmode (FEEM) waveguide calculations, demonstrating cross-solver numerical agreement with a maximum discrepancy of $1.04\%$ across $d \ge 5$\,nm ($\le 0.91\%$ for $d \le 50$\,nm), alongside a cross-geometry numerical consistency test on a dielectric-loaded waveguide agreeing within $<3\%$."
        ),
        (
            r"\item \textbf{Mathematical Invariance of Optimal Separation Distance:} We prove that the platform-matched private capacity $R_{\rm priv}(d) \propto \Gamma_{\rm rad}(d) H_{\min}(X|E; d)$ peaks at a finite separation distance ($d^* \approx 33.8$\,nm for Au, $d^* \approx 17.5$\,nm for Ag) that is strictly invariant to the repetition rate factor $k_{\rm rep}$, detector efficiency $\eta_{\rm det}$, and baseline emitter lifetime $\tau_0$.",
            r"\item \textbf{Parameter Scaling and Invariance of Optimal Separation Distance:} We show that the platform-matched theoretical private throughput peaks at a finite separation distance ($d^* \approx 33.8$\,nm for Au, $d^* \approx 17.5$\,nm for Ag) that is strictly invariant to the repetition rate factor $k_{\rm rep}$, detector efficiency $\eta_{\rm det}$, baseline emitter lifetime $\tau_0$, and path branching fraction $p_1$."
        ),
        # 9. Limiting cases in Section 3
        (
            r"Thus, while raw spontaneous decay accelerates as $d^{-3}$ [Eq.~(\ref{eq:quasistatic_divergence})], the extractable private min-entropy collapses linearly with $\Xi$ as $d^3$.",
            r"Thus, within the local-response asymptotic model, decreasing $d$ drives $\Xi \to 0$; while raw spontaneous decay accelerates as $d^{-3}$ [Eq.~(\ref{eq:quasistatic_divergence})], the extractable private min-entropy collapses linearly with $\Xi$ as $d^3$."
        ),
        (
            r"\item \textbf{Zero-Distance Limit within Local Electrodynamics ($d \to 0$):} Within the formal local model, $\Gamma_{\rm nr} \propto d^{-3} \to \infty$ while $\Gamma_{\rm rad}$ remains bounded, causing $\Xi \propto d^3 \to 0$, $\eta_{\rm rad} \to 0$, and $R_{\rm priv} \to 0$. As noted in Remark~\ref{rem:nonlocality}, nonlocality softens this divergence below 2\,nm, but does not prevent severe near-field quenching.",
            r"\item \textbf{Zero-Distance Limit within Local Electrodynamics ($d \to 0$):} Within the formal local-response asymptotic model, $\Gamma_{\rm nr} \propto d^{-3} \to \infty$ while $\Gamma_{\rm rad}$ remains bounded, causing $\Xi \propto d^3 \to 0$, $\eta_{\rm rad} \to 0$, and $R_{\rm priv} \to 0$. As noted in Remark~\ref{rem:nonlocality}, nonlocality softens this divergence below 2\,nm, but does not prevent severe near-field quenching. In all practical device designs and physical evaluations in this study, separations are strictly restricted to $d \ge 5$\,nm."
        ),
        # 10. Figure 11 caption
        (
            r"\caption{\textbf{Universal scaling collapse of conditional min-entropy onto master curve $\Phi(\Xi)$.} Plot of private conditional min-entropy $H_{\min}(X|E)$ versus the universal dimensionless decay-branching ratio $\Xi \equiv \Gamma_{\rm rad}/(\Gamma_{\rm pl} + \Gamma_{\rm nr})$. Solid curve is the exact analytical prediction $\Phi(\Xi)$ [Eq.~(\ref{eq:hmin_master})]. Numerical data for planar gold (red circles) and planar silver (green squares) across separations $d \in [5, 80]$\,nm collapse onto the analytical curve. Cross-geometry validation data points (orange triangles) computed via FEEM for a dielectric-loaded plasmonic waveguide (DLSPPW; ridge widths $w = 300, 500, 700$\,nm) confirm consistency within $<3\%$ relative discrepancy.}",
            r"\caption{\textbf{Scaling collapse of conditional min-entropy onto master curve $\Phi(\Xi)$ across investigated plasmonic reservoirs.} Plot of private conditional min-entropy $H_{\min}(X|E)$ versus the dimensionless decay-branching ratio $\Xi \equiv \Gamma_{\rm rad}/(\Gamma_{\rm pl} + \Gamma_{\rm nr})$. Solid curve is the exact analytical prediction $\Phi(\Xi)$ [Eq.~(\ref{eq:hmin_master})]. Numerical data for planar gold (red circles) and planar silver (green squares) across separations $d \in [5, 80]$\,nm collapse onto the analytical curve. Cross-geometry numerical consistency data points (orange triangles) computed via FEEM for a dielectric-loaded plasmonic waveguide (DLSPPW; ridge widths $w = 300, 500, 700$\,nm) confirm agreement within $<3\%$ relative discrepancy.}"
        ),
        # 11. Section 5.7 FEEM
        (
            r"This out-of-sample agreement across completely different geometries (planar film vs.\ 3D ridge waveguide) proves that the decay-branching ratio $\Xi$ provides an accurate universal bridge between computational electrodynamics and quantum privacy.",
            r"This out-of-sample consistency across disparate geometries (planar film vs.\ 3D ridge waveguide) confirms the cross-geometry consistency of the decay-branching mapping, showing that constructing $\Xi$ from modal loss ratios reproduces $\Phi(\Xi)$ within $<3\%$ in guided nanophotonic geometries without asserting physical equivalence between localized dipole decay and propagating waveguide modes."
        ),
        # 12. Section 6 discrepancy
        (
            r"The cross-solver discrepancy between FDTD, BEM, and analytical Green-tensor integration remains strictly $\le 0.91\%$ [Fig.~\ref{fig:benchmark}]. Furthermore, the independent FEEM waveguide benchmark reproduces the analytical min-entropy curve within $<3\%$ discrepancy [Fig.~\ref{fig:scaling}].",
            r"The cross-solver discrepancy between FDTD, BEM, and analytical Green-tensor integration exhibits a maximum discrepancy of $1.04\%$ across the tested $d \ge 5$\,nm range ($\le 0.91\%$ for $d \le 50$\,nm) [Fig.~\ref{fig:benchmark}]. Furthermore, the independent FEEM waveguide benchmark provides a cross-geometry numerical consistency test reproducing the analytical min-entropy curve within $<3\%$ discrepancy [Fig.~\ref{fig:scaling}]."
        ),
        (
            r"Over the local-response validity domain ($d \ge 5$\,nm), the maximum deviation is strictly $\le 0.91\%$, proving numerical cross-solver agreement.",
            r"Over the local-response validity domain ($d \ge 5$\,nm), the maximum deviation is $1.04\%$ (occurring at $d = 80$\,nm, with $\le 0.91\%$ for $d \le 50$\,nm), demonstrating high cross-solver numerical agreement."
        ),
        # 13. Table 4 emitter platforms
        (
            r"\caption{\textbf{Projected Private-Randomness Capacities for Representative Solid-State Emitter Platforms.} Maximum platform-matched private capacities $R_{\rm priv}^{\max}$ evaluated for diamond SiV$^-$ centers, diamond NV$^-$ centers, colloidal CdSe/ZnS quantum dots, and single organic dye molecules (DBT in anthracene) coupled to planar gold and silver substrates at $\lambda = 650$\,nm ($k_{\rm rep} = 5$, $\eta_{\rm det} = 0.85$).}",
            r"\caption{\textbf{Model-Predicted Private-Throughput Projections for Representative Emitter Platforms.} Theoretical model projections of maximum platform-matched private-randomness throughputs for solid-state quantum emitters coupled to planar gold and silver substrates at $\lambda = 650$\,nm ($k_{\rm rep} = 5$, $\eta_{\rm det} = 0.85$). Both channel throughput $R_{\rm priv}^{(\rm ch)}$ and net dual-rail arm contribution $R_{\rm priv}^{(\rm arm)} = \frac{1}{2} R_{\rm priv}^{(\rm ch)}$ are shown. These values represent theoretical model-derived ceilings under assumed single-dipole orientation and ideal host matrices rather than experimental QRNG demonstrations.}"
        ),
        # 14. Table 3 Markovian threshold
        (
            r"Markovian Weak-to-Intermediate Coupling} & Emitter linewidth is smaller than plasmonic bath resonance width ($\Gamma_{\rm tot} \ll \Delta\omega_{\rm pl}$) & Valid for $F_P \le 10^3$; excludes vacuum Rabi splitting strong-coupling regime & Lindblad master equation holds; decay rates correspond to stationary LDOS \\",
            r"Markovian Weak-to-Intermediate Coupling} & Emitter linewidth is smaller than plasmonic bath resonance width ($\Gamma_{\rm tot} \ll \Delta\omega_{\rm pl}$) & Requires emitter--reservoir dynamics to remain in weak-to-intermediate coupling, approximately Markovian regime ($\Gamma_{\rm tot} \ll \Delta\omega_{\rm res}$)~\cite{thanopulos2024strong}; strong-coupling regimes exhibiting non-Markovian memory effects or vacuum Rabi splitting are outside present model & Lindblad master equation holds; decay rates correspond to stationary LDOS \\"
        ),
        # 15. Section 9 conclusions
        (
            r"By evaluating adversarial distinguishability under Helstrom's hypothesis testing, we proved that the private conditional min-entropy is governed by an exact closed-form relation: $H_{\min}(X|E) = \log_2[2(1+\Xi)/(2+\Xi)] \equiv \Phi(\Xi)$, parameterized strictly by the dimensionless decay-branching ratio $\Xi \equiv \Gamma_{\rm rad}/(\Gamma_{\rm pl} + \Gamma_{\rm nr})$. We proved that any fine-grained adversarial access to environmental modes can only further reduce extractable privacy, rendering $\Phi(\Xi)$ the most optimistic operational bound.",
            r"By evaluating adversarial distinguishability under Helstrom's hypothesis testing within the open-system channel model, we derived the exact private conditional min-entropy relation: $H_{\min}(X|E) = \log_2[2(1+\Xi)/(2+\Xi)] \equiv \Phi(\Xi)$, parameterized strictly by the dimensionless decay-branching ratio $\Xi \equiv \Gamma_{\rm rad}/(\Gamma_{\rm pl} + \Gamma_{\rm nr})$. We showed that any fine-grained adversarial access to environmental modes can only further reduce extractable privacy, rendering $\Phi(\Xi)$ the most optimistic operational bound."
        ),
        (
            r"Multi-solver computational benchmarks across Sommerfeld dyadic Green-tensor integration, 3D conformal FDTD, surface-integral BEM, and FEEM waveguide solvers confirm cross-solver numerical agreement within $\le 0.91\%$ discrepancy for planar interfaces and $<3\%$ for waveguides.  These findings establish a foundational design principle for open quantum nanophotonics:",
            r"Multi-solver computational benchmarks across Sommerfeld dyadic Green-tensor integration, 3D conformal FDTD, surface-integral BEM, and FEEM waveguide solvers confirm cross-solver numerical agreement with a maximum discrepancy of $1.04\%$ across $d \ge 5$\,nm ($\le 0.91\%$ for $d \le 50$\,nm) and $<3\%$ for guided waveguides. These findings establish a practical design principle for information-aware plasmonic quantum-source optimization:"
        ),
        # 16. Section 7 text
        (
            r"SiV$^-$ centers coupled to silver films at $d^* \approx 14$\,nm yield projected capacities reaching $R_{\rm priv}^{\max} \approx 210$\,Mbps.",
            r"SiV$^-$ centers coupled to silver films at $d^* \approx 14$\,nm yield model-predicted channel throughputs reaching $R_{\rm priv}^{(\rm ch),\max} \approx 210$\,Mbps (net dual-rail arm contribution $R_{\rm priv}^{(\rm arm),\max} \approx 105$\,Mbps)."
        ),
        (
            r"NV$^-$ centers on gold substrates reach $R_{\rm priv}^{\max} \approx 45$\,Mbps at $d^* \approx 34$\,nm.",
            r"NV$^-$ centers on gold substrates yield model-predicted channel throughputs reaching $R_{\rm priv}^{(\rm ch),\max} \approx 45$\,Mbps ($R_{\rm priv}^{(\rm arm),\max} \approx 22.5$\,Mbps) at $d^* \approx 34$\,nm."
        )
    ]

    applied = 0
    for target, repl in replacements:
        if target in content:
            content = content.replace(target, repl)
            applied += 1
        else:
            print(f"WARNING (manuscript): Target not found: {target[:50]}...")

    # Now let's handle the operational rate and Figure 5 caption replacement using regex or direct block replacement
    old_sec4_pattern = r"At this platform-matched clock, the photon flux traversing the plasmonic arm.*?\\end\{proof\}"
    new_sec4_text = r"""In our dual-rail interferometric architecture, input single photons prepared at clock rate $f_{\rm rep}(d)$ encounter the 50:50 beam splitter, branching into Path~0 (lossless reference arm) with probability $p_0 = 1/2$ and Path~1 (plasmonic channel) with probability $p_1 = 1/2$. To provide complete operational clarity, we define two complementary rate metrics:
\begin{enumerate}
    \item \textbf{Plasmonic Channel Theoretical Throughput ($R_{\rm priv}^{(\rm ch)}$):} 
    First, considering the private entropy generated per photon traversing the plasmonic channel (equivalent to evaluating the channel capacity under full occupation $p_1 = 1$), the platform-matched theoretical private-randomness throughput delivered by the plasmonic channel is:
    \begin{equation}
    \boxed{R_{\rm priv}^{(\rm ch)}(d) \equiv \frac{\eta_{\rm det}}{k_{\rm rep}}\,\Gamma_{\rm rad}(d)\,H_{\min}(X|E;\,d) = \frac{\eta_{\rm det}}{k_{\rm rep}}\,\Gamma_{\rm rad}(d)\,\Phi\left(\frac{\Gamma_{\rm rad}(d)}{\Gamma_{\rm pl}(d) + \Gamma_{\rm nr}(d)}\right).}
    \label{eq:r_priv_ch}
    \end{equation}
    For an uncoupled reference emitter ($d \to \infty$, $\Gamma_{\rm rad} = \Gamma_0$, $\Phi = 1$\,bit), the reference channel throughput is $R_0 \equiv \frac{\eta_{\rm det}}{k_{\rm rep}}\Gamma_0 \approx 1.70$\,Mbps. For planar gold, the channel throughput peaks at $R_{\rm priv}^{(\rm ch),\max} \approx 0.201$\,Mbps ($d^* \approx 33.8$\,nm), while for silver it reaches $R_{\rm priv}^{(\rm ch),\max} \approx 0.462$\,Mbps ($d^* \approx 17.5$\,nm).

    \item \textbf{Net Dual-Rail Plasmonic-Arm Contribution ($R_{\rm priv}^{(\rm arm)}$):}
    In the actual dual-rail configuration where photons occupy the plasmonic arm with branching probability $p_1 = 1/2$, the net private generation rate contributed specifically by the plasmonic arm is weighted by $p_1$:
    \begin{equation}
    \boxed{R_{\rm priv}^{(\rm arm)}(d) \equiv p_1\,R_{\rm priv}^{(\rm ch)}(d) = \frac{\eta_{\rm det}}{2 k_{\rm rep}}\,\Gamma_{\rm rad}(d)\,H_{\min}(X|E;\,d) = \frac{\eta_{\rm det}}{2 k_{\rm rep}}\,\Gamma_{\rm rad}(d)\,\Phi(\Xi(d)).}
    \label{eq:r_priv_arm}
    \end{equation}
    Under this arm-weighted definition, the uncoupled reference baseline is $R_0^{(\rm arm)} \equiv p_1 R_0 \approx 0.85$\,Mbps. The peak plasmonic-arm throughput is $R_{\rm priv}^{(\rm arm),\max} \approx 0.101$\,Mbps for planar gold and $R_{\rm priv}^{(\rm arm),\max} \approx 0.231$\,Mbps for silver. At $d = 5$\,nm, the arm rate collapses to $\sim 0.50$\,kbps.
\end{enumerate}

Similarly, the post-selected private generation rate extracted from detected coincidence clicks is obtained by weighting the detection-conditioned min-entropy $H_{\min}(X|E, {\rm det}; d)$ by the detected photon rate in Path~1:
\begin{equation}
R_{\rm priv}^{(\rm det)}(d) \equiv \frac{\eta_{\rm det}}{2 k_{\rm rep}}\,\Gamma_{\rm rad}(d)\,H_{\min}(X|E, {\rm det};\,d) = \frac{\eta_{\rm det}}{2 k_{\rm rep}}\,\Gamma_{\rm rad}(d)\,\log_2\left(1 + \eta_B(d)\right).
\label{eq:r_priv_det}
\end{equation}
Notice that with the explicit inclusion of the branching factor $p_1 = 1/2$, the rate prefactor $\frac{\eta_{\rm det}}{2 k_{\rm rep}}\Gamma_{\rm rad}(d)$ in Eq.~(\ref{eq:r_priv_det}) is mathematically identical to that in the unconditional arm throughput Eq.~(\ref{eq:r_priv_arm}).

\subsection{Normalized Private Throughput and Invariant Relative Scaling}
\label{subsec:normalized_rate}
Normalizing either throughput metric by its respective free-space baseline yields an identical dimensionless ratio:
\begin{equation}
\boxed{\frac{R_{\rm priv}^{(\rm arm)}(d)}{R_0^{(\rm arm)}} = \frac{R_{\rm priv}^{(\rm ch)}(d)}{R_0} = \frac{\Gamma_{\rm rad}(d)}{\Gamma_0}\,\Phi(\Xi(d)).}
\label{eq:normalized_rate}
\end{equation}
Remarkably, the normalized relative throughput in Eq.~(\ref{eq:normalized_rate}) is \textbf{strictly invariant} to whether one considers the channel throughput or the net dual-rail arm contribution, and is completely independent of $\Gamma_0$, $\eta_{\rm det}$, and $k_{\rm rep}$. It depends solely on the electrodynamic decay-channel partitioning of the nanophotonic environment.

\subsection{Parameter Scaling and Invariance of the Optimal Separation}
\label{subsec:invariance_thm}

\begin{theorem}[Parameter Scaling and Invariance of Optimal Separation Distance]
\label{thm:invariance}
Let $R_{\rm priv}^{(\rm ch)}(d)$ and $R_{\rm priv}^{(\rm arm)}(d)$ be the platform-matched theoretical private throughputs defined in Eqs.~(\ref{eq:r_priv_ch}) and~(\ref{eq:r_priv_arm}). The optimal emitter--metal separation distance $d^*$ satisfying $\left.\frac{\partial R_{\rm priv}}{\partial d}\right|_{d^*} = 0$ is strictly invariant to the pulse reset factor $k_{\rm rep}$, detector efficiency $\eta_{\rm det}$, baseline decay rate $\Gamma_0$, and path branching fraction $p_1$.
\end{theorem}
\begin{proof}
Because both $R_{\rm priv}^{(\rm ch)}(d)$ and $R_{\rm priv}^{(\rm arm)}(d)$ factor as $R_{\rm priv}(d) = C \cdot \frac{\Gamma_{\rm rad}(d)}{\Gamma_0} \Phi(\Xi(d))$, where $C > 0$ is a scalar prefactor independent of $d$, the stationarity condition $\frac{\partial R_{\rm priv}}{\partial d} = 0$ is identically equivalent to:
\begin{equation}
\frac{d}{dd}\left[\frac{\Gamma_{\rm rad}(d)}{\Gamma_0} \Phi\left(\frac{\Gamma_{\rm rad}(d)}{\Gamma_{\rm pl}(d) + \Gamma_{\rm nr}(d)}\right)\right] = 0.
\label{eq:invariance_condition}
\end{equation}
Equation~(\ref{eq:invariance_condition}) contains solely the electrodynamic decay rates $\Gamma_{\rm rad}(d)$, $\Gamma_{\rm pl}(d)$, and $\Gamma_{\rm nr}(d)$, which are governed exclusively by Maxwell's equations and material permittivities. Therefore, $d^*$ is an exact invariant of the rate functional with respect to $k_{\rm rep}$, $\eta_{\rm det}$, $\Gamma_0$, and $p_1$.
\end{proof}"""

    sec4_match = re.search(old_sec4_pattern, content, re.DOTALL)
    if sec4_match:
        content = content[:sec4_match.start()] + new_sec4_text + content[sec4_match.end():]
        applied += 1
        print("Replaced Section 4 block successfully!")
    else:
        print("WARNING: Could not find Section 4 block!")

    # Figure 5 caption replacement
    old_fig5_pattern = r"\\caption\{\\textbf\{Purcell enhancement does not determine private-randomness performance\.\}.*?\\label\{fig:rate_vs_purcell\}"
    new_fig5_text = r"""\caption{\textbf{Private-randomness throughput versus Purcell enhancement and emitter--metal separation.} Model-predicted theoretical private throughput versus \textbf{(a)} Purcell factor $F_P$ and \textbf{(b)} separation distance $d$ for planar gold (red solid curve, $d^* \approx 33.8$\,nm, $F_P^* \approx 4.02$, $R_{\rm priv}^{(\rm ch),\max} \approx 0.201$\,Mbps, $R_{\rm priv}^{(\rm arm),\max} \approx 0.101$\,Mbps) and planar silver (green dashed curve, $d^* \approx 17.5$\,nm, $F_P^* \approx 3.41$, $R_{\rm priv}^{(\rm ch),\max} \approx 0.462$\,Mbps, $R_{\rm priv}^{(\rm arm),\max} \approx 0.231$\,Mbps) at $\lambda = 650$\,nm ($\Gamma_0 = 10^7$\,s$^{-1}$, $\eta_{\rm det} = 0.85$, $k_{\rm rep} = 5$). In (a), the curve traces a parametric trajectory with decreasing separation distance $d$ indicated by arrows. In (b), shaded areas highlight the uncollected environmental loss channels (guided SPP in blue, Ohmic dissipation in gray) that cause the collapse of private throughput in the extreme near field ($d < 15$\,nm). The uncoupled free-space reference throughput is $R_0 = 1.70$\,Mbps ($R_0^{(\rm arm)} = 0.85$\,Mbps). Both channel throughput $R_{\rm priv}^{(\rm ch)}$ and dual-rail arm contribution $R_{\rm priv}^{(\rm arm)}$ scale identically.}
\label{fig:rate_vs_purcell}"""

    fig5_match = re.search(old_fig5_pattern, content, re.DOTALL)
    if fig5_match:
        content = content[:fig5_match.start()] + new_fig5_text + content[fig5_match.end():]
        applied += 1
        print("Replaced Figure 5 caption successfully!")
    else:
        print("WARNING: Could not find Figure 5 caption!")

    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

    print(f"Total replacements in write_manuscript.py: {applied}")

def update_supplementary():
    path = "scripts/write_supplementary.py"
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()

    replacements = [
        # S3 mesh description
        (
            r"$0.25$ & $24.20$ & $0.83\%$ & $0.069$ & Fully converged (production) \\",
            r"$0.25$ & $24.20$ & $0.83\%$ & $0.069$ & Production mesh (sub-1\% numerical difference) \\"
        ),
        (
            r"The 0.25-nm mesh is fully converged",
            r"The 0.25-nm mesh serves as our production mesh (sub-1\% numerical difference)"
        ),
        # S5 FEEM clarification
        (
            r"The modal branching ratio $\Xi_{\rm wg} = \Gamma_{\rm rad}^{(\rm wg)} / \Gamma_{\rm nr}^{(\rm wg)}$ was evaluated for ridge widths $w = 300, 500, 700$\,nm without reference to $\Phi(\Xi)$. As shown in main-text Fig.~4, the resulting points agree with $\Phi(\Xi)$ within $<3\%$ relative discrepancy.",
            r"""The modal branching ratio $\Xi_{\rm wg} = \Gamma_{\rm rad}^{(\rm wg)} / \Gamma_{\rm nr}^{(\rm wg)}$ was evaluated for ridge widths $w = 300, 500, 700$\,nm without reference to $\Phi(\Xi)$. As shown in main-text Fig.~4, the resulting points agree with $\Phi(\Xi)$ within $<3\%$ relative discrepancy.

\subsection{Interpretation as Cross-Geometry Numerical Consistency Test}
We emphasize that $\Gamma_{\rm rad}^{(\rm wg)}$ and $\Gamma_{\rm nr}^{(\rm wg)}$ are waveguide modal propagation metrics characterizing spatial attenuation and leakage of a guided mode, rather than localized spontaneous-decay rates of a point quantum dipole. Consequently, the FEEM calculation is not presented as an experimental or universal demonstration that localized dipole emission and propagating modes are physically identical. Instead, it serves as an out-of-sample cross-geometry numerical consistency test of the branching-ratio mapping $\Xi$. It demonstrates that when an effective loss parameter $\Xi$ is constructed from electrodynamic modal loss ratios in an independent guided nanophotonic geometry, evaluating the channel model $\Phi(\Xi)$ yields values consistent with the master curve within $<3\%$, confirming the mathematical consistency and portability of the branching-ratio formulation."""
        ),
        # S6 Dual-rail arm rate clarification
        (
            r"The isometry condition $V^\dagger V = \mathbb{I}_{\rm opt}$ holds identically:",
            r"""\subsection{Dual-Rail Architecture Branching Probability and Rate Definitions}
In the balanced dual-rail spatial architecture, single photons prepared by the 50:50 coupler enter Path~0 (reference arm) with probability $p_0 = 1/2$ and Path~1 (plasmonic arm) with probability $p_1 = 1/2$. We explicitly distinguish:
\begin{enumerate}
    \item The \textbf{plasmonic channel throughput} $R_{\rm priv}^{(\rm ch)}(d) \equiv \frac{\eta_{\rm det}}{k_{\rm rep}} \Gamma_{\rm rad}(d) H_{\min}(X|E; d)$, which measures the private entropy generation rate per photon traversing the plasmonic channel (equivalent to full occupation $p_1 = 1$).
    \item The \textbf{net plasmonic-arm contribution throughput} $R_{\rm priv}^{(\rm arm)}(d) \equiv p_1 R_{\rm priv}^{(\rm ch)}(d) = \frac{\eta_{\rm det}}{2 k_{\rm rep}} \Gamma_{\rm rad}(d) H_{\min}(X|E; d)$, which accounts for the $p_1 = 1/2$ occupation fraction of Path~1 in the interferometer.
    \item The \textbf{post-selected private generation rate} $R_{\rm priv}^{(\rm det)}(d) \equiv \frac{\eta_{\rm det}}{2 k_{\rm rep}} \Gamma_{\rm rad}(d) \log_2(1 + \eta_B(d))$.
\end{enumerate}
Crucially, because $p_1 = 1/2$ is a constant prefactor, the normalized relative throughput:
\begin{equation}
\frac{R_{\rm priv}^{(\rm arm)}(d)}{R_0^{(\rm arm)}} = \frac{R_{\rm priv}^{(\rm ch)}(d)}{R_0} = \frac{\Gamma_{\rm rad}(d)}{\Gamma_0} \Phi(\Xi(d))
\end{equation}
is identically independent of whether the channel throughput or arm-weighted throughput is considered, leaving the optimal distance $d^*$, Purcell factor $F_P^*$, and relative near-field collapse unchanged.

\subsection{Isometry and Joint Post-Channel State}
The isometry condition $V^\dagger V = \mathbb{I}_{\rm opt}$ holds identically:"""
        )
    ]

    applied = 0
    for target, repl in replacements:
        if target in content:
            content = content.replace(target, repl)
            applied += 1
        else:
            print(f"WARNING (SI): Target not found: {target[:50]}...")

    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

    print(f"Total replacements in write_supplementary.py: {applied}")

if __name__ == "__main__":
    update_manuscript()
    update_supplementary()
    print("Script modifications completed successfully!")

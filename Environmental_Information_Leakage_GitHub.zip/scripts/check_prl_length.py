import re
import os

with open('02_PRL_SUBMISSION/PRL_submission.tex', 'r', encoding='utf-8') as f:
    text = f.read()

# Strip comments
text = re.sub(r'%.*?\n', '\n', text)

# Extract main body between \maketitle and acknowledgments/bibliography
body_match = re.search(r'\\maketitle(.*?)(?:\\begin\{acknowledgments\}|\\bibliography|\\begin\{thebibliography\})', text, re.DOTALL)
if body_match:
    body = body_match.group(1)
else:
    body = text

# Count display equations
equations = re.findall(r'\\begin\{(?:equation|align)\*?\}(.*?)\\end\{(?:equation|align)\*?\}', body, re.DOTALL)
num_eq_lines = 0
for eq in equations:
    num_eq_lines += max(1, len([l for l in eq.strip().split(r'\\') if l.strip()]))
eq_words = num_eq_lines * 16

# Count figures and tables
figures = re.findall(r'\\begin\{figure\*?\}(.*?)\\end\{figure\*?\}', body, re.DOTALL)
tables = re.findall(r'\\begin\{table\*?\}(.*?)\\end\{table\*?\}', body, re.DOTALL)

# Remove figures, tables, equations
clean_body = re.sub(r'\\begin\{(?:figure|table)\*?\}.*?\\end\{(?:figure|table)\*?\}', '', body, re.DOTALL)
clean_body = re.sub(r'\\begin\{(?:equation|align)\*?\}.*?\\end\{(?:equation|align)\*?\}', '', clean_body, re.DOTALL)

# Remove LaTeX commands, math, formatting
clean_body = re.sub(r'\\[a-zA-Z]+(\[[^\]]*\])?(\{[^}]*\})?', ' ', clean_body)
clean_body = re.sub(r'[{}]', ' ', clean_body)
clean_body = re.sub(r'\$[^$]+\$', ' math ', clean_body)

words = clean_body.split()
text_word_count = len(words)

# APS estimate: ~170 words per single-column figure, ~80 words per table
fig_words = len(figures) * 170
tbl_words = len(tables) * 80

total_words = text_word_count + eq_words + fig_words + tbl_words

print(f"Text words: {text_word_count}")
print(f"Equations: {len(equations)} ({num_eq_lines} rows -> {eq_words} words)")
print(f"Figures: {len(figures)} -> {fig_words} words")
print(f"Tables: {len(tables)} -> {tbl_words} words")
print(f"TOTAL APS PRL WORD COUNT ESTIMATE: {total_words} / 3750 words")

import re
import subprocess
import pypdf

# 1. Read PRL_submission.tex
with open("02_PRL_SUBMISSION/PRL_submission.tex", "r", encoding="utf-8") as f:
    tex = f.read()

# Let's see the sequence of 48 references:
# Intro 1: pironio2010random, colbeck2012free
# Intro 2: acin2012randomness, ma2016quantum, herrero2017quantum
# Intro 3: drahi2020certified, jones2026certified
# Intro 4: jennewein2000fast, stefanov2000optical, soorat2017random
# Intro 5: avesani2018source, soorat2026interferometric, sajeev2024advancing
# Intro 6: smith2025noise, shaliq2026quantum, singh2026quantum
# Intro 7: lounis2005single, senellart2017high
# Intro 8: wang2019towards, tomm2021bright
# Intro 9: akselrod2014probing, chikkaraddy2016single
# Intro 10: hoang2015ultrafast, kanli2026purcell
# Intro 11: priyanka2026numerical, priyanka2026design
# Channel/purification: devetak2005distillation, wilde2013quantum
# Qubit control: damodarakurup2024concatenated
# Min-entropy: konig2009operational, tomamichel2011leftover
# Macro QED: dung1998spontaneous, dung2000decay, scheel2008macroscopic
# Lindblad: breuer2002theory
# LDOS/decay: chance1978molecular, ford1984electrodynamic
# Quenching/Ohmic: samir2018fluorescence, martirez2026optical
# Nonlocal: raza2015nonlocal, mortensen2014generalized
# Suppmat: suppmat
# Solvers: hohenester2012mnpbem
# Diamond/sources: tan2024diamond, aharonovich2016solid, zheng2026hthp, malykhin2022control
# Repo: repo

# That is exactly 48 verified references!

target_intro = r"""\emph{Introduction.}---Quantum random number generation (QRNG) is a
fundamental primitive for quantum cryptography and secure communications~\cite{pironio2010random,colbeck2012free}.
Certified private randomness is extracted via device-independent protocols~\cite{acin2012randomness,ma2016quantum,herrero2017quantum}, with physical entropy bounds derived under quantum speed limits~\cite{drahi2020certified,jones2026certified}.
Optical implementations exploit spatial beamsplitters and photon statistics to generate unbiased bits~\cite{jennewein2000fast,stefanov2000optical,soorat2017random}.
Practical systems employ source-independent detection~\cite{avesani2018source}, interferometric Michelson geometries~\cite{soorat2026interferometric}, or Mach--Zehnder architectures~\cite{sajeev2024advancing}, while integrated photonic chips achieve noise-rejecting randomness~\cite{smith2025noise,shaliq2026quantum} and high-rate entropy extraction~\cite{singh2026quantum}.
Solid-state single-photon emitters coupled to nanophotonics provide a deterministic hardware basis~\cite{lounis2005single,senellart2017high}, demonstrated in polarized microcavities~\cite{wang2019towards,tomm2021bright}.
Plasmonic Purcell enhancement, compressing optical modes into deep sub-diffraction volumes ($F_P \sim 10^2$--$10^4$)~\cite{akselrod2014probing,chikkaraddy2016single}, enables ultrafast radiative decay~\cite{hoang2015ultrafast,kanli2026purcell}.
Consequently, plasmonic coupling of quantum dots has been widely explored for low-threshold nanolasers and accelerated quantum light sources~\cite{priyanka2026numerical,priyanka2026design}."""

# Find current intro block
p1 = tex.find(r'\emph{Introduction.}---')
p2 = tex.find(r'\begin{figure}[t]')
tex = tex[:p1] + target_intro + "\n\n" + tex[p2:]

# Update nonlocal citation
p_nl = re.search(r'Because hydrodynamic nonlocality.*?serve solely as computational stress tests\.', tex, re.DOTALL)
if p_nl:
    new_nl = r'Because hydrodynamic nonlocality, electron spill-out, and quantum tunnelling soften near-field divergences for $d \lesssim 1$--$3$\,nm~\cite{raza2015nonlocal,mortensen2014generalized}, all physical conclusions and Proposition~1 are conservatively restricted to $d \ge 5$\,nm; calculations below 5\,nm serve solely as computational stress tests.'
    tex = tex[:p_nl.start()] + new_nl + tex[p_nl.end():]

# Update outlook diamond citations
p_out = re.search(r'Integration of single diamond color centers.*?platform candidates~\\cite\{gras2021quantum\}\.', tex, re.DOTALL)
if p_out:
    new_out = r'Diamond color centers integrated with nanophotonics offer a robust physical architecture~\cite{tan2024diamond,aharonovich2016solid}. Silicon-vacancy (SiV$^-$) centers exhibit narrow transitions and long coherence~\cite{zheng2026hthp,malykhin2022control}, making them promising platform candidates.'
    tex = tex[:p_out.start()] + new_out + tex[p_out.end():]

# Ensure repo citation is clean
tex = re.sub(r'in the project repository~\\cite\{[^}]+\}\.', r'in the project repository~\\cite{repo}.', tex)

with open("02_PRL_SUBMISSION/PRL_submission.tex", "w", encoding="utf-8") as f:
    f.write(tex)

# Recompile
subprocess.run(["bibtex", "PRL_submission"], cwd="02_PRL_SUBMISSION", capture_output=True)
subprocess.run(["pdflatex", "-interaction=nonstopmode", "PRL_submission.tex"], cwd="02_PRL_SUBMISSION", capture_output=True)
subprocess.run(["pdflatex", "-interaction=nonstopmode", "PRL_submission.tex"], cwd="02_PRL_SUBMISSION", capture_output=True)

r = pypdf.PdfReader("02_PRL_SUBMISSION/PRL_submission.pdf")
print(f"Compiled page count: {len(r.pages)}")
for i, p in enumerate(r.pages):
    print(f"Page {i+1}: length={len(p.extract_text())}")

import json
import re

with open('scripts/reference_verification_report.json', 'r', encoding='utf-8') as f:
    report = json.load(f)

print(f"Total reports: {len(report)}")
for item in report:
    k = item['key']
    bib_t = item['bib_title']
    bib_a = item['bib_author']
    bib_doi = item['bib_doi']
    bib_y = item['bib_year']
    bib_j = item['bib_journal']
    
    cr = item.get('crossref_doi_res', {})
    cr_t = cr.get('title')
    cr_a = cr.get('authors')
    cr_y = cr.get('year')
    cr_j = cr.get('journal')
    cr_doi = cr.get('doi')
    
    # Check title equality
    t1 = re.sub(r'[^a-z0-9]', '', bib_t.lower())
    t2 = re.sub(r'[^a-z0-9]', '', (cr_t or '').lower())
    
    # Let's check diff
    if t1 != t2:
        print(f"Key: {k}")
        print(f"  BIB Title: {bib_t}")
        print(f"  CR  Title: {cr_t}")
        print(f"  DOI:       {bib_doi}")
        print()

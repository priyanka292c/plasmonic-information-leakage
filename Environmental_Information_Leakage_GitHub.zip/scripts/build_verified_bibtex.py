import json
import re

# Load retrieved papers from Crossref search
with open("scripts/retrieved_papers.json", "r", encoding="utf-8") as f:
    papers = json.load(f)

# Verified Ram Soorat & Priyanka papers
soorat_papers = [
    {
        "title": "Interferometric Quantum Random Number Generation via Michelson Configuration",
        "authors": [{"given": "Ram", "family": "Soorat"}, {"given": "Aakash", "family": "Chilakamarri"}, {"given": "Priyanka", "family": "Priyanka"}, {"given": "Barath Sai Kumar", "family": "Jakkuva"}, {"given": "Syed", "family": "Areebuddin"}],
        "journal": "International Journal of Theoretical Physics",
        "year": 2026,
        "volume": "65",
        "page": "128",
        "doi": "10.1007/s10773-026-06369-3"
    },
    {
        "title": "Numerical Design of Gold Nanostar Plasmonic Nanolasers Coupled to Quantum Dots for Low-Threshold Lasing",
        "authors": [{"given": "Priyanka", "family": "Priyanka"}, {"given": "Ram", "family": "Soorat"}],
        "journal": "Plasmonics",
        "year": 2026,
        "volume": "21",
        "page": "452",
        "doi": "10.1007/s11468-026-03462-5"
    },
    {
        "title": "Design and numerical analysis of hybrid plasmonic–photonic crystal quantum-dot nanolasers with enhanced spontaneous emission",
        "authors": [{"given": "Priyanka", "family": "Priyanka"}, {"given": "Ravindar", "family": "Tadi"}, {"given": "Ram", "family": "Soorat"}],
        "journal": "Nano Trends",
        "year": 2026,
        "volume": "6",
        "page": "100233",
        "doi": "10.1016/j.nwnano.2026.100233"
    },
    {
        "title": "Advancing Quantum Technology: Insights Form Mach-Zehnder Interferometer in Quantum State Behaviour and Error Correction",
        "authors": [{"given": "Damodarakurup", "family": "Sajeev"}, {"given": "Shaik", "family": "Ahmed"}, {"given": "Shankar", "family": "Pidishety"}, {"given": "Ram", "family": "Soorat"}],
        "journal": "Journal of Quantum Computing",
        "year": 2024,
        "volume": "6",
        "page": "54000",
        "doi": "10.32604/jqc.2024.054000"
    },
    {
        "title": "Concatenated open-loop control for higher-order photon polarization qubit decoherence",
        "authors": [{"given": "S.", "family": "Damodarakurup"}, {"given": "B.", "family": "Alif"}, {"given": "C.", "family": "Bhadranandan"}, {"given": "J. P.", "family": "Ulahannan"}, {"given": "R.", "family": "Soorat"}],
        "journal": "Indian Journal of Physics",
        "year": 2024,
        "volume": "98",
        "page": "3112",
        "doi": "10.1007/s12648-024-03112-8"
    },
    {
        "title": "Random number generator for cryptography",
        "authors": [{"given": "R.", "family": "Soorat"}, {"given": "K.", "family": "Madhuri"}, {"given": "A.", "family": "Vudayagiri"}],
        "journal": "Nanosystems: Physics, Chemistry, Mathematics",
        "year": 2017,
        "volume": "8",
        "page": "600--605",
        "doi": "10.17586/2220-8054-2017-8-5-600-605"
    }
]

# Combine and deduplicate
all_list = soorat_papers + []
seen_dois = {p['doi'].lower() for p in soorat_papers}

# Clean titles and authors from retrieved papers
for p in papers:
    doi = p.get('doi', '').lower().strip()
    title = p.get('title', '').strip()
    journal = p.get('journal', '').strip()
    year = p.get('year')
    authors_raw = p.get('authors', [])
    
    # Filter out corrections / non-articles
    if 'correction' in title.lower() or 'preface' in title.lower():
        continue
    if 'arxiv' in journal.lower() or 'biorxiv' in journal.lower():
        continue
    if doi in seen_dois:
        continue
    if not title or not journal or not year or not authors_raw:
        continue
        
    formatted_authors = []
    for a in authors_raw:
        if isinstance(a, dict):
            formatted_authors.append(a)
        elif isinstance(a, str):
            parts = a.split()
            if len(parts) >= 2:
                formatted_authors.append({'given': ' '.join(parts[:-1]), 'family': parts[-1]})
            else:
                formatted_authors.append({'given': '', 'family': a})
                
    all_list.append({
        'title': title,
        'authors': formatted_authors,
        'journal': journal,
        'year': year,
        'volume': p.get('volume', ''),
        'page': p.get('pages', ''),
        'doi': p.get('doi', '').strip()
    })
    seen_dois.add(doi)

print(f"Total curated and verified unique papers: {len(all_list)}")

# Save curated json
with open("scripts/curated_40_plus_papers.json", "w", encoding="utf-8") as f:
    json.dump(all_list, f, indent=2)

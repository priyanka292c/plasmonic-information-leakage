import subprocess
import pypdf

# 1. Update references.bib with apsrev42Control
with open('02_PRL_SUBMISSION/references.bib', 'r', encoding='utf-8') as f:
    bib = f.read()

control = '@CONTROL{apsrev42Control,author="08",editor="1",pages="0",title="-1",year="1"}\n'
if '@CONTROL{apsrev42Control' not in bib:
    bib = control + bib
    with open('02_PRL_SUBMISSION/references.bib', 'w', encoding='utf-8') as f:
        f.write(bib)

# 2. Add nocite in tex
with open('02_PRL_SUBMISSION/PRL_submission.tex', 'r', encoding='utf-8') as f:
    tex = f.read()

if 'apsrev42Control' not in tex:
    tex = tex.replace('\\begin{document}', '\\begin{document}\n\\nocite{apsrev42Control}')
    with open('02_PRL_SUBMISSION/PRL_submission.tex', 'w', encoding='utf-8') as f:
        f.write(tex)

# 3. Run bibtex and pdflatex
subprocess.run(['bibtex', 'PRL_submission'], cwd='02_PRL_SUBMISSION', capture_output=True)
subprocess.run(['pdflatex', '-interaction=nonstopmode', 'PRL_submission.tex'], cwd='02_PRL_SUBMISSION', capture_output=True)
subprocess.run(['pdflatex', '-interaction=nonstopmode', 'PRL_submission.tex'], cwd='02_PRL_SUBMISSION', capture_output=True)

r = pypdf.PdfReader('02_PRL_SUBMISSION/PRL_submission.pdf')
print('Page count with title=-1:', len(r.pages))
for i, p in enumerate(r.pages):
    print(f'Page {i+1}: length={len(p.extract_text())}')

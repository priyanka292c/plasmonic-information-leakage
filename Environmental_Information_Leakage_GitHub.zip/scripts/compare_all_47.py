import json
import re

with open('scripts/reference_verification_report.json', 'r', encoding='utf-8') as f:
    report = json.load(f)

with open('scripts/all_47_compared.txt', 'w', encoding='utf-8') as out:
    for i, item in enumerate(report, 1):
        k = item['key']
        bib_t = item['bib_title']
        bib_a = item['bib_author']
        bib_doi = item['bib_doi']
        bib_y = item['bib_year']
        bib_j = item['bib_journal']
        
        cr = item.get('crossref_doi_res', {})
        cr_t = cr.get('title')
        cr_a = cr.get('authors')
        cr_y = cr.get('year')
        cr_j = cr.get('journal')
        cr_doi = cr.get('doi')
        
        out.write(f"[{i:02d}] {k}\n")
        out.write(f"     BIB: '{bib_t}' | '{bib_doi}' | '{bib_j}' ({bib_y})\n")
        out.write(f"          Author: {bib_a}\n")
        if cr.get('status') == 'ok':
            out.write(f"     CR : '{cr_t}' | '{cr_doi}' | '{cr_j}' ({cr_y})\n")
            out.write(f"          Author: {cr_a}\n")
        else:
            out.write(f"     CR : FAILED ({cr.get('error')})\n")
        out.write("\n")

import re

with open("02_PRL_SUBMISSION/references.bib", "r", encoding="utf-8") as f:
    bib = f.read()

# Fix \\& to \&
bib = bib.replace(r"\\&", r"\&")

# Fix unicode characters
bib = bib.replace("−", "-")
bib = bib.replace("–", "--")
bib = bib.replace("—", "---")
bib = bib.replace("“", "``").replace("”", "''")
bib = bib.replace("’", "'").replace("‘", "'")

with open("02_PRL_SUBMISSION/references.bib", "w", encoding="utf-8") as f:
    f.write(bib)

print("Cleaned up references.bib syntax.")

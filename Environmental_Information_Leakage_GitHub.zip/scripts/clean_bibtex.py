import re

def clean_bib(filename):
    with open(filename, 'r', encoding='utf-8', errors='replace') as f:
        text = f.read()
    
    replacements = {
        'Ö': '{\\"O}', 'ö': '{\\"o}',
        'Ü': '{\\"U}', 'ü': '{\\"u}',
        'Ä': '{\\"A}', 'ä': '{\\"a}',
        'É': "{\\'E}", 'é': "{\\'e}",
        'È': "{\\`E}", 'è': "{\\`e}",
        'á': "{\\'a}", 'à': "{\\`a}",
        'í': "{\\'i}", 'ó': "{\\'o}",
        'ú': "{\\'u}", 'ñ': '{\\~n}',
        'ç': '{\\c{c}}', 'ß': '{\\ss}',
        '’': "'", '‘': "'", '“': '"', '”': '"',
        '–': '--', '—': '---'
    }
    for k, v in replacements.items():
        text = text.replace(k, v)
    
    # Strip any remaining non-ascii characters
    text = re.sub(r'[^\x00-\x7F]+', '', text)
    
    with open(filename, 'w', encoding='ascii') as f:
        f.write(text)
    print(f"Cleaned {filename}")

targets = [
    '07_REFERENCES/references.bib',
    '01_MASTER_MANUSCRIPT/references.bib',
    '02_PRL_SUBMISSION/references.bib',
    '02_PRL_SUBMISSION/supplementary/references.bib'
]

for t in targets:
    clean_bib(t)

print("All BibTeX files cleaned to strict ASCII.")

import urllib.request
import urllib.parse
import json
import time

headers = {'User-Agent': 'PRLReferenceVerifier/1.0 (mailto:ram.soorat@woxsen.edu.in)'}

def query_crossref(query, rows=15):
    encoded = urllib.parse.quote(query)
    url = f"https://api.crossref.org/works?query={encoded}&rows={rows}&filter=type:journal-article"
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=15) as res:
            data = json.loads(res.read().decode('utf-8'))
            items = data['message']['items']
            results = []
            for it in items:
                doi = it.get('DOI', '')
                title = it.get('title', [''])[0]
                container = it.get('container-title', [''])
                journal = container[0] if container else ''
                year = None
                for yf in ['published-print', 'published-online', 'created']:
                    if yf in it and 'date-parts' in it[yf]:
                        year = it[yf]['date-parts'][0][0]
                        if year:
                            break
                volume = it.get('volume', '')
                issue = it.get('issue', '')
                pages = it.get('page', '')
                authors = []
                for a in it.get('author', []):
                    g = a.get('given', '')
                    f = a.get('family', '')
                    if f:
                        authors.append(f"{g} {f}".strip())
                
                # Filter out arxiv, ensure valid doi and recent year
                if doi and title and journal and year and year >= 2018:
                    if 'arxiv' not in journal.lower() and 'biorxiv' not in journal.lower() and 'medrxiv' not in journal.lower():
                        results.append({
                            'doi': doi,
                            'title': title,
                            'journal': journal,
                            'year': year,
                            'volume': volume,
                            'issue': issue,
                            'pages': pages,
                            'authors': authors
                        })
            return results
    except Exception as e:
        print(f"Error querying {query}: {e}")
        return []

# Search topics
queries = [
    "quantum random number generation photonic",
    "certified quantum randomness min-entropy",
    "source-device-independent quantum random number generator",
    "Purcell enhancement lossy plasmonic single photon",
    "spontaneous emission quenching metallic surface nanophotonics",
    "quantum dot plasmonic Purcell effect",
    "diamond color center SiV NV plasmonic Purcell",
    "nanophotonic quantum random number generator chip"
]

all_papers = {}
for q in queries:
    print(f"Querying: {q}...")
    res = query_crossref(q, rows=15)
    for p in res:
        if p['doi'] not in all_papers:
            all_papers[p['doi']] = p
    time.sleep(1)

print(f"\nTotal unique recent peer-reviewed papers retrieved: {len(all_papers)}")
with open("scripts/retrieved_papers.json", "w", encoding="utf-8") as f:
    json.dump(list(all_papers.values()), f, indent=2)

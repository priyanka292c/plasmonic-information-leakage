import re
import subprocess
import pypdf

# Load original clean PRL_submission.tex
with open("02_PRL_SUBMISSION/PRL_submission.tex", "r", encoding="utf-8") as f:
    text = f.read()

# Let's restore the exact original text of the intro first to make clean replacements
# Replace introduction with streamlined sequential citations
new_intro = r"""\emph{Introduction.}---Quantum random number generation (QRNG) is a fundamental primitive for quantum cryptography and secure communications~\cite{pironio2010random,colbeck2012free}.
Certified private randomness can be extracted via device-independent and semi-device-independent frameworks~\cite{acin2012randomness,ma2016quantum}, with physical entropy bounds derived under quantum principles~\cite{herrero2017quantum,soorat2017random}.
Security against adversarial side information can be bounded using speed limits and entropic relations~\cite{drahi2020certified,jones2026certified}, while randomness expansion certifies untrusted devices~\cite{mahato2026certified,adamson2020quantum}.
Solid-state single-photon emitters coupled to nanophotonics provide a deterministic hardware basis for quantum randomness~\cite{lounis2005single,senellart2017high}.
High-brightness single photons have been achieved in microcavities~\cite{wang2019towards,tomm2021bright} and integrated waveguides~\cite{uppu2020scalable,li2022photonic}.
In a dual-rail / which-path nanophotonic QRNG, single photons enter an optical 50:50 superposition across two spatial paths, with user Alice detecting path outcomes $X \in \{0, 1\}$~\cite{jennewein2000fast,stefanov2000optical}.
Practical implementations employ source-device-independent heterodyne detection~\cite{avesani2018source} or multiplexed spatial modes~\cite{haylock2019multiplexed} to reach gigabit rates.
Recently, interferometric Michelson configurations have demonstrated high-speed randomness generation~\cite{soorat2026interferometric}, while Mach--Zehnder architectures clarify spatial state behavior~\cite{sajeev2024advancing}.
Optical self-testing and source-independent detection have further mitigated detector mismatch~\cite{ma2020practical,petrov2022independent}, while integrated photonic chips achieve noise-rejecting randomness~\cite{smith2025noise,shaliq2026quantum}.
Multi-bit quantum walks~\cite{sarkar2019multi} and high-rate entropy extraction pipelines~\cite{solymos2020real,singh2026quantum} underscore the technological relevance of photonic QRNG.
The operational generation rate is paced by the emitter clock repetition rate, which is bounded by the spontaneous emission lifetime.
Plasmonic Purcell enhancement, compressing optical modes into deep sub-diffraction volumes with Purcell factors $F_P\sim 10^2$--$10^4$~\cite{akselrod2014probing,chikkaraddy2016single}, enables ultrafast radiative decay~\cite{hoang2015ultrafast,kanli2026purcell}.
Hybrid plasmonic--photonic resonators further accelerate emission~\cite{cao2020chiral,azzam2023purcell}, as demonstrated in silicon-integrated emitters~\cite{gritsch2023purcell} and cavity QED systems~\cite{wang2021cavity}.
Consequently, plasmonic coupling of quantum dots has been widely explored for low-threshold nanolasers and accelerated quantum light sources~\cite{priyanka2026numerical,priyanka2026design}."""

# Replace the intro block
m = re.search(r'\\emph\{Introduction\.\}---.*?(?=In this Letter, we demonstrate)', text, re.DOTALL)
if m:
    text = text[:m.start()] + new_intro + "\n\n" + text[m.end():]
    print("Replaced introduction.")
else:
    print("Could not match intro block.")

with open("02_PRL_SUBMISSION/PRL_submission.tex", "w", encoding="utf-8") as f:
    f.write(text)

print("Saved updated PRL_submission.tex.")

"""
Script to write the complete, enhanced supplementary_information.tex for Springer Plasmonics.
Addresses all 20 reviewer points with comprehensive derivations, tables, and physical discussions.
"""
import os

si_content = r"""% =========================================================================
% Springer Journal: Plasmonics
% Supplementary Information (SI)
%
% Title: Plasmonic Purcell Enhancement versus Environmental Information
%        Leakage in Private Quantum Randomness Generation
% Authors: Priyanka and Ram Soorat
% =========================================================================
\documentclass[11pt,a4paper]{article}

\usepackage[margin=2.2cm,top=2.0cm,bottom=2.0cm]{geometry}
\usepackage{amsmath,amssymb,amsfonts,amsthm}
\usepackage{graphicx}
\usepackage{dcolumn}
\usepackage{bm}
\usepackage{cite}
\usepackage{hyperref}
\usepackage{color}
\usepackage{microtype}
\usepackage{booktabs}
\usepackage{array}
\usepackage{caption}

\hypersetup{
    colorlinks=true,
    linkcolor=blue,
    citecolor=blue,
    urlcolor=blue
}

\renewcommand{\thesection}{S\arabic{section}}
\renewcommand{\theequation}{S\arabic{equation}}
\renewcommand{\thefigure}{S\arabic{figure}}
\renewcommand{\thetable}{S\arabic{table}}

\linespread{1.15}

\begin{document}

\begin{center}
    {\Large\textbf{Supplementary Information for:}}\\[8pt]
    {\Large\textbf{``Plasmonic Purcell Enhancement versus Environmental Information Leakage\\in Private Quantum Randomness Generation''}}\\[16pt]
    \textbf{Priyanka}$^1$ \quad and \quad \textbf{Ram Soorat}$^{2,*}$\\[6pt]
    $^1$Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India\\[2pt]
    $^2$School of Technology, Woxsen University, Hyderabad, Telangana 502345, India\\[2pt]
    $^*$Corresponding author: \href{mailto:ram.soorat@woxsen.edu.in}{ram.soorat@woxsen.edu.in}
\end{center}

\vspace{1.5em}
\hrule
\vspace{1.5em}

\tableofcontents

\newpage

% =========================================================================
% SECTION S1
% =========================================================================
\section{Macroscopic Quantum Electrodynamics and Dyadic Green's Tensors}
\label{sec:s1_mqed}

In this section, we provide the foundational derivation of macroscopic quantum electrodynamics (QED) in dispersing and absorbing media, establishing the rigorous connection between the dyadic Green's tensor and the emitter's decay rate.

\subsection{Canonical Quantization in Dispersing and Absorbing Media}
In the presence of absorbing media with complex relative permittivity $\varepsilon(\mathbf{r}, \omega) = \varepsilon_r(\mathbf{r}, \omega) + i \varepsilon_i(\mathbf{r}, \omega)$ satisfying Kramers--Kronig causality relations, canonical quantization requires coupling the electromagnetic field to a continuous reservoir of harmonic oscillators representing material polarization noise~\cite{dung1998spontaneous,scheel2008macroscopic}. The electric field operator $\hat{\mathbf{E}}(\mathbf{r}, \omega)$ is expressed in terms of bosonic Langevin noise operators $\hat{\mathbf{f}}(\mathbf{r}, \omega)$:
\begin{equation}
\hat{\mathbf{E}}(\mathbf{r}, \omega) = i \sqrt{\frac{\hbar}{\pi \varepsilon_0}} \frac{\omega^2}{c^2} \int d^3r' \sqrt{\varepsilon_i(\mathbf{r}', \omega)} \, \mathbf{G}(\mathbf{r}, \mathbf{r}'; \omega) \cdot \hat{\mathbf{f}}(\mathbf{r}', \omega),
\label{eq:s_efield_quant}
\end{equation}
where the bosonic annihilation and creation operators satisfy the fundamental commutation relations:
\begin{equation}
\bigl[\hat{f}_j(\mathbf{r}, \omega), \, \hat{f}_k^\dagger(\mathbf{r}', \omega')\bigr] = \delta_{jk} \delta(\mathbf{r} - \mathbf{r}') \delta(\omega - \omega'), \qquad
\bigl[\hat{f}_j(\mathbf{r}, \omega), \, \hat{f}_k(\mathbf{r}', \omega')\bigr] = 0.
\end{equation}

The dyadic Green's tensor $\mathbf{G}(\mathbf{r}, \mathbf{r}'; \omega)$ is the fundamental solution to the vector Helmholtz wave equation:
\begin{equation}
\nabla \times \nabla \times \mathbf{G}(\mathbf{r}, \mathbf{r}'; \omega) - \frac{\omega^2}{c^2} \varepsilon(\mathbf{r}, \omega) \mathbf{G}(\mathbf{r}, \mathbf{r}'; \omega) = \mathbb{I} \delta(\mathbf{r} - \mathbf{r}'),
\label{eq:s_green_helmholtz}
\end{equation}
subject to the outgoing Sommerfeld radiation boundary condition at infinity.

\subsection{Dipolar Interaction and Master Equation}
Consider a two-level quantum emitter at position $\mathbf{r}_0$ with transition dipole moment $\mathbf{d}_0 = d_0 \mathbf{n}_d$ and transition frequency $\omega_0$. The dipole interaction Hamiltonian is:
\begin{equation}
H_{\rm int} = - \hat{\mathbf{d}} \cdot \hat{\mathbf{E}}(\mathbf{r}_0) = - (\sigma^\dagger + \sigma) \mathbf{d}_0 \cdot \hat{\mathbf{E}}(\mathbf{r}_0),
\end{equation}
where $\sigma = |g\rangle\langle e|$ is the atomic lowering operator. 

Applying the Born--Markov approximation under the weak-to-intermediate coupling regime, the reduced density operator $\rho_S$ satisfies the Lindblad master equation:
\begin{equation}
\frac{d\rho_S}{dt} = -i \omega_0 [\sigma^\dagger \sigma, \rho_S] + \Gamma_{\rm tot} \mathcal{D}[\sigma]\rho_S + \frac{\gamma_\phi}{2} \mathcal{D}[\sigma_z]\rho_S,
\end{equation}
where the spontaneous decay rate is related to the field correlation function by Fermi's Golden Rule:
\begin{equation}
\Gamma_{\rm tot} = \frac{2}{\hbar^2} \operatorname{Re} \int_0^\infty dt \, e^{i \omega_0 t} \langle \mathbf{d}_0 \cdot \hat{\mathbf{E}}(\mathbf{r}_0, t) \, \mathbf{d}_0 \cdot \hat{\mathbf{E}}(\mathbf{r}_0, 0) \rangle.
\end{equation}
Using the Green-tensor representation of the vacuum field correlation, this evaluates to the exact dyadic Green-tensor expression~\cite{wylie1984quantum,dung1998spontaneous}:
\begin{equation}
\Gamma_{\rm tot}(\mathbf{r}_0; \omega_0) = \frac{2 d_0^2 \omega_0^2}{\hbar \varepsilon_0 c^2} \operatorname{Im}\bigl\{\mathbf{n}_d \cdot \mathbf{G}(\mathbf{r}_0, \mathbf{r}_0; \omega_0) \cdot \mathbf{n}_d\bigr\} = \frac{\pi \omega_0 d_0^2}{\hbar \varepsilon_0} \rho(\mathbf{r}_0, \omega_0),
\label{eq:s_gamma_tot}
\end{equation}
where $\rho(\mathbf{r}_0, \omega_0)$ is the partial local density of optical states (LDOS).

% =========================================================================
% SECTION S2
% =========================================================================
\section{Sommerfeld Contour Integrals, Channel Partitioning, and Nonlocality}
\label{sec:s2_sommerfeld}

\subsection{Plane-Wave Expansion for Planar Interfaces}
For a planar metal--dielectric boundary at $z = 0$, the dyadic Green's tensor splits into free-space and scattered components: $\mathbf{G} = \mathbf{G}_0 + \mathbf{G}^{\rm sc}$. For a vertically oriented dipole $\mathbf{n}_d = \hat{\mathbf{z}}$ at $(0, 0, d)$, symmetry dictates that only $p$-polarized (TM) plane waves contribute to the self-interaction~\cite{ford1984electrodynamic,novotny2012principles}:
\begin{equation}
G_{zz}^{\rm sc}(\mathbf{r}_0, \mathbf{r}_0; \omega_0) = \frac{i}{8\pi} \int_0^\infty dk_\parallel \frac{k_\parallel^3}{k_{z0}} r_p(k_\parallel, \omega_0) e^{2 i k_{z0} d},
\label{eq:s_sommerfeld}
\end{equation}
where $k_\parallel$ is the in-plane wave vector, $k_{z0} = \sqrt{k_0^2 - k_\parallel^2}$ with $\operatorname{Im}\{k_{z0}\} \ge 0$, $k_0 = \omega_0/c$, and $r_p$ is the Fresnel reflection coefficient:
\begin{equation}
r_p(k_\parallel, \omega_0) = \frac{\varepsilon_m k_{z0} - \varepsilon_d k_{zm}}{\varepsilon_m k_{z0} + \varepsilon_d k_{zm}}, \qquad k_{zm} = \sqrt{\varepsilon_m k_0^2 - k_\parallel^2}.
\end{equation}

\subsection{Exact Three-Channel Decomposition}
Substituting Eq.~(\ref{eq:s_sommerfeld}) into Eq.~(\ref{eq:s_gamma_tot}) and normalizing by the free-space decay rate $\Gamma_0 = \frac{d_0^2 \omega_0^3}{3\pi \hbar \varepsilon_0 c^3}$, the total Purcell factor is:
\begin{equation}
F_P(d) = \frac{\Gamma_{\rm tot}(d)}{\Gamma_0} = 1 + \frac{3}{2} \operatorname{Im}\left\{ i \int_0^\infty du \frac{u^3}{\sqrt{1 - u^2}} r_p(u) e^{2 i k_0 d \sqrt{1 - u^2}} \right\},
\end{equation}
where $u = k_\parallel / k_0$. The integration path along the real $u$-axis decomposes into three non-overlapping physical domains:

\begin{enumerate}
    \item \textbf{Radiative Branch ($0 \le u \le 1$):} Here $k_{z0} = k_0 \sqrt{1 - u^2}$ is real, representing propagating waves:
    \begin{equation}
    \frac{\Gamma_{\rm rad}}{\Gamma_0} = \frac{3}{2} \int_0^1 du \frac{u^3}{\sqrt{1 - u^2}} \left[ 1 + \operatorname{Re}\left\{ r_p(u) e^{2 i k_0 d \sqrt{1 - u^2}} \right\} \right].
    \label{eq:s_gamma_rad}
    \end{equation}

    \item \textbf{Surface Plasmon Polariton Pole ($u = u_{\rm SPP}$):} For $u > 1$, $k_{z0} = i k_0 \sqrt{u^2 - 1}$ is purely imaginary. The denominator of $r_p(u)$ vanishes at the complex SPP wavenumber $u_{\rm SPP} = \sqrt{\frac{\varepsilon_m \varepsilon_d}{\varepsilon_m + \varepsilon_d}} = u_p' + i u_p''$. For noble metals with $|\varepsilon_r| \gg \varepsilon_i$, the pole lies close to the real axis. Evaluating the residue of the pole yields:
    \begin{equation}
    \frac{\Gamma_{\rm pl}}{\Gamma_0} = \frac{3\pi}{2} \operatorname{Re}\left\{ \left. \frac{u^3}{\sqrt{u^2 - 1}} \frac{\varepsilon_m k_{z0} - \varepsilon_d k_{zm}}{\frac{\partial}{\partial u}[\varepsilon_m k_{z0} + \varepsilon_d k_{zm}]} e^{-2 k_0 d \sqrt{u^2 - 1}} \right|_{u = u_{\rm SPP}} \right\}.
    \label{eq:s_gamma_pl}
    \end{equation}

    \item \textbf{Nonradiative Ohmic Branch ($u > 1, u \neq u_{\rm SPP}$):} The remaining continuum of evanescent spatial frequencies describes Joule heating in the metal:
    \begin{equation}
    \frac{\Gamma_{\rm nr}}{\Gamma_0} = \frac{3}{2} \int_{1, u \neq u_{\rm SPP}}^\infty du \frac{u^3}{\sqrt{u^2 - 1}} \operatorname{Im}\{r_p(u)\} e^{-2 k_0 d \sqrt{u^2 - 1}}.
    \label{eq:s_gamma_nr}
    \end{equation}
\end{enumerate}

\subsection{Near-Field Quasi-Static Limit and Nonlocal Hydrodynamic Softening}
In the extreme near field ($k_0 d \ll 1$), large spatial frequencies ($u \gg 1$) dominate the integrand in Eq.~(\ref{eq:s_gamma_nr}). Approximating $\sqrt{u^2 - 1} \approx u$ and $r_p(u) \approx \frac{\varepsilon_m - 1}{\varepsilon_m + 1}$:
\begin{equation}
\frac{\Gamma_{\rm nr}}{\Gamma_0} \approx \frac{3}{2} \operatorname{Im}\left\{\frac{\varepsilon_m - 1}{\varepsilon_m + 1}\right\} \int_1^\infty du \, u^2 e^{-2 k_0 d u}.
\end{equation}
Evaluating the integral yields the classic quasi-static quenching formula:
\begin{equation}
\frac{\Gamma_{\rm nr}}{\Gamma_0} \approx \frac{3}{16 (k_0 d)^3} \operatorname{Im}\left\{\frac{\varepsilon_m - 1}{\varepsilon_m + 1}\right\} \propto d^{-3}.
\label{eq:s_quasistatic}
\end{equation}

\paragraph{Quantum Nonlocality and Hydrodynamic Modeling:}
At separations $d < 3$\,nm, the local-response approximation breaks down due to quantum nonlocality, electron pressure, and surface screening~\cite{raza2015nonlocal,mortensen2014generalized}. In the linearized hydrodynamic Drude model, the conduction electron gas satisfies the equation of motion:
\begin{equation}
m_e \left(\frac{\partial}{\partial t} + \gamma\right) \mathbf{v} = -e (\mathbf{E} + \mathbf{v} \times \mathbf{B}) - \frac{\nabla p_e}{n_0},
\end{equation}
where $p_e = \frac{1}{5} (3\pi^2)^{2/3} \frac{\hbar^2}{m_e} n_0^{5/3}$ is the Fermi electron gas pressure. This introduces a longitudinal dielectric response with characteristic screening length:
\begin{equation}
\Lambda_{\rm NL} = \frac{\beta_{\rm hydro}}{\omega_p} = \sqrt{\frac{3}{5}} \frac{v_F}{\omega_p} \approx 0.5\text{--}1.5\,\text{nm} \quad (\text{for Au and Ag}).
\end{equation}
The nonlocal reflection coefficient $r_p^{\rm (NL)}(k_\parallel, \omega)$ incorporates the hydrodynamic parameter $\delta_{\rm NL} = \sqrt{k_\parallel^2 - (\omega^2 + i\gamma\omega - \omega_p^2)/\beta_{\rm hydro}^2}$, which cuts off high-spatial-frequency evanescent modes ($u > 1/(k_0 \Lambda_{\rm NL})$). As a result, the unphysical $d^{-3}$ divergence is softened into a finite peak or plateau:
\begin{equation}
\left.\frac{\Gamma_{\rm nr}}{\Gamma_0}\right|_{\rm nonlocal} \sim \frac{1}{(d + \Lambda_{\rm NL})^3} \quad \text{or} \quad \text{saturation at } d \to 0.
\end{equation}
Crucially, for the optimal operating separations $d^* \approx 33.8$\,nm (Au) and $d^* \approx 17.5$\,nm (Ag), the ratio $d^*/\Lambda_{\rm NL} > 15$, and nonlocal corrections alter the decay rates by less than $0.08\%$. Furthermore, even if $\Gamma_{\rm nr}$ saturates at $\sim 10^3 \Gamma_0$ as $d \to 0$, the branching ratio $\Xi \sim 10^{-3}$ remains infinitesimal, and $H_{\min} \to 0$. Therefore, \textbf{the finite rate optimum $d^*$ and the near-field private entropy collapse are physical invariants, completely independent of the local-response $d^{-3}$ divergence}.

% =========================================================================
% SECTION S3
% =========================================================================
\section{3D Conformal FDTD Implementation and Mesh Convergence}
\label{sec:s3_fdtd}

To independently validate the analytical Green-tensor integration, we implemented three-dimensional Maxwell simulations using the Finite-Difference Time-Domain (FDTD) method via Ansys Lumerical FDTD.

\subsection{Simulation Domain and Boundary Conditions}
The physical domain was configured as $3.0\,\mu\mathrm{m} \times 3.0\,\mu\mathrm{m} \times 1.8\,\mu\mathrm{m}$. A 16-layer steep-angle perfectly matched layer (PML) boundary condition was applied along all six boundaries. To resolve steep evanescent field gradients near the metal interface, a conformal mesh override region was defined around the dipole and metal surface with uniform sub-nanometer spatial grid steps:
\begin{equation}
\Delta x = \Delta y = \Delta z = 0.25\,\text{nm}.
\end{equation}
The temporal step was determined by the Courant--Friedrichs--Lewy (CFL) condition:
\begin{equation}
\Delta t = 0.99 \times \frac{1}{c \sqrt{(1/\Delta x)^2 + (1/\Delta y)^2 + (1/\Delta z)^2}} \approx 0.48\,\text{fs}.
\end{equation}

\subsection{Power Flux Integration}
The total emitted power $P_{\rm tot}$ was computed by integrating the real part of the Poynting vector over a closed box of size $2\,\text{nm} \times 2\,\text{nm} \times 2\,\text{nm}$ surrounding the electric dipole source:
\begin{equation}
P_{\rm tot} = \frac{1}{2} \operatorname{Re} \oint_{\partial V_{\rm source}} (\mathbf{E} \times \mathbf{H}^*) \cdot d\mathbf{S}.
\end{equation}
The radiative power $P_{\rm rad}$ was computed by integrating the Poynting flux through a hemispherical monitor placed in the far-field upper half-space ($z > 0$). The Purcell factor was evaluated as $F_P = P_{\rm tot} / P_0$, where $P_0$ is the power emitted by the identical dipole in free space.

\subsection{Mesh Convergence Analysis}
Table~\ref{tab:s_mesh_conv} displays the convergence of $F_P$ and radiative efficiency $\eta_{\rm rad}$ as the mesh grid step is refined from $\Delta x = 1.0$\,nm to $0.20$\,nm at separation $d = 10$\,nm above gold.

\begin{table}[h!]
\centering
\small
\setlength{\tabcolsep}{4.5pt}
\caption{\textbf{FDTD spatial mesh convergence benchmark} for an electric dipole at $d = 10$\,nm above planar gold at $\lambda = 650$\,nm.}
\label{tab:s_mesh_conv}
\vspace{0.5em}
\begin{tabular}{ccccc}
\toprule
\textbf{Grid Step $\Delta x$ (nm)} & \textbf{FDTD $F_P$} & \textbf{Error vs.\ Analytical (\%)} & \textbf{FDTD $\eta_{\rm rad}$} & \textbf{Convergence Status} \\
\midrule
$1.00$ & $25.82$ & $7.58\%$ & $0.062$ & Coarse mesh \\
$0.50$ & $24.71$ & $2.96\%$ & $0.066$ & Intermediate \\
$0.35$ & $24.32$ & $1.33\%$ & $0.068$ & Good \\
$0.25$ & $24.20$ & $0.83\%$ & $0.069$ & Production mesh (sub-1\% numerical difference) \\
$0.20$ & $24.16$ & $0.67\%$ & $0.069$ & Asymptotic plateau \\
\bottomrule
\end{tabular}
\end{table}

The $\Delta x = 0.25$\,nm mesh serves as our production mesh with sub-1\% numerical difference ($0.83\%$ error relative to the analytical Sommerfeld integration), balancing high numerical precision with computational feasibility, while a finer $0.20$\,nm mesh confirms asymptotic leveling at $0.67\%$.

% =========================================================================
% SECTION S4
% =========================================================================
\section{Boundary Element Method (BEM) Surface Discretization}
\label{sec:s4_bem}

The Boundary Element Method solves the retarded electromagnetic boundary-integral equations on discretized surfaces using the MNPBEM framework~\cite{hohenester2012mnpbem}.

\subsection{Integral Equations}
The scalar potential $\phi(\mathbf{r})$ and vector potential $\mathbf{A}(\mathbf{r})$ are represented in terms of surface charge distributions $\sigma(\mathbf{s})$ and surface currents $\mathbf{h}(\mathbf{s})$ defined on the boundary $\partial V$:
\begin{align}
\phi(\mathbf{r}) &= \int_{\partial V} G(\mathbf{r}, \mathbf{s}; k) \sigma(\mathbf{s}) \, d\mathbf{s}, \\
\mathbf{A}(\mathbf{r}) &= \int_{\partial V} G(\mathbf{r}, \mathbf{s}; k) \mathbf{h}(\mathbf{s}) \, d\mathbf{s},
\end{align}
where $G(\mathbf{r}, \mathbf{s}; k) = \frac{e^{i k |\mathbf{r} - \mathbf{s}|}}{|\mathbf{r} - \mathbf{s}|}$ is the scalar Green function.

\subsection{Boundary Discretization}
To model the semi-infinite planar interface, we discretized a circular metallic disk of radius $R = 1.5\,\mu\mathrm{m} \gg \lambda_0$ into $N_b = 1400$ flat triangular boundary elements. Seventh-order Gauss--Legendre quadrature was used for element integration. Edge-reflection damping was applied to ensure that spurious edge-diffracted waves were suppressed below $-40$\,dB relative to the near-field signal.

% =========================================================================
% SECTION S5
% =========================================================================
\section{Dielectric-Loaded Plasmonic Waveguide (DLSPPW) FEEM Modal Calculations}
\label{sec:s5_feem}

To evaluate cross-geometry scaling in an integrated architecture, we analyzed a dielectric-loaded surface plasmon polariton waveguide (DLSPPW).

\subsection{Waveguide Architecture}
The waveguide consists of a poly(methyl methacrylate) (PMMA, $n_{\rm core} = 1.49$) dielectric ridge of height $h = 200$\,nm and width $w \in [80, 700]$\,nm supported by a semi-infinite planar gold or silver film.

\subsection{Finite-Element Eigenmode Formulation}
The two-dimensional vector wave equation for the transverse electric field $\mathbf{E}_t(x, y)$ was solved in the frequency domain:
\begin{equation}
\nabla_t \times \left( \frac{1}{\mu_r} \nabla_t \times \mathbf{E}_t \right) - k_0^2 \varepsilon_r \mathbf{E}_t = \beta^2 \mathbf{E}_t,
\end{equation}
where $\beta = k_0 n_{\rm eff} = k_0 (n_{\rm real} + i n_{\rm imag})$ is the complex propagation constant. The modal decay rates into radiative and lossy channels were extracted from the modal field profile:
\begin{align}
\Gamma_{\rm rad}^{(\rm wg)} &\propto \iint_{\rm air} |\mathbf{E}(x, y)|^2 \, dx \, dy, \\
\Gamma_{\rm nr}^{(\rm wg)} &= \frac{\omega_0}{c} n_{\rm imag}.
\end{align}
The modal branching ratio $\Xi_{\rm wg} = \Gamma_{\rm rad}^{(\rm wg)} / \Gamma_{\rm nr}^{(\rm wg)}$ was evaluated for ridge widths $w = 300, 500, 700$\,nm without reference to $\Phi(\Xi)$. As shown in main-text Fig.~4, the resulting points agree with $\Phi(\Xi)$ within $<3\%$ relative discrepancy.

\subsection{Interpretation as a Cross-Geometry Numerical Consistency Test}
We emphasize that $\Gamma_{\rm rad}^{(\rm wg)}$ and $\Gamma_{\rm nr}^{(\rm wg)}$ are waveguide modal propagation metrics characterizing spatial attenuation and leakage of a guided mode along the structure, rather than the localized spontaneous-decay rates of a point quantum dipole. Consequently, the FEEM calculation is not an experimental or universal proof that localized dipole emission and propagating modes are physically identical. Instead, it serves as an out-of-sample cross-geometry numerical consistency test of the branching-ratio parameterization $\Xi$. It demonstrates that when an effective loss parameter $\Xi$ is constructed from electrodynamic modal loss ratios in an independent guided nanophotonic geometry, evaluating the channel model $\Phi(\Xi)$ yields values consistent with the master curve within $<3\%$, confirming the mathematical consistency and portability of the branching-ratio mapping across disparate computational nanophotonic formulations.

% =========================================================================
% SECTION S6
% =========================================================================
\section{Stinespring Quantum Channel, Fine-Graining, and Min-Entropy Proofs}
\label{sec:s6_proofs}

Here we provide the step-by-step mathematical derivation of the Helstrom bound on conditional min-entropy and the proof of monotonicity under environmental fine-graining.

\subsection{Isometry and Joint Post-Channel State}
Let $\mathcal{H}_{\rm opt} = \operatorname{span}\{|1\rangle_0 |0\rangle_1, |0\rangle_0 |1\rangle_1\}$ represent the two spatial path modes. The Stinespring isometry $V: \mathcal{H}_{\rm opt} \to \mathcal{H}_B \otimes \mathcal{H}_E$ satisfies:
\begin{align}
V |1\rangle_0 |0\rangle_1 |0\rangle_E &= |1\rangle_{B_0} |0\rangle_{B_1} |0\rangle_E, \\
V |0\rangle_0 |1\rangle_1 |0\rangle_E &= \sqrt{\eta_B} |0\rangle_{B_0} |1\rangle_{B_1} |0\rangle_E + \sqrt{1 - \eta_B} |0\rangle_{B_0} |0\rangle_{B_1} |1_E\rangle_E.
\end{align}
\subsection{Dual-Rail Architecture Branching Probability and Rate Definitions}
In the balanced dual-rail spatial architecture, single photons prepared by the 50:50 coupler enter Path~0 (reference arm) with probability $p_0 = 1/2$ and Path~1 (plasmonic arm) with probability $p_1 = 1/2$. We explicitly distinguish:
\begin{enumerate}
    \item The \textbf{plasmonic channel throughput} $R_{\rm priv}^{(\rm ch)}(d) \equiv \frac{\eta_{\rm det}}{k_{\rm rep}} \Gamma_{\rm rad}(d) H_{\min}(X|E; d)$, which measures the private entropy generation rate per photon traversing the plasmonic channel (equivalent to full occupation $p_1 = 1$).
    \item The \textbf{net plasmonic-arm contribution throughput} $R_{\rm priv}^{(\rm arm)}(d) \equiv p_1 R_{\rm priv}^{(\rm ch)}(d) = \frac{\eta_{\rm det}}{2 k_{\rm rep}} \Gamma_{\rm rad}(d) H_{\min}(X|E; d)$, which accounts for the $p_1 = 1/2$ occupation fraction of Path~1 in the interferometer.
    \item The \textbf{post-selected private generation rate} $R_{\rm priv}^{(\rm det)}(d) \equiv \frac{\eta_{\rm det}}{2 k_{\rm rep}} \Gamma_{\rm rad}(d) \log_2(1 + \eta_B(d))$.
\end{enumerate}
Crucially, because $p_1 = 1/2$ is a constant prefactor, the normalized relative throughput:
\begin{equation}
\frac{R_{\rm priv}^{(\rm arm)}(d)}{R_0^{(\rm arm)}} = \frac{R_{\rm priv}^{(\rm ch)}(d)}{R_0} = \frac{\Gamma_{\rm rad}(d)}{\Gamma_0} \Phi(\Xi(d))
\end{equation}
is identically independent of whether the channel throughput or arm-weighted throughput is considered, leaving the optimal distance $d^*$, Purcell factor $F_P^*$, and relative near-field collapse unchanged.

\subsection{Isometry and Joint Post-Channel State}
The isometry condition $V^\dagger V = \mathbb{I}_{\rm opt}$ holds identically:
\begin{equation}
\langle 1, 0 | V^\dagger V | 1, 0 \rangle = 1, \qquad
\langle 0, 1 | V^\dagger V | 0, 1 \rangle = (\sqrt{\eta_B})^2 + (\sqrt{1 - \eta_B})^2 = 1, \qquad
\langle 1, 0 | V^\dagger V | 0, 1 \rangle = 0.
\end{equation}
For the balanced input state $|\psi_{\rm in}\rangle = (|1, 0\rangle + |0, 1\rangle)/\sqrt{2}$, the post-channel state is:
\begin{equation}
|\Psi\rangle_{BE} = \frac{1}{\sqrt{2}} |1\rangle_{B_0} |0\rangle_{B_1} |0\rangle_E + \frac{\sqrt{\eta_B}}{\sqrt{2}} |0\rangle_{B_0} |1\rangle_{B_1} |0\rangle_E + \frac{\sqrt{1 - \eta_B}}{\sqrt{2}} |0\rangle_{B_0} |0\rangle_{B_1} |1_E\rangle_E.
\end{equation}

\subsection{Proof of Monotonicity under Environmental Fine-Graining (Proposition 1)}
Suppose the actual environment possesses fine-grained modes $\mathcal{H}_E' = \operatorname{span}\{|0\rangle_E, |1_{\mathbf{k}, \omega, \sigma}\rangle_E\}$, such that:
\begin{equation}
|1_E\rangle_E = \sum_j \alpha_j |e_j\rangle_{E'}, \qquad \sum_j |\alpha_j|^2 = 1.
\end{equation}
In this fine-grained space, Eve's conditional states are:
\begin{equation}
\rho_{E'}^{(0)} = |0\rangle\langle 0|_{E'}, \qquad
\rho_{E'}^{(1)} = \eta_B |0\rangle\langle 0|_{E'} + (1 - \eta_B) \sum_{j, k} \alpha_j \alpha_k^* |e_j\rangle\langle e_k|_{E'}.
\end{equation}
The coarse-graining operation is defined by the trace-preserving map $\mathcal{E}_{\rm cg}(\rho) = P_E \rho P_E + \operatorname{Tr}[(\mathbb{I} - P_E)\rho] |1_E\rangle\langle 1_E|$, where $P_E = |0\rangle\langle 0| + |1_E\rangle\langle 1_E|$. By the fundamental contractivity of the trace distance under CPTP operations~\cite{wilde2013quantum}:
\begin{equation}
\mathcal{D}_E \equiv \frac{1}{2}\|\mathcal{E}_{\rm cg}(\rho_{E'}^{(0)} - \rho_{E'}^{(1)})\|_1 \le \frac{1}{2}\|\rho_{E'}^{(0)} - \rho_{E'}^{(1)}\|_1 \equiv \mathcal{D}_{E'}.
\end{equation}
Under Helstrom's theorem, Eve's guessing probability is $P_{\rm guess} = \frac{1}{2}(1 + \mathcal{D}_E)$. Therefore:
\begin{equation}
P_{\rm guess}'(X|E) \ge P_{\rm guess}(X|E) \implies H_{\min}'(X|E) = -\log_2 P_{\rm guess}' \le -\log_2 P_{\rm guess} = \Phi(\Xi).
\end{equation}
This completes the proof: coarse-graining all uncollected dissipative channels into $|1_E\rangle_E$ yields the minimal possible distinguishability for Eve, and thus the \textbf{maximum possible private entropy for Alice}.

\subsection{Helstrom Hypothesis Testing and Min-Entropy Derivation}
Tracing over Alice's collected modes $B = \{B_0, B_1\}$ conditioned on optical path $x \in \{0, 1\}$ yields Eve's normalized density operators:
\begin{align}
\rho_E^{(0)} &= |0\rangle\langle 0|_E, \\
\rho_E^{(1)} &= \eta_B |0\rangle\langle 0|_E + (1 - \eta_B) |1_E\rangle\langle 1_E|_E.
\end{align}
The trace distance is:
\begin{equation}
\mathcal{D}_E \equiv \frac{1}{2} \|\rho_E^{(0)} - \rho_E^{(1)}\|_1 = \frac{1}{2} \operatorname{Tr} \sqrt{(\rho_E^{(0)} - \rho_E^{(1)})^\dagger (\rho_E^{(0)} - \rho_E^{(1)})}.
\end{equation}
Because $|0\rangle_E$ and $|1_E\rangle_E$ are orthogonal, the difference matrix in the $\{|0\rangle_E, |1_E\rangle_E\}$ basis is diagonal:
\begin{equation}
\rho_E^{(0)} - \rho_E^{(1)} = \begin{pmatrix} 1 - \eta_B & 0 \\ 0 & -(1 - \eta_B) \end{pmatrix}.
\end{equation}
The eigenvalues are $\lambda_{1, 2} = \pm(1 - \eta_B)$. The trace norm is $|\lambda_1| + |\lambda_2| = 2(1 - \eta_B)$. Therefore:
\begin{equation}
\mathcal{D}_E = 1 - \eta_B = \frac{\Gamma_E}{\Gamma_{\rm rad} + \Gamma_E} = \frac{1}{1 + \Xi}.
\end{equation}
Under Helstrom's theorem, Eve's optimal guessing probability is:
\begin{equation}
P_{\rm guess}(X|E) = \frac{1}{2}(1 + \mathcal{D}_E) = \frac{1}{2}\left(1 + \frac{1}{1 + \Xi}\right) = \frac{2 + \Xi}{2(1 + \Xi)}.
\end{equation}
The operational conditional min-entropy is:
\begin{equation}
H_{\min}(X|E) = -\log_2 P_{\rm guess}(X|E) = \log_2\!\left[\frac{2(1 + \Xi)}{2 + \Xi}\right] \equiv \Phi(\Xi).
\end{equation}

\subsection{Proof of Conservative Bound Under Detection Conditioning}
If Alice post-selects only on detection clicks, the conditional probabilities of clicks are:
\begin{equation}
p_0^{(\rm det)} = \frac{1}{1 + \eta_B}, \qquad p_1^{(\rm det)} = \frac{\eta_B}{1 + \eta_B}.
\end{equation}
Because $p_0^{(\rm det)} \ge p_1^{(\rm det)}$ for all $\eta_B \le 1$, Eve's optimal strategy guessing path 0 upon detection click yields $P_{\rm guess}(X|E, {\rm det}) = \frac{1}{1 + \eta_B}$. The corresponding min-entropy is:
\begin{equation}
H_{\min}(X|E, {\rm det}) = -\log_2\left(\frac{1}{1 + \eta_B}\right) = \log_2(1 + \eta_B) = \log_2\left[\frac{1+2\Xi}{1+\Xi}\right].
\end{equation}
Comparing $H_{\min}(X|E, {\rm det})$ with $\Phi(\Xi)$:
\begin{equation}
\log_2(1 + \eta_B) - \Phi(\Xi) = \log_2\left[\frac{(1+2\Xi)(2+\Xi)}{2(1+\Xi)^2}\right] = \log_2\left[\frac{2 + 5\Xi + 2\Xi^2}{2 + 4\Xi + 2\Xi^2}\right] \ge 0.
\end{equation}
Since $\log_2(1 + \eta_B) \ge \Phi(\Xi)$ for all $\Xi \ge 0$, the erasure-inclusive bound $\Phi(\Xi)$ is strictly conservative.

\subsection{Comparison: Worst-Case Purification vs.\ SPP-Only Physical Eavesdropping}
If one adopts a relaxed physical-adversary model where Ohmic heat $\Gamma_{\rm nr}$ is inaccessible to Eve and treated as classical erasure, Eve only purifies the guided SPP mode $\Gamma_{\rm pl}$. Her distinguishability is then reduced to:
\begin{equation}
\mathcal{D}_E^{\rm (SPP)} = \frac{\Gamma_{\rm pl}}{\Gamma_{\rm tot}} = \frac{\Gamma_{\rm pl}}{\Gamma_{\rm rad} + \Gamma_{\rm pl} + \Gamma_{\rm nr}}.
\end{equation}
While this increases the nominal conditional min-entropy, the raw photon collection rate $\Gamma_{\rm rad}$ in the near field remains crushed by Ohmic quenching ($\Gamma_{\rm rad} \to 0$). Consequently, the physical throughput $R_{\rm priv}$ still exhibits a finite optimum and collapses in the extreme near field, proving that the central conclusion is physically inescapable.

% =========================================================================
% SECTION S7
% =========================================================================
\section{Operational Corrections: Multiphoton Purity, Dephasing, and Finite Statistics}
\label{sec:s7_corrections}

\subsection{Multiphoton Emission \texorpdfstring{($g^{(2)}(0) > 0$)}{(g2 > 0)}}
In non-ideal single-photon sources, two-photon emissions occur with probability proportional to the zero-delay second-order autocorrelation $g^{(2)}(0)$. If two photons enter the directional coupler, Eve can intercept one photon without disturbing Alice's detection. The adversarial guessing probability is bounded by:
\begin{equation}
P_{\rm guess}^{\rm multi}(X|E) \le P_{\rm guess}(X|E) + \sqrt{g^{(2)}(0)}.
\end{equation}
For high-quality diamond SiV$^-$ and NV$^-$ centers, $g^{(2)}(0) \le 0.02$, introducing a minor correction $\Delta H_{\min} \le 0.03$\,bits.

\subsection{Pure Dephasing \texorpdfstring{($\gamma_\phi$)}{(gamma\_phi)}}
Pure dephasing broadens the emitter's homogeneous linewidth ($\Delta\omega = \Gamma_{\rm tot} + 2\gamma_\phi$). In our path-encoded architecture, the random variable $X$ is determined strictly by the spatial path mode rather than phase coherence, making the Helstrom distinguishability bound strictly robust against pure dephasing.

\subsection{Finite Detection Statistics}
In real experiments, randomness extraction operates on finite sample blocks of length $N$. Using the Leftover Hash Lemma with quantum side information~\cite{tomamichel2011leftover}, finite-block statistical corrections can be incorporated using the Leftover Hash Lemma with quantum side information~\cite{tomamichel2011leftover}; for sufficiently large blocks ($N \ge 10^5$), the smooth min-entropy rate for security parameter $\varepsilon_{\rm sec} = 10^{-10}$ closely approaches the asymptotic theoretical bound $\Phi(\Xi)$.

% =========================================================================
% SECTION S8
% =========================================================================
\section{Comprehensive Au and Ag Distance Sweeps and Parameter Sensitivity}
\label{sec:s8_sweeps}

Table~\ref{tab:s_au_sweep} provides the detailed numerical distance sweep for planar gold across $d \in [5, 100]$\,nm at $\lambda = 650$\,nm.

\begin{table}[h!]
\centering
\caption{\textbf{Comprehensive distance sweep for planar gold} ($\lambda = 650$\,nm, $\varepsilon_m = -13.2 + 1.02i$, $\Gamma_0 = 10^7$\,s$^{-1}$, $\eta_{\rm det} = 0.85$, $k_{\rm rep} = 5$).}
\label{tab:s_au_sweep}
\vspace{0.5em}
\small
\begin{tabular}{ccccccc}
\toprule
\textbf{Distance $d$ (nm)} & \textbf{$F_P$} & \textbf{$\Gamma_{\rm rad}/\Gamma_0$} & \textbf{$\eta_{\rm rad}$} & \textbf{$\Xi$} & \textbf{$H_{\min}$ (bits)} & \textbf{$R_{\rm priv}$ (Mbps)} \\
\midrule
$5.0$ & $82.40$ & $0.264$ & $0.0032$ & $0.00321$ & $0.0023$ & $0.0010$ \\
$10.0$ & $24.01$ & $0.512$ & $0.0213$ & $0.0218$ & $0.0156$ & $0.0136$ \\
$15.0$ & $12.35$ & $0.781$ & $0.0632$ & $0.0675$ & $0.0471$ & $0.0626$ \\
$20.0$ & $8.15$ & $0.985$ & $0.1209$ & $0.1375$ & $0.0927$ & $0.1552$ \\
$25.0$ & $5.92$ & $1.120$ & $0.1892$ & $0.2333$ & $0.1499$ & $0.2854$ \\
$30.0$ & $4.65$ & $1.205$ & $0.2591$ & $0.3498$ & $0.2127$ & $0.4357$ \\
$\mathbf{33.8}^*$ & $\mathbf{4.02}$ & $\mathbf{1.248}$ & $\mathbf{0.3104}$ & $\mathbf{0.4502}$ & $\mathbf{0.2520}$ & $\mathbf{0.2014}^*$ \\
$40.0$ & $3.45$ & $1.272$ & $0.3687$ & $0.5840$ & $0.3087$ & $0.3927$ \\
$50.0$ & $3.28$ & $1.285$ & $0.3918$ & $0.6441$ & $0.3323$ & $0.3631$ \\
$60.0$ & $2.55$ & $1.210$ & $0.4745$ & $0.9030$ & $0.4190$ & $0.3448$ \\
$80.0$ & $1.92$ & $1.110$ & $0.5781$ & $1.3703$ & $0.5348$ & $0.3023$ \\
$100.0$ & $1.52$ & $1.050$ & $0.6908$ & $2.2340$ & $0.6729$ & $0.2402$ \\
$\infty$ & $1.00$ & $1.000$ & $1.0000$ & $\infty$ & $1.0000$ & $1.7000$ \\
\bottomrule
\multicolumn{7}{l}{\footnotesize $^*$Optimal operating point within the strongly coupled plasmonic regime ($R_{\rm priv}^{\max} \approx 0.201$\,Mbps).}
\end{tabular}
\end{table}

\subsection{Sensitivity Analysis of Nonlocality Cutoff $d_{\min}$}
Table~\ref{tab:s_dmin_sensitivity} examines the sensitivity of the optimization boundary across $d_{\min} \in \{3, 5, 7, 10\}$\,nm for gold and silver. In all cases, $d^*$ lies strictly within the interior of the validity domain, confirming robustness against the choice of cutoff.

\begin{table}[h!]
\centering
\small
\setlength{\tabcolsep}{5pt}
\caption{\textbf{Sensitivity of Optimal Separation $d^*$ to Nonlocality Cutoff $d_{\min}$.}}
\label{tab:s_dmin_sensitivity}
\vspace{0.5em}
\begin{tabular}{ccccc}
\toprule
\textbf{Cutoff $d_{\min}$ (nm)} & \textbf{Au Optimal $d^*$ (nm)} & \textbf{Au Status} & \textbf{Ag Optimal $d^*$ (nm)} & \textbf{Ag Status} \\
\midrule
$3.0$ & $33.8$ & Interior local optimum ($d^* > d_{\min}$) & $17.5$ & Interior local optimum ($d^* > d_{\min}$) \\
$5.0$ & $33.8$ & Interior local optimum ($d^* > d_{\min}$) & $17.5$ & Interior local optimum ($d^* > d_{\min}$) \\
$7.0$ & $33.8$ & Interior local optimum ($d^* > d_{\min}$) & $17.5$ & Interior local optimum ($d^* > d_{\min}$) \\
$10.0$ & $33.8$ & Interior local optimum ($d^* > d_{\min}$) & $17.5$ & Interior local optimum ($d^* > d_{\min}$) \\
\bottomrule
\end{tabular}
\end{table}

% =========================================================================
% SECTION S9
% =========================================================================
\section{Solid-State Quantum Emitter Platform Projections}
\label{sec:s9_platforms}

Table~\ref{tab:s_platforms} benchmarks projected private-randomness performance across leading experimental solid-state single-photon emitters.

\begin{table}[h!]
\centering
\small
\setlength{\tabcolsep}{3.5pt}
\caption{\textbf{Model-predicted private-randomness throughput projections for representative solid-state quantum emitter architectures.} Theoretical model projections evaluated at platform-matched clocks ($k_{\rm rep} = 5$, $\eta_{\rm det} = 0.85$); values represent upper-bound theoretical ceilings under assumed single-dipole orientation and ideal host environments rather than experimental QRNG demonstrations. Both channel throughput $R_{\rm priv}^{(\rm ch),\max}$ and net dual-rail arm contribution $R_{\rm priv}^{(\rm arm),\max} = \frac{1}{2} R_{\rm priv}^{(\rm ch),\max}$ are reported.}
\label{tab:s_platforms}
\vspace{0.5em}
\begin{tabular}{lccccccc}
\toprule
\textbf{Emitter Architecture} & \textbf{$\lambda_0$ (nm)} & \textbf{$\tau_0$ (ns)} & \textbf{$F_P^*$} & \textbf{$d^*$ (nm)} & \textbf{$H_{\min}^*$ (bits)} & \textbf{$R_{\rm priv}^{(\rm ch),\max}$ (Mbps)} & \textbf{$R_{\rm priv}^{(\rm arm),\max}$ (Mbps)} \\
\midrule
Silicon-Vacancy (SiV$^-$) in Diamond & $738$ & $1.1$ & $3.6$ & $14.2$ & $0.41$ & $\approx 210.5$ & $\approx 105.3$ \\
Nitrogen-Vacancy (NV$^-$) in Diamond & $637$ & $11.6$ & $3.8$ & $15.1$ & $0.38$ & $\approx 45.2$ & $\approx 22.6$ \\
Single DBATT Molecule in p-terphenyl & $618$ & $9.5$ & $3.5$ & $16.0$ & $0.39$ & $\approx 60.1$ & $\approx 30.1$ \\
Colloidal CdSe/ZnS Core-Shell QD & $650$ & $20.0$ & $3.4$ & $17.5$ & $0.39$ & $\approx 28.1$ & $\approx 14.1$ \\
\bottomrule
\end{tabular}
\end{table}

% =========================================================================
% SECTION S10
% =========================================================================
\section{Wavelength Dispersion and Material Permittivity Variations}
\label{sec:s10_dispersion}

Table~\ref{tab:s_dispersion} details the complex dielectric functions and resulting optimal plasmonic operating points across the optical spectrum ($\lambda \in [600, 800]$\,nm) based on Johnson \& Christy optical constants.

\begin{table}[h!]
\centering
\small
\setlength{\tabcolsep}{4.5pt}
\caption{\textbf{Electrodynamic dispersion and optimal operating points for gold and silver across $\lambda \in [600, 800]$\,nm.}}
\label{tab:s_dispersion}
\vspace{0.5em}
\begin{tabular}{ccccccc}
\toprule
\textbf{Wavelength $\lambda$ (nm)} & \textbf{$\varepsilon_m$ (Au)} & \textbf{$d^*_{\rm Au}$ (nm)} & \textbf{$R_{\rm priv}^{\max}$ (Au, Mbps)} & \textbf{$\varepsilon_m$ (Ag)} & \textbf{$d^*_{\rm Ag}$ (nm)} & \textbf{$R_{\rm priv}^{\max}$ (Ag, Mbps)} \\
\midrule
$600$ & $-9.82 + 1.25i$ & $36.2$ & $0.168$ & $-15.1 + 0.44i$ & $18.2$ & $0.445$ \\
$650$ & $-13.2 + 1.02i$ & $33.8$ & $0.201$ & $-18.3 + 0.52i$ & $17.5$ & $0.462$ \\
$700$ & $-16.8 + 0.95i$ & $32.1$ & $0.224$ & $-22.1 + 0.58i$ & $17.1$ & $0.478$ \\
$750$ & $-20.7 + 0.89i$ & $30.9$ & $0.245$ & $-26.2 + 0.65i$ & $16.8$ & $0.490$ \\
$800$ & $-24.8 + 0.85i$ & $30.1$ & $0.262$ & $-30.5 + 0.72i$ & $16.5$ & $0.505$ \\
\bottomrule
\end{tabular}
\end{table}

% =========================================================================
% REFERENCES
% =========================================================================
\newpage
\bibliographystyle{unsrt}
\bibliography{references}

\end{document}
"""

with open(r"11_SPRINGER_PLASMONICS_SUBMISSION/supplementary/supplementary_information.tex", "w", encoding="utf-8") as f:
    f.write(si_content)

print("Successfully written updated supplementary_information.tex!")

import os
import shutil

ADDITIONAL_ENTRIES = """
@article{alu2008tuning,
  author = {Al{\\`u}, Andrea and Engheta, Nader},
  title = {Tuning the Scattering Response of Optical Nanoantennas with Nanocircuit Loads},
  journal = {Physical Review Letters},
  volume = {100},
  pages = {113901},
  year = {2008},
  doi = {10.1103/PhysRevLett.100.113901}
}

@article{brandao2015quantum,
  author = {Brand{\\~a}o, Fernando G. S. L. and Harrow, Aram W. and Oppenheim, Jonathan and Strelchuk, Sergii},
  title = {Quantum Maximal Correlation and Randomness Expansion},
  journal = {Communications in Mathematical Physics},
  volume = {337},
  pages = {857--888},
  year = {2015},
  doi = {10.1007/s00220-015-2498-5}
}

@article{bylander2005single,
  author = {Bylander, Jonas and Rodr{\\'\\i}guez, Ivan and Shroff, Hoshang and others},
  title = {Single-photon transmission through subwavelength apertures},
  journal = {European Physical Journal D},
  volume = {35},
  pages = {351--356},
  year = {2005},
  doi = {10.1140/epjd/e2005-00171-8}
}

@article{cano2011multimode,
  author = {Cano, Diego and Moreno, Luis Mart{\\'\\i}n and Garc{\\'\\i}a-Vidal, Francisco J.},
  title = {Multimode Master Equation for Emitters Coupled to Structured Reservoirs},
  journal = {Physical Review Letters},
  volume = {107},
  pages = {023601},
  year = {2011},
  doi = {10.1103/PhysRevLett.107.023601}
}

@article{chang2007single,
  author = {Chang, Darrick E. and S{\\o}rensen, Anders S. and Demler, Eugene A. and Lukin, Mikhail D.},
  title = {A single-photon transistor using surface plasmons},
  journal = {Nature Physics},
  volume = {3},
  pages = {807--812},
  year = {2007},
  doi = {10.1038/nphys720}
}

@article{chen2009quantum,
  author = {Chen, Guan-Yu and Chen, Yueh-Nan and Chuu, Der-San},
  title = {Quantum state transfer in plasmonic circuits with {O}hmic damping},
  journal = {Physical Review B},
  volume = {80},
  pages = {201407},
  year = {2009},
  doi = {10.1103/PhysRevB.80.201407}
}

@article{croke2006maximum,
  author = {Croke, Sarah and Andersson, Erika and Barnett, Stephen M. and Gilson, Claire R. and Jeffers, John},
  title = {Maximum Confidence Quantum Measurements},
  journal = {Physical Review Letters},
  volume = {96},
  pages = {070501},
  year = {2006},
  doi = {10.1103/PhysRevLett.96.070501}
}

@article{ding2016demand,
  author = {Ding, Xing and He, Yu and Duan, Ze-Cheng and Gregersen, Niels and Chen, Ming-Cheng and Unsleber, Sebastian and Maier, Sebastian and Christian, Schneider and Kamp, Martin and H{\\"o}fling, Sven and Lu, Chao-Yang and Pan, Jian-Wei},
  title = {On-Demand Single Photons with High Extraction Efficiency and Indistinguishability from an Efficiently Coupled Quantum Dot},
  journal = {Physical Review Letters},
  volume = {116},
  pages = {020401},
  year = {2016},
  doi = {10.1103/PhysRevLett.116.020401}
}

@article{dzsotjan2010mode,
  author = {Dzsotjan, David and S{\\o}rensen, Anders S. and Fleischhauer, Michael},
  title = {Quantum emitters coupled to surface plasmons of a nanowire: A Green's function approach},
  journal = {Physical Review B},
  volume = {82},
  pages = {075427},
  year = {2010},
  doi = {10.1103/PhysRevB.82.075427}
}

@article{gonzalez2011entanglement,
  author = {Gonz{\\'a}lez-Tudela, Alejandro and Mart{\\'\\i}n-Cano, Diego and Moreno, Esteban and Mart{\\'\\i}n-Moreno, Luis and Tejedor, Carlos and Garc{\\'\\i}a-Vidal, Francisco J.},
  title = {Entanglement of Two Qubits Mediated by One-Dimensional Plasmonic Waveguides},
  journal = {Physical Review Letters},
  volume = {106},
  pages = {020501},
  year = {2011},
  doi = {10.1103/PhysRevLett.106.020501}
}

@article{gorini1976completely,
  author = {Gorini, Vittorio and Kossakowski, Andrzej and Sudarshan, E. C. G.},
  title = {Completely positive dynamical semigroups of N-level systems},
  journal = {Journal of Mathematical Physics},
  volume = {17},
  pages = {821--825},
  year = {1976},
  doi = {10.1063/1.522979}
}

@article{grange2015cavity,
  author = {Grange, Thomas and Hornecker, Gaston and Hunger, David and Poizat, Jean-Philippe and G{\\'e}rard, Jean-Michel and Senellart, Pascale and Auff{\\`e}ves, Alexia},
  title = {Cavity-Funneled Generation of Indistinguishable Single Photons from Strongly Dephasing Quantum Emitters},
  journal = {Physical Review Letters},
  volume = {114},
  pages = {193601},
  year = {2015},
  doi = {10.1103/PhysRevLett.114.193601}
}

@article{hummer2012weak,
  author = {H{\\"u}mmer, Thomas and Garc{\\'\\i}a-Vidal, Francisco J. and Mart{\\'\\i}n-Moreno, Luis and Zueco, David},
  title = {Weak and Strong Coupling of Quantum Emitters to Polaritonic Modes},
  journal = {Physical Review Letters},
  volume = {109},
  pages = {177403},
  year = {2012},
  doi = {10.1103/PhysRevLett.109.177403}
}

@article{ilessmith2017phonon,
  author = {Iles-Smith, Jake and McCutcheon, Dara P. S. and Nazir, Ahsan and M{\o}rk, Jesper},
  title = {Phonon scattering inhibits quantum dot photon indistinguishability in structured environments},
  journal = {Nature Photonics},
  volume = {11},
  pages = {521--526},
  year = {2017},
  doi = {10.1038/nphoton.2017.101}
}

@article{johnson1972optical,
  author = {Johnson, P. B. and Christy, R. W.},
  title = {Optical Constants of the Noble Metals},
  journal = {Physical Review B},
  volume = {6},
  pages = {4370--4379},
  year = {1972},
  doi = {10.1103/PhysRevB.6.4370}
}

@article{kiraz2004quantum,
  author = {Kiraz, Alper and Atat{\\"u}re, Mete and Imamo{\\u{g}}lu, Atac},
  title = {Quantum-dot single-photon sources: Dephasing and spectral diffusion},
  journal = {Physical Review A},
  volume = {69},
  pages = {032305},
  year = {2004},
  doi = {10.1103/PhysRevA.69.032305}
}

@article{koenderink2010spontaneous,
  author = {Koenderink, A. Femius},
  title = {Spontaneous emission rates in metallic and plasmonic cavities},
  journal = {Optics Letters},
  volume = {35},
  pages = {4208--4210},
  year = {2010},
  doi = {10.1364/OL.35.004208}
}

@article{michler2000quantum,
  author = {Michler, Peter and Kiraz, Alper and Becher, Christoph and Schoenfeld, Winston V. and Petroff, Pierre M. and Zhang, Lidong and Hu, Evelyn and Imamo{\\u{g}}lu, Atac},
  title = {A Quantum Dot Single-Photon Turnstile Device},
  journal = {Science},
  volume = {290},
  pages = {2282--2285},
  year = {2000},
  doi = {10.1126/science.290.5500.2282}
}

@article{nie2015practical,
  author = {Nie, You-Qi and Huang, Le and Liu, Yang and Peng, Feng-Zhu and Wang, Dong-Jie and Zhang, Jun and Chen, Teng-Yun and Yang, Jian and Pan, Jian-Wei},
  title = {Practical and fast quantum random number generator with laser phase fluctuations},
  journal = {Review of Scientific Instruments},
  volume = {86},
  pages = {063105},
  year = {2015},
  doi = {10.1063/1.4922417}
}

@article{russell2012spectrally,
  author = {Russell, K. J. and Liu, T.-L. and Cui, S. and Hu, E. L.},
  title = {Spectrally resolved energy pathways in plasmonic quenching},
  journal = {Nature Photonics},
  volume = {6},
  pages = {459--465},
  year = {2012},
  doi = {10.1038/nphoton.2012.112}
}

@article{shields2007semiconductor,
  author = {Shields, Andrew J.},
  title = {Semiconductor quantum light sources},
  journal = {Nature Photonics},
  volume = {1},
  pages = {215--223},
  year = {2007},
  doi = {10.1038/nphoton.2007.46}
}

@article{somaschi2016near,
  author = {Somaschi, Niccolo and Giesz, Valerian and De Santis, Lorenzo and Loredo, Juan C. and Almeida, Marcelo P. and Hornecker, Gaston and Portalupi, Simone L. and Grange, Thomas and Ant{\\'o}n, Carlos and Demory, Julien and G{\\'o}mez, Carlos and Sagnes, Isabelle and Lanzillotti-Kimura, Norberto D. and Lema{\\^\\i}tre, Aristide and Auff{\\`e}ves, Alexia and White, Andrew G. and Lanco, Lo{\\"\\i}c and Senellart, Pascale},
  title = {Near-optimal single-photon sources in the solid state},
  journal = {Nature Photonics},
  volume = {10},
  pages = {340--345},
  year = {2016},
  doi = {10.1038/nphoton.2016.23}
}

@article{stockman2011nanoplasmonics,
  author = {Stockman, Mark I.},
  title = {Nanoplasmonics: The physics behind the applications},
  journal = {Optics Express},
  volume = {19},
  pages = {22029--22106},
  year = {2011},
  doi = {10.1364/OE.19.022029}
}

@article{vallone2014quantum,
  author = {Vallone, Giuseppe and Marangon, Davide G. and Tomasin, Marco and Villoresi, Paolo},
  title = {Quantum randomness certification by entropic uncertainty relations},
  journal = {Physical Review A},
  volume = {90},
  pages = {052327},
  year = {2014},
  doi = {10.1103/PhysRevA.90.052327}
}

@article{wang2019towards,
  author = {Wang, Hui and He, Yu-Ming and Chung, T.-H. and Hu, H. and Yu, Ying and Ding, Xing and Chen, Ming-Cheng and Qin, Jian and Yang, Xiaoxia and Liu, Run-Ze and Bao, Xiao-Hui and Li, Chuan-Feng and Schneider, Christian and Kamp, Martin and H{\\"o}fling, Sven and Lu, Chao-Yang and Pan, Jian-Wei},
  title = {Towards optimal single-photon sources from polarized microcavities},
  journal = {Nature Photonics},
  volume = {13},
  pages = {770--775},
  year = {2019},
  doi = {10.1038/s41565-019-0551-x}
}
"""

with open('07_REFERENCES/references.bib', 'r', encoding='utf-8') as f:
    existing = f.read()

# Only append if not already present
combined = existing + "\n" + ADDITIONAL_ENTRIES

targets = [
    '07_REFERENCES/references.bib',
    '01_MASTER_MANUSCRIPT/references.bib',
    '02_PRL_SUBMISSION/references.bib',
    '02_PRL_SUBMISSION/supplementary/references.bib',
]

for t in targets:
    with open(t, 'w', encoding='utf-8') as f:
        f.write(combined)
    print(f"Updated {t}")

import urllib.request
import urllib.parse
import json
import time
import sys

headers = {'User-Agent': 'PRLReferenceVerifier/1.0 (mailto:ram.soorat@woxsen.edu.in)'}

def get_crossref_doi(doi):
    encoded = urllib.parse.quote(doi)
    url = f"https://api.crossref.org/works/{encoded}"
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=5) as res:
            if res.status == 200:
                data = json.loads(res.read().decode('utf-8'))['message']
                title = data.get('title', [''])[0]
                container = data.get('container-title', [''])
                journal = container[0] if container else ''
                year = None
                for yf in ['published-print', 'published-online', 'created', 'issued']:
                    if yf in data and 'date-parts' in data[yf]:
                        year = data[yf]['date-parts'][0][0]
                        if year:
                            break
                volume = data.get('volume', '')
                page = data.get('page', data.get('article-number', ''))
                authors = []
                for a in data.get('author', []):
                    g = a.get('given', '')
                    f = a.get('family', '')
                    if f:
                        authors.append({'given': g, 'family': f})
                return {
                    'valid': True,
                    'doi': data.get('DOI', doi),
                    'title': title,
                    'journal': journal,
                    'year': year,
                    'volume': volume,
                    'page': page,
                    'authors': authors
                }
    except Exception as e:
        return {'valid': False, 'doi': doi, 'error': str(e)}

candidate_dois = [
    # Ram Soorat & Priyanka papers
    "10.1007/s10773-026-06369-3",
    "10.1007/s11468-026-03462-5",
    "10.1016/j.nwnano.2026.100233",
    "10.1007/s11128-026-05192-3",
    "10.32604/jqc.2024.054000",
    "10.17586/2220-8054-2017-8-5-600-605",
    "10.1007/s11128-020-02756-9",
    "10.1007/s12648-024-03112-8",
    "10.1016/j.ijleo.2016.05.046",

    # Recent Top-tier QRNG & certified randomness (2018-2026)
    "10.1103/PRXQuantum.1.010302",
    "10.1038/s41467-018-07585-0",
    "10.1103/PhysRevLett.120.010503",
    "10.1038/s41534-019-0144-8",
    "10.1007/s11128-020-02865-5",
    "10.1103/PhysRevApplied.15.064034",
    "10.1103/PhysRevLett.126.100503",
    "10.1007/s11128-024-04593-6",
    "10.1364/opticaq.570625",
    "10.1038/s41598-019-48844-4",
    "10.1063/5.0342762",
    "10.1007/s10773-026-06288-3",
    "10.1103/physrevresearch.2.043317",
    "10.1038/s41578-022-00473-4",

    # Recent Top-tier Plasmonic Purcell, Quantum Emitters & Nanophotonics (2018-2026)
    "10.1038/s41565-020-00831-x",
    "10.1126/sciadv.abc8268",
    "10.1038/s41565-019-0551-x",
    "10.1038/s41578-021-00346-6",
    "10.1038/s41567-020-0935-z",
    "10.1103/PhysRevLett.124.033601",
    "10.1103/PhysRevLett.128.083601",
    "10.1103/PhysRevLett.125.153602",
    "10.1038/s41377-019-0241-z",
    "10.1038/s41467-021-25597-4",
    "10.1021/acs.nanolett.0c03632",
    "10.1021/acsphotonics.8b00306",
    "10.1364/optica.486167",
    "10.1039/c8nr01527a",
    "10.1088/1361-6455/abf6e1",
    "10.1140/epjd/s10053-026-01211-1",
    "10.1038/s41565-022-01187-0",
    "10.1021/acs.nanolett.2c02741",
    "10.1103/PhysRevLett.123.087401",
    "10.1126/science.aay9876",
    "10.1038/s41586-020-2374-1",
    "10.1038/s41565-021-00992-7",
    "10.1103/PhysRevX.10.021053",
    "10.1038/s41467-022-31122-8",
    "10.1103/PhysRevLett.127.143603",
    "10.1021/acs.nanolett.1c02821",
    "10.1038/s41565-023-01389-w"
]

print(f"Total candidate DOIs: {len(candidate_dois)}", flush=True)
verified = []
for i, doi in enumerate(candidate_dois):
    res = get_crossref_doi(doi)
    if res['valid']:
        print(f"[{i+1}/{len(candidate_dois)}] OK: {doi} -> {res['title'][:40]}... ({res['year']}) in {res['journal']}", flush=True)
        verified.append(res)
    else:
        print(f"[{i+1}/{len(candidate_dois)}] FAILED: {doi} -> {res.get('error')}", flush=True)
    time.sleep(0.1)

print(f"\nSuccessfully verified {len(verified)} peer-reviewed papers!", flush=True)
with open("scripts/verified_recent_papers.json", "w", encoding="utf-8") as f:
    json.dump(verified, f, indent=2)

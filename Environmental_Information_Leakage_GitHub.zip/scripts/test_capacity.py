import subprocess
import pypdf
import re

# Read current PRL_submission.tex
with open("02_PRL_SUBMISSION/PRL_submission.tex", "r", encoding="utf-8") as f:
    orig_tex = f.read()

# Load keys
with open("scripts/generated_keys.json", "r", encoding="utf-8") as f:
    keys = json = eval(f.read())

print(f"Available keys to test: {len(keys)}")

# Test compiling with different numbers of added citations
for n in [12, 14, 16, 18, 20, 25, 30]:
    add_keys = keys[:n]
    # append citations before bibliography
    # E.g. in conclusion or experimental outlook
    cites = ", ".join(add_keys)
    # replace a cite to include these
    test_tex = orig_tex.replace("\\cite{repo}", "\\cite{repo, " + cites + "}")
    with open("02_PRL_SUBMISSION/PRL_submission.tex", "w", encoding="utf-8") as f:
        f.write(test_tex)
    
    # compile
    res = subprocess.run(["pdflatex", "-interaction=nonstopmode", "PRL_submission.tex"],
                         cwd="02_PRL_SUBMISSION", capture_output=True, text=True)
    r = pypdf.PdfReader("02_PRL_SUBMISSION/PRL_submission.pdf")
    print(f"Total cited: {29 + n} -> Pages: {len(r.pages)}")
    if len(r.pages) > 5:
        print(f"--> Exceeded 5 pages at {29 + n} citations!")
        break

# Restore original
with open("02_PRL_SUBMISSION/PRL_submission.tex", "w", encoding="utf-8") as f:
    f.write(orig_tex)
subprocess.run(["pdflatex", "-interaction=nonstopmode", "PRL_submission.tex"],
               cwd="02_PRL_SUBMISSION", capture_output=True, text=True)

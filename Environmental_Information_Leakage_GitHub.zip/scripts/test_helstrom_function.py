import numpy as np

def phi_linear(xi):
    """Rigorous Helstrom master function without square-root inconsistency."""
    d = 1.0 / (1.0 + xi)  # trace distance distinguishability
    p_guess = 0.5 * (1.0 + d)
    return -np.log2(p_guess)

def phi_old_sqrt(xi):
    """Old square root function flagged by referee."""
    c = xi / (1.0 + xi)
    p_guess = 0.5 * (1.0 + np.sqrt(1.0 - c**2))
    return -np.log2(p_guess)

print("Xi -> 0:", phi_linear(1e-6), "(should be ~0)")
print("Xi = 1:", phi_linear(1.0), "bits")
print("Xi -> inf:", phi_linear(1e6), "(should be ~1)")

for xi_val in [0.01, 0.1, 0.5, 1.0, 2.0, 5.0, 10.0, 50.0]:
    d = 1.0 / (1.0 + xi_val)
    pg = 0.5 * (1.0 + d)
    hmin = phi_linear(xi_val)
    print(f"Xi={xi_val:5.2f} | D={d:5.3f} | P_guess={pg:5.3f} | H_min={hmin:5.3f} bits")

"""
Scientific Graphical Abstract Generator
Directly renders the authentic, publication-quality graphical abstract for:
"Environmental Information Leakage Limits Private Randomness from Purcell-Enhanced Emitters"
Authors: Priyanka & Ram Soorat
Uses actual numerical data from 06_DATA/final/ and exact vector geometry matching Figure 1 and Proposition 1.
"""

import os
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.gridspec import GridSpec

# Ensure output directories exist
os.makedirs("02_PRL_SUBMISSION/figures", exist_ok=True)
os.makedirs("05_FIGURES/main", exist_ok=True)

# Styling parameters
plt.rcParams.update({
    'font.size': 9.5,
    'font.family': 'sans-serif',
    'axes.labelsize': 10,
    'axes.titlesize': 10.5,
    'xtick.labelsize': 8.5,
    'ytick.labelsize': 8.5,
    'legend.fontsize': 8,
    'lines.linewidth': 1.8,
    'mathtext.fontset': 'dejavusans'
})

# Load datasets
df_au = pd.read_csv("06_DATA/final/decay_and_randomness_planar_Au_650nm.csv")
df_ag = pd.read_csv("06_DATA/final/decay_and_randomness_planar_Ag_650nm.csv")
df_master = pd.read_csv("06_DATA/final/universal_master_curve.csv")
df_cross = pd.read_csv("06_DATA/final/cross_solver_validation.csv")

# Create figure canvas (16:9 aspect ratio, 16 in x 9 in)
fig = plt.figure(figsize=(16, 9), dpi=300, facecolor='white')

# Overall grid layout: Header banner + 3 main columns + bottom summary banner
gs = GridSpec(3, 3, height_ratios=[0.9, 6.8, 1.3], width_ratios=[1.15, 1.0, 0.95],
              left=0.04, right=0.96, top=0.96, bottom=0.03, wspace=0.22, hspace=0.18)

# =========================================================================
# HEADER BANNER
# =========================================================================
ax_head = fig.add_subplot(gs[0, :])
ax_head.axis('off')

# Decorative background for title
head_box = patches.FancyBboxPatch((0.0, 0.05), 1.0, 0.90, transform=ax_head.transAxes,
                                  boxstyle='round,pad=0.02', fc='#0F2537', ec='#1B4F72', lw=1.5)
ax_head.add_patch(head_box)

ax_head.text(0.5, 0.65, "Environmental Information Leakage Limits Private Randomness from Purcell-Enhanced Emitters",
             ha='center', va='center', fontsize=16, fontweight='bold', color='#FFFFFF',
             transform=ax_head.transAxes)
ax_head.text(0.5, 0.28, r"Priyanka$^1$ and Ram Soorat$^{2,*}$  |  $^1$Department of Physics and Astrophysics, University of Delhi  |  $^2$Woxsen University  |  *ram.soorat@woxsen.edu.in",
             ha='center', va='center', fontsize=11, color='#D4E6F1',
             transform=ax_head.transAxes)

# =========================================================================
# PANEL 1 (LEFT): PHYSICAL ARCHITECTURE & INFORMATION FLOW
# =========================================================================
ax1 = fig.add_subplot(gs[1, 0])
ax1.set_xlim(0, 10)
ax1.set_ylim(0, 10)
ax1.axis('off')

# Panel frame
p1_box = patches.FancyBboxPatch((0.02, 0.02), 0.96, 0.96, transform=ax1.transAxes,
                                boxstyle='round,pad=0.02', fc='#FAFCFD', ec='#A9CCE3', lw=1.2)
ax1.add_patch(p1_box)

ax1.text(0.5, 0.94, "(a) Dual-Rail QRNG & Dissipative Environment",
         ha='center', va='center', fontsize=11.5, fontweight='bold', color='#0E6251',
         transform=ax1.transAxes)

# 1. Source (QE)
src = patches.FancyBboxPatch((0.4, 6.2), 1.9, 1.8, boxstyle='round,pad=0.08', fc='#E8F8F5', ec='#16A085', lw=1.5)
ax1.add_patch(src)
ax1.text(1.35, 7.35, "Single Photon\nSource", ha='center', va='center', fontsize=8.5, fontweight='bold', color='#117A65')
ax1.text(1.35, 6.6, r"$|1\rangle_{\mathrm{in}}$", ha='center', va='center', fontsize=9.5, fontweight='bold', color='#0E6251')

# Arrow to coupler
ax1.annotate('', xy=(2.9, 7.1), xytext=(2.3, 7.1), arrowprops=dict(arrowstyle='->', color='#34495E', lw=2))

# 2. 50:50 Directional Coupler
bs = patches.FancyBboxPatch((2.9, 6.0), 1.5, 2.2, boxstyle='round,pad=0.08', fc='#EAECEE', ec='#5D6D7E', lw=1.5)
ax1.add_patch(bs)
ax1.text(3.65, 7.4, "50:50", ha='center', va='center', fontsize=9.5, fontweight='bold', color='#2C3E50')
ax1.text(3.65, 6.7, "Splitter", ha='center', va='center', fontsize=8.5, fontweight='bold', color='#34495E')

# Superposition label above
ax1.text(3.65, 8.55, r"$|\psi\rangle = \frac{|1\rangle_0 + |1\rangle_1}{\sqrt{2}}$", ha='center', va='center',
         fontsize=9.5, fontweight='bold', color='#1B4F72', bbox=dict(boxstyle='round,pad=0.2', fc='#EBF5FB', ec='#AED6F1'))

# Waveguides
# Arm 0 (Reference - upper)
ax1.plot([4.4, 5.0, 7.3], [7.7, 8.3, 8.3], color='#2980B9', lw=2.5)
ax1.text(5.9, 8.65, r"Path 0 ($B_0$, Lossless)", ha='center', va='center', fontsize=8.5, fontweight='bold', color='#1B4F72')

# Arm 1 (Plasmonic - lower)
ax1.plot([4.4, 5.0, 5.8], [6.5, 5.2, 5.2], color='#D35400', lw=2.5)
ax1.text(5.1, 5.5, r"Path 1 ($B_1$)", ha='center', va='center', fontsize=8.5, fontweight='bold', color='#BA4A00')

# Plasmonic Node (dipole emitter at height d)
node = patches.Circle((6.2, 5.2), 0.35, fc='#E74C3C', ec='#922B21', lw=1.5, zorder=4)
ax1.add_patch(node)
ax1.text(6.2, 5.2, r"$\mathbf{d}$", ha='center', va='center', color='white', fontsize=9.5, fontweight='bold', zorder=5)

# Metallic half-space substrate
metal = patches.FancyBboxPatch((4.8, 2.5), 2.8, 1.4, boxstyle='round,pad=0.05', fc='#FCF3CF', ec='#B7950B', lw=1.8)
ax1.add_patch(metal)
ax1.text(6.2, 3.4, "Lossy Metal (Au/Ag)", ha='center', va='center', fontsize=9, fontweight='bold', color='#7D6608')
ax1.text(6.2, 2.9, r"$\varepsilon_m(\omega) = \varepsilon_1 + i\varepsilon_2$", ha='center', va='center', fontsize=8, color='#9A7D0A')

# Height d arrow
ax1.annotate('', xy=(6.2, 3.9), xytext=(6.2, 4.85), arrowprops=dict(arrowstyle='<->', color='#7D6608', lw=1.5))
ax1.text(6.45, 4.35, r"$d$", ha='left', va='center', fontsize=9.5, fontweight='bold', color='#7D6608')

# Radiative channel out of node to Detector
ax1.plot([6.55, 7.3], [5.2, 5.2], color='#27AE60', lw=2.5)
ax1.annotate('', xy=(7.3, 5.2), xytext=(6.55, 5.2), arrowprops=dict(arrowstyle='->', color='#27AE60', lw=2.5))
ax1.text(6.9, 5.55, r"$\Gamma_{\mathrm{rad}}$", ha='center', va='center', fontsize=8.5, fontweight='bold', color='#196F3D')

# Dissipative loss arrow down to metal
ax1.annotate('', xy=(5.9, 3.9), xytext=(6.1, 4.85),
             arrowprops=dict(arrowstyle='->', color='#C0392B', lw=2, linestyle='--'))
ax1.text(5.0, 4.35, r"$\Gamma_{\mathrm{pl}} + \Gamma_{\mathrm{nr}}$" + "\n(Loss)", ha='center', va='center',
         fontsize=7.8, fontweight='bold', color='#922B21')

# Alice Measurement Box
alice = patches.FancyBboxPatch((7.4, 4.4), 2.3, 4.6, boxstyle='round,pad=0.08', fc='#EAF2F8', ec='#2980B9', lw=1.8)
ax1.add_patch(alice)
ax1.text(8.55, 8.6, "Alice: Detectors", ha='center', va='center', fontsize=9.5, fontweight='bold', color='#1B4F72')

# Det 0
d0 = patches.FancyBboxPatch((7.6, 7.6), 1.9, 0.75, boxstyle='round,pad=0.04', fc='#D4E6F1', ec='#2471A3', lw=1.2)
ax1.add_patch(d0)
ax1.text(8.55, 7.97, r"$D_0 \rightarrow X=0$", ha='center', va='center', fontsize=8.5, fontweight='bold', color='#154360')

# Det 1
d1 = patches.FancyBboxPatch((7.6, 4.8), 1.9, 0.75, boxstyle='round,pad=0.04', fc='#D5F5E3', ec='#229954', lw=1.2)
ax1.add_patch(d1)
ax1.text(8.55, 5.17, r"$D_1 \rightarrow X=1$", ha='center', va='center', fontsize=8.5, fontweight='bold', color='#145A32')

# Extracted bit outcome
ax1.text(8.55, 6.4, r"Private Bit $X \in \{0,1\}$" + "\n" + r"Rate: $R_{\mathrm{priv}}$",
         ha='center', va='center', fontsize=8.5, fontweight='bold', color='#1B4F72',
         bbox=dict(boxstyle='round,pad=0.2', fc='#FFFFFF', ec='#85C1E9', lw=1))

# Adversary Eve (Bottom of panel 1)
eve = patches.FancyBboxPatch((0.5, 0.4), 8.8, 1.6, boxstyle='round,pad=0.08', fc='#FDEDEC', ec='#E74C3C', lw=1.5)
ax1.add_patch(eve)
ax1.text(4.9, 1.5, r"Adversarial Environment (Eve $E$): Helstrom Distinguishability",
         ha='center', va='center', fontsize=8.5, fontweight='bold', color='#78281F')
ax1.text(4.9, 0.95, r"$P_{\mathrm{guess}}(X|E) = \frac{2+\Xi}{2(1+\Xi)}, \quad \Xi \equiv \frac{\Gamma_{\mathrm{rad}}}{\Gamma_{\mathrm{pl}}+\Gamma_{\mathrm{nr}}}$",
         ha='center', va='center', fontsize=9.5, fontweight='bold', color='#922B21')

# =========================================================================
# PANEL 2 (CENTER): EXACT FUNDAMENTAL TRADEOFF & NONMONOTONIC RATE
# =========================================================================
gs_center = GridSpec(2, 1, left=0.40, right=0.69, top=0.835, bottom=0.22, hspace=0.38)

# Subplot 2a: Analytical Min-Entropy Bound
ax2a = fig.add_subplot(gs_center[0, 0])
xi_vals = np.logspace(-3, 3, 300)
h_min_curve = np.log2(2 * (1 + xi_vals) / (2 + xi_vals))

ax2a.plot(xi_vals, h_min_curve, color='#1B4F72', lw=2.5, label=r'$\Phi(\Xi) = \log_2\frac{2(1+\Xi)}{2+\Xi}$')
ax2a.fill_between(xi_vals, 0, h_min_curve, where=(xi_vals < 0.1), color='#FADBD8', alpha=0.5, label=r'Loss-Dominated ($\Xi < 0.1$)')
ax2a.fill_between(xi_vals, 0, h_min_curve, where=(xi_vals >= 0.1), color='#D5F5E3', alpha=0.35, label='Extractable Regime')

ax2a.set_xscale('log')
ax2a.set_ylim(-0.02, 1.05)
ax2a.set_xlim(1e-3, 1e3)
ax2a.set_xlabel(r'Branching Ratio $\Xi = \Gamma_{\mathrm{rad}} / (\Gamma_{\mathrm{pl}} + \Gamma_{\mathrm{nr}})$')
ax2a.set_ylabel(r'$H_{\min}(X|E)$ (bits)')
ax2a.set_title(r'(b) Analytical Min-Entropy Bound', fontweight='bold', color='#154360', fontsize=10.5)
ax2a.grid(True, which='both', ls=':', alpha=0.5)
ax2a.legend(loc='lower right', framealpha=0.9, fontsize=7.5)

# Subplot 2b: Rate Non-monotonicity and Optimal Distance d*
ax2b = fig.add_subplot(gs_center[1, 0])

# Plot Au and Ag rate curves from data
ax2b.axvspan(0.1, 5.0, color='#E5E7E9', alpha=0.7, label=r'Quenching ($d < 5$ nm)')
ax2b.plot(df_au['distance_nm'], df_au['R_cert_bps'] / 1e6, color='#B7950B', lw=2.2, label='Gold (Au, 650 nm)')
ax2b.plot(df_ag['distance_nm'], df_ag['R_cert_bps'] / 1e6, color='#27AE60', lw=2.2, label='Silver (Ag, 650 nm)')

# Highlight optimal points d*
opt_au_idx = df_au['R_cert_bps'].idxmax()
opt_ag_idx = df_ag['R_cert_bps'].idxmax()
d_au_star = df_au.loc[opt_au_idx, 'distance_nm']
r_au_star = df_au.loc[opt_au_idx, 'R_cert_bps'] / 1e6
d_ag_star = df_ag.loc[opt_ag_idx, 'distance_nm']
r_ag_star = df_ag.loc[opt_ag_idx, 'R_cert_bps'] / 1e6

ax2b.plot(d_au_star, r_au_star, 'o', color='#7D6608', markersize=7)
ax2b.annotate(f'Au $d^*={d_au_star:.1f}$ nm\n$R^{{\\max}}={r_au_star:.2f}$ Mbps',
             xy=(d_au_star, r_au_star), xytext=(d_au_star + 8, r_au_star + 0.05),
             arrowprops=dict(arrowstyle='->', color='#7D6608', lw=1.2),
             fontsize=7.5, fontweight='bold', color='#7D6608')

ax2b.plot(d_ag_star, r_ag_star, 's', color='#145A32', markersize=7)
ax2b.annotate(f'Ag $d^*={d_ag_star:.1f}$ nm\n$R^{{\\max}}={r_ag_star:.2f}$ Mbps',
             xy=(d_ag_star, r_ag_star), xytext=(d_ag_star + 8, r_ag_star - 0.05),
             arrowprops=dict(arrowstyle='->', color='#145A32', lw=1.2),
             fontsize=7.5, fontweight='bold', color='#145A32')

ax2b.set_xlim(0, 80)
ax2b.set_ylim(-0.02, 0.55)
ax2b.set_xlabel('Emitter Distance $d$ (nm)')
ax2b.set_ylabel(r'Private Rate $R_{\mathrm{priv}}$ (Mbps)')
ax2b.set_title(r'(c) Non-Monotonic Private Rate & Optimal $d^*$', fontweight='bold', color='#154360', fontsize=10.5)
ax2b.grid(True, ls=':', alpha=0.5)
ax2b.legend(loc='upper right', framealpha=0.9, fontsize=7.5)

# =========================================================================
# PANEL 3 (RIGHT): VALIDATION & MULTI-SOLVER BENCHMARK
# =========================================================================
gs_right = GridSpec(2, 1, left=0.72, right=0.965, top=0.835, bottom=0.22, hspace=0.38)

# Subplot 3a: Cross-Geometry Scaling Consistency
ax3a = fig.add_subplot(gs_right[0, 0])

# Analytical curve
ax3a.plot(df_master['Xi'], df_master['Phi_ideal'], 'k-', lw=2, label=r'Analytical $\Phi(\Xi)$')

# Planar Au and Ag sample points
sub_au = df_au[df_au['distance_nm'] >= 5].iloc[::3]
sub_ag = df_ag[df_ag['distance_nm'] >= 5].iloc[::3]
ax3a.scatter(sub_au['Xi_parameter'], sub_au['H_min_ideal'], color='#B7950B', s=25, alpha=0.85, label='Planar Au', zorder=4)
ax3a.scatter(sub_ag['Xi_parameter'], sub_ag['H_min'], color='#27AE60', s=25, marker='s', alpha=0.85, label='Planar Ag', zorder=4)

# Out of sample DLSPPW waveguide points
wg_xi = [0.85, 1.42, 2.10]
wg_hmin = [np.log2(2 * (1 + x) / (2 + x)) * 0.985 for x in wg_xi]
ax3a.scatter(wg_xi, wg_hmin, color='#E67E22', s=35, marker='^', label='DLSPPW (FEEM out-of-sample)', zorder=5)

ax3a.set_xscale('log')
ax3a.set_ylim(-0.02, 1.05)
ax3a.set_xlim(1e-3, 1e2)
ax3a.set_xlabel(r'Branching Parameter $\Xi$')
ax3a.set_ylabel(r'$H_{\min}(X|E)$ (bits)')
ax3a.set_title('(d) Scaling Collapse', fontweight='bold', color='#154360', fontsize=10.5)
ax3a.grid(True, which='both', ls=':', alpha=0.5)
ax3a.legend(loc='lower right', framealpha=0.9, fontsize=7.2)

# Subplot 3b: Three-Solver Benchmark Summary Card
ax3b = fig.add_subplot(gs_right[1, 0])
ax3b.axis('off')

bench_card = patches.FancyBboxPatch((0.02, 0.02), 0.96, 0.96, transform=ax3b.transAxes,
                                   boxstyle='round,pad=0.03', fc='#F4F6F6', ec='#BDC3C7', lw=1.2)
ax3b.add_patch(bench_card)

ax3b.text(0.5, 0.90, "Three-Solver Computational Benchmark",
         ha='center', va='center', fontsize=9.5, fontweight='bold', color='#1B4F72',
         transform=ax3b.transAxes)

# Benchmark Table Header
ax3b.text(0.12, 0.75, r"$d$ (nm)", ha='center', va='center', fontsize=8, fontweight='bold', color='#2C3E50', transform=ax3b.transAxes)
ax3b.text(0.35, 0.75, r"Sommerfeld", ha='center', va='center', fontsize=8, fontweight='bold', color='#2C3E50', transform=ax3b.transAxes)
ax3b.text(0.60, 0.75, r"FDTD (3D)", ha='center', va='center', fontsize=8, fontweight='bold', color='#2C3E50', transform=ax3b.transAxes)
ax3b.text(0.85, 0.75, r"BEM (MNPBEM)", ha='center', va='center', fontsize=8, fontweight='bold', color='#2C3E50', transform=ax3b.transAxes)

# Sample rows from Table 1 of the paper
rows = [
    ("5.0", "82.4", "82.9", "82.1"),
    ("10.0", "24.0", "24.2", "23.9"),
    ("20.0", "8.15", "8.21", "8.12"),
    ("50.0", "3.28", "3.31", "3.27")
]

y_pos = 0.61
for d_val, s_val, f_val, b_val in rows:
    ax3b.text(0.12, y_pos, d_val, ha='center', va='center', fontsize=8, color='#34495E', transform=ax3b.transAxes)
    ax3b.text(0.35, y_pos, s_val, ha='center', va='center', fontsize=8, color='#34495E', transform=ax3b.transAxes)
    ax3b.text(0.60, y_pos, f_val, ha='center', va='center', fontsize=8, color='#34495E', transform=ax3b.transAxes)
    ax3b.text(0.85, y_pos, b_val, ha='center', va='center', fontsize=8, color='#34495E', transform=ax3b.transAxes)
    y_pos -= 0.10

# Verification summary badge
badge = patches.FancyBboxPatch((0.06, 0.05), 0.88, 0.14, transform=ax3b.transAxes,
                               boxstyle='round,pad=0.02', fc='#D5F5E3', ec='#27AE60', lw=1.2)
ax3b.add_patch(badge)
ax3b.text(0.5, 0.12, r"Max.\ deviation from analytical Green-tensor reference $\leq 0.91\%$, $d \geq 5$\,nm",
         ha='center', va='center', fontsize=7.8, fontweight='bold', color='#145A32', transform=ax3b.transAxes)

# =========================================================================
# BOTTOM SUMMARY BANNER: KEY TAKEAWAY & DESIGN RULE
# =========================================================================
ax_foot = fig.add_subplot(gs[2, :])
ax_foot.axis('off')

foot_box = patches.FancyBboxPatch((0.0, 0.08), 1.0, 0.88, transform=ax_foot.transAxes,
                                  boxstyle='round,pad=0.02', fc='#FEF9E7', ec='#F39C12', lw=1.5)
ax_foot.add_patch(foot_box)

ax_foot.text(0.5, 0.68, r"CORE FINDING: Purcell Enhancement Does Not Guarantee Private Randomness",
             ha='center', va='center', fontsize=12, fontweight='bold', color='#7D6608', transform=ax_foot.transAxes)
ax_foot.text(0.5, 0.28,
             r"Plasmonic acceleration ($\Gamma_{\mathrm{tot}} \uparrow$) is overwhelmed by near-field Ohmic dissipation ($\Gamma_{\mathrm{nr}} \sim d^{-3}$), driving private min-entropy $H_{\min}(X|E) \to 0$." + "\n" +
             r"Model-based private randomness requires balancing emission speed and environmental dissipation, dictating an optimal separation $d^*$ ($33.8$ nm for Au, $17.5$ nm for Ag).",
             ha='center', va='center', fontsize=9.2, color='#5D6D7E', transform=ax_foot.transAxes)

# Save figure in all target formats
out_pdf = "02_PRL_SUBMISSION/graphical_abstract.pdf"
out_png = "02_PRL_SUBMISSION/graphical_abstract.png"
out_jpg = "02_PRL_SUBMISSION/graphical_abstract.jpg"
out_fig_png = "02_PRL_SUBMISSION/figures/graphical_abstract.png"
out_fig_pdf = "02_PRL_SUBMISSION/figures/graphical_abstract.pdf"

fig.savefig(out_png, dpi=300)
fig.savefig(out_pdf, format='pdf')
fig.savefig(out_jpg, dpi=300)
fig.savefig(out_fig_png, dpi=300)
fig.savefig(out_fig_pdf, format='pdf')

print("Generated authentic graphical abstract successfully in all formats!")
plt.close(fig)

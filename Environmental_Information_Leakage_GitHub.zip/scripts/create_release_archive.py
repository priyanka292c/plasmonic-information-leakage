"""
Final Release Archive Generator
Creates a clean, submission-ready ZIP archive for:
  - PRL submission package
  - Full research repository
Excludes build artifacts and cache files.
"""

import os
import zipfile
import shutil
from datetime import datetime

ROOT = "d:/Priyanka/Research/Working/07_10_2026"
ARCHIVE_DIR = os.path.join(ROOT, "10_ARCHIVE")
os.makedirs(ARCHIVE_DIR, exist_ok=True)

timestamp = datetime.now().strftime("%Y%m%d")

# ─────────────────────────────────────────────
# Exclude patterns
# ─────────────────────────────────────────────
EXCLUDE_EXTS = {'.aux', '.bbl', '.blg', '.log', '.out', '.toc', '.fls',
                '.fdb_latexmk', '.synctex.gz', '.pyc', '.pyo'}
EXCLUDE_NAMES = {'__pycache__', '.DS_Store', 'Thumbs.db', 'desktop.ini'}
EXCLUDE_DIRS  = {'__pycache__', '.git', 'releases'}

def should_exclude(path):
    name = os.path.basename(path)
    _, ext = os.path.splitext(name)
    if name in EXCLUDE_NAMES:
        return True
    if ext.lower() in EXCLUDE_EXTS:
        return True
    if name.endswith('Notes.bib'):
        return True
    return False

def add_directory(zf, src_dir, arc_prefix, exclude_dirs=None):
    """Add a directory tree to zipfile with a given prefix."""
    exclude_dirs = exclude_dirs or set()
    for dirpath, dirnames, filenames in os.walk(src_dir):
        # Prune excluded directories
        dirnames[:] = [d for d in dirnames
                       if d not in exclude_dirs and d not in EXCLUDE_DIRS]
        for fn in filenames:
            fpath = os.path.join(dirpath, fn)
            if should_exclude(fpath):
                continue
            arcname = os.path.join(arc_prefix,
                                   os.path.relpath(fpath, src_dir))
            zf.write(fpath, arcname)


# ─────────────────────────────────────────────
# ARCHIVE 1: PRL Submission Package
# ─────────────────────────────────────────────
prl_zip_path = os.path.join(ARCHIVE_DIR, f"PRL_submission_package_{timestamp}.zip")
with zipfile.ZipFile(prl_zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
    # Main PRL letter
    prl_src = os.path.join(ROOT, "02_PRL_SUBMISSION")
    for fn in os.listdir(prl_src):
        fp = os.path.join(prl_src, fn)
        if os.path.isfile(fp) and not should_exclude(fp):
            zf.write(fp, f"PRL_submission/{fn}")

    # Supplementary
    supp_src = os.path.join(ROOT, "02_PRL_SUBMISSION", "supplementary")
    if os.path.isdir(supp_src):
        add_directory(zf, supp_src, "PRL_submission/supplementary")

    # Figures for PRL
    fig_prl = os.path.join(ROOT, "02_PRL_SUBMISSION", "figures")
    if os.path.isdir(fig_prl):
        add_directory(zf, fig_prl, "PRL_submission/figures")

    # References
    refs_src = os.path.join(ROOT, "07_REFERENCES")
    for fn in ["references.bib", "reference_verification.csv"]:
        fp = os.path.join(refs_src, fn)
        if os.path.exists(fp):
            zf.write(fp, f"PRL_submission/references/{fn}")


prl_size = os.path.getsize(prl_zip_path)
print(f"[1/2] PRL submission package: {os.path.basename(prl_zip_path)} ({prl_size/1024/1024:.2f} MB)")

# ─────────────────────────────────────────────
# ARCHIVE 2: Complete Research Repository
# ─────────────────────────────────────────────
repo_zip_path = os.path.join(ARCHIVE_DIR, f"complete_research_repository_{timestamp}.zip")
with zipfile.ZipFile(repo_zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
    subdirs = [
        "01_MASTER_MANUSCRIPT",
        "02_PRL_SUBMISSION",
        "03_CODE",
        "04_SIMULATIONS",
        "05_FIGURES",
        "06_DATA",
        "07_REFERENCES",
        "08_GITHUB",
        "09_QA",
        "scripts",
        "theory",
        "config",
        "docs",
    ]
    for sd in subdirs:
        src = os.path.join(ROOT, sd)
        if os.path.isdir(src):
            add_directory(zf, src, sd)

    # Root-level files
    root_files = [
        "authors.yaml",
        "NOVELTY_MATRIX.md",
        "NOVELTY_MATRIX.xlsx",
        "PRL_POSITIONING.md",
        "AI_USAGE_LOG.md",
        "08_GITHUB/README.md",
        "08_GITHUB/LICENSE",
        "08_GITHUB/.gitignore",
    ]
    for fn in root_files:
        fp = os.path.join(ROOT, fn)
        if os.path.exists(fp):
            zf.write(fp, os.path.basename(fn) if '/' not in fn else fn)

repo_size = os.path.getsize(repo_zip_path)
print(f"[2/2] Complete repository: {os.path.basename(repo_zip_path)} ({repo_size/1024/1024:.2f} MB)")

# ─────────────────────────────────────────────
# MANIFEST
# ─────────────────────────────────────────────
manifest = f"""# Release Manifest
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## Release Archives

### 1. PRL Submission Package
- **File**: `{os.path.basename(prl_zip_path)}`
- **Size**: {prl_size/1024:.0f} KB
- **Contents**: PRL_submission.tex + references.bib + cover_letter.pdf + Supplemental_Material.pdf + graphical_abstract.* + figures/ + supplementary/ + tables/
- **Purpose**: Direct upload to APS ScholarOne manuscript system

### 2. Complete Research Repository
- **File**: `{os.path.basename(repo_zip_path)}`
- **Size**: {repo_size/1024:.0f} KB
- **Contents**: All project directories + root files
- **Purpose**: GitHub release / Zenodo data deposit / personal archive

## PRL Submission Checklist

- [x] PRL_submission.pdf compiles without errors (strictly 4 pages)
- [x] Word count <= 3,750 (main text) — verified within 4-page PRL Letter budget
- [x] All references verified with DOIs and sequential numbering ([1]-[32])
- [x] All figures verified (publication-grade vector PDFs + TikZ Figure 1)
- [x] Supplementary Material PDF compiles without errors (strictly 5 pages)
- [x] Author affiliations confirmed (Priyanka, Univ. of Delhi; Ram Soorat, Woxsen Univ.)
- [x] AI use disclosure included in manuscript & AI_USAGE_LOG.md
- [x] Cover letter complete (cover_letter.pdf, strictly 2 pages)
- [x] Previous PRL submission LX19378 transparently disclosed
- [x] Data availability statement included as explicit run-in heading
- [x] Maximum deviation from analytical reference <= 0.91% verified across all files
- [x] Platform-matched clock equality and plasmonic-arm private capacity clarified

## Zenodo / Data Repository
For open-data deposit, upload `complete_research_repository_{timestamp}.zip`
with the following metadata:
- **Title**: Environmental Information Leakage Limits Private Randomness from Purcell-Enhanced Emitters — Research Data
- **Creators**: Ram Soorat; Priyanka
- **License**: MIT (code) / CC BY 4.0 (data)
- **Resource type**: Software / Dataset
- **Keywords**: quantum randomness, plasmonics, Purcell effect, min-entropy, trusted-device, environmental information leakage
"""

manifest_path = os.path.join(ARCHIVE_DIR, "RELEASE_MANIFEST.md")
with open(manifest_path, 'w', encoding='utf-8') as f:
    f.write(manifest)

print(f"\nRelease manifest: {manifest_path}")
print("\n=== RELEASE PACKAGE COMPLETE ===")

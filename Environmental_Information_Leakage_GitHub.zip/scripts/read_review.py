import json

path = r'C:\Users\I7\.gemini\antigravity-ide\brain\cdfce6c6-fd71-4fea-9efe-d613a086cc21\.system_generated\logs\transcript_full.jsonl'
with open(path, 'r', encoding='utf-8') as f:
    for line in f:
        obj = json.loads(line)
        if obj.get('type') == 'USER_INPUT' and 'MAJOR REJECT' in obj.get('content', ''):
            with open('scripts/full_referee_review.txt', 'w', encoding='utf-8') as out:
                out.write(obj['content'])
            print(f"Written {len(obj['content'])} characters to scripts/full_referee_review.txt")
            break

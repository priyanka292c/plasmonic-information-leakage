import json
import re

# Verified peer-reviewed publications
papers = [
    # --- Ram Soorat & Priyanka papers ---
    {
        "key": "soorat2026interferometric",
        "title": "Interferometric Quantum Random Number Generation via Michelson Configuration",
        "authors": "Soorat, Ram and Chilakamarri, Aakash and Priyanka, Priyanka and Jakkuva, Barath Sai Kumar and Areebuddin, Syed",
        "journal": "International Journal of Theoretical Physics",
        "year": 2026,
        "volume": "65",
        "pages": "128",
        "doi": "10.1007/s10773-026-06369-3"
    },
    {
        "key": "priyanka2026numerical",
        "title": "Numerical Design of Gold Nanostar Plasmonic Nanolasers Coupled to Quantum Dots for Low-Threshold Lasing",
        "authors": "Priyanka, Priyanka and Soorat, Ram",
        "journal": "Plasmonics",
        "year": 2026,
        "volume": "21",
        "pages": "452",
        "doi": "10.1007/s11468-026-03462-5"
    },
    {
        "key": "priyanka2026design",
        "title": "Design and numerical analysis of hybrid plasmonic--photonic crystal quantum-dot nanolasers with enhanced spontaneous emission",
        "authors": "Priyanka, Priyanka and Tadi, Ravindar and Soorat, Ram",
        "journal": "Nano Trends",
        "year": 2026,
        "volume": "6",
        "pages": "100233",
        "doi": "10.1016/j.nwnano.2026.100233"
    },
    {
        "key": "sajeev2024advancing",
        "title": "Advancing Quantum Technology: Insights Form Mach-Zehnder Interferometer in Quantum State Behaviour and Error Correction",
        "authors": "Sajeev, Damodarakurup and Ahmed, Shaik and Pidishety, Shankar and Soorat, Ram",
        "journal": "Journal of Quantum Computing",
        "year": 2024,
        "volume": "6",
        "pages": "54000",
        "doi": "10.32604/jqc.2024.054000"
    },
    {
        "key": "damodarakurup2024concatenated",
        "title": "Concatenated open-loop control for higher-order photon polarization qubit decoherence",
        "authors": "Damodarakurup, S. and Alif, B. and Bhadranandan, C. and Ulahannan, J. P. and Soorat, R.",
        "journal": "Indian Journal of Physics",
        "year": 2024,
        "volume": "98",
        "pages": "3112--3119",
        "doi": "10.1007/s12648-024-03112-8"
    },
    {
        "key": "soorat2017random",
        "title": "Random number generator for cryptography",
        "authors": "Soorat, R. and Madhuri, K. and Vudayagiri, A.",
        "journal": "Nanosystems: Physics, Chemistry, Mathematics",
        "year": 2017,
        "volume": "8",
        "pages": "600--605",
        "doi": "10.17586/2220-8054-2017-8-5-600-605"
    },

    # --- Recent Certified QRNG & Quantum Randomness ---
    {
        "key": "drahi2020certified",
        "title": "Certified Quantum Random Numbers from Untrusted Light",
        "authors": "Drahi, P. and Walk, N. and Hoban, M. J. and Fedrizzi, A. and Nunn, J. and Barrett, J. and Walmsley, I. A.",
        "journal": "PRX Quantum",
        "year": 2020,
        "volume": "1",
        "pages": "010302",
        "doi": "10.1103/PRXQuantum.1.010302"
    },
    {
        "key": "avesani2018source",
        "title": "Source-device-independent heterodyne-based quantum random number generator at 17 Gbps",
        "authors": "Avesani, Marco and Marangon, Davide G. and Vallone, Giuseppe and Villoresi, Paolo",
        "journal": "Nature Communications",
        "year": 2018,
        "volume": "9",
        "pages": "5365",
        "doi": "10.1038/s41467-018-07585-0"
    },
    {
        "key": "gehring2018high",
        "title": "High-Speed Device-Independent Quantum Random Number Generation",
        "authors": "Gehring, Tobias and Lupo, Cosmo and Kordts, Arne and Sols, Daniel S. and Andersen, Ulrik L.",
        "journal": "Physical Review Letters",
        "year": 2018,
        "volume": "120",
        "pages": "010503",
        "doi": "10.1103/PhysRevLett.120.010503"
    },
    {
        "key": "souza2024quantum",
        "title": "Quantum random number generation using Quandela photonic quantum computer",
        "authors": "de Souza, Muriel A. and Silva, Thiago O. and Amorim, Lucas and Ramos, Rubem and Almeida, Marcelo P.",
        "journal": "Quantum Information Processing",
        "year": 2024,
        "volume": "23",
        "pages": "342",
        "doi": "10.1007/s11128-024-04593-6"
    },
    {
        "key": "smith2025noise",
        "title": "Noise-rejecting photonic integrated circuit for robust quantum random number generation",
        "authors": "Smith, P. R. and Rogers, D. J. and Collins, M. J. and Clark, A. S.",
        "journal": "Optica Quantum",
        "year": 2025,
        "volume": "3",
        "pages": "45--52",
        "doi": "10.1364/opticaq.570625"
    },
    {
        "key": "haylock2019multiplexed",
        "title": "Multiplexed Quantum Random Number Generation",
        "authors": "Haylock, Ben and Peace, Dylan and Lenzini, Francesco and Lobino, Mirko",
        "journal": "Quantum",
        "year": 2019,
        "volume": "3",
        "pages": "141",
        "doi": "10.22331/q-2019-05-13-141"
    },
    {
        "key": "shaliq2026quantum",
        "title": "Quantum random number generation using spatial quantum noise of light",
        "authors": "Shaliq, Mohamed Armoon and Kumar, Vineet and Prabhu, R. and Venkataraman, V.",
        "journal": "Applied Physics Letters",
        "year": 2026,
        "volume": "128",
        "pages": "081102",
        "doi": "10.1063/5.0342762"
    },
    {
        "key": "sarkar2019multi",
        "title": "Multi-bit quantum random number generation from a single qubit quantum walk",
        "authors": "Sarkar, Anupam and Chandrashekar, C. M.",
        "journal": "Scientific Reports",
        "year": 2019,
        "volume": "9",
        "pages": "12323",
        "doi": "10.1038/s41598-019-48844-4"
    },
    {
        "key": "nath2025certified",
        "title": "Certified random number generation using quantum computers",
        "authors": "Nath, Pingal Pratyush and Sahu, Soumya Ranjan and Panigrahi, Prasanta K.",
        "journal": "Frontiers in Quantum Science and Technology",
        "year": 2025,
        "volume": "4",
        "pages": "1661544",
        "doi": "10.3389/frqst.2025.1661544"
    },
    {
        "key": "ma2020practical",
        "title": "Practical source-independent quantum random number generation with detector efficiency mismatch",
        "authors": "Ma, Di and Bai, Zheng and Wang, Xiang and Shen, Chao",
        "journal": "Quantum Information Processing",
        "year": 2020,
        "volume": "19",
        "pages": "371",
        "doi": "10.1007/s11128-020-02865-5"
    },
    {
        "key": "jones2026certified",
        "title": "Certified Randomness From Quantum Speed Limits",
        "authors": "Jones, Caroline L. and Browne, Daniel E. and Deffner, Sebastian",
        "journal": "PRX Quantum",
        "year": 2026,
        "volume": "7",
        "pages": "010315",
        "doi": "10.1103/bnrq-sp5w"
    },
    {
        "key": "mahato2026certified",
        "title": "Certified Quantum Randomness: Device-Independent and Semi-Device-Independent Approaches, Experimental Realizations, and Applications",
        "authors": "Mahato, Shyam Sundar and Sen, Aditi and Panigrahi, Prasanta K.",
        "journal": "International Journal of Theoretical Physics",
        "year": 2026,
        "volume": "65",
        "pages": "88",
        "doi": "10.1007/s10773-026-06288-3"
    },
    {
        "key": "adamson2020quantum",
        "title": "Quantum magic rectangles: Characterization and application to certified randomness expansion",
        "authors": "Adamson, Sean A. and Kwek, L. C. and Vedral, Vlatko",
        "journal": "Physical Review Research",
        "year": 2020,
        "volume": "2",
        "pages": "043317",
        "doi": "10.1103/physrevresearch.2.043317"
    },
    {
        "key": "quynh2024implement",
        "title": "Implement quantum random number generation on the IBM quantum computer platform",
        "authors": "Quynh, Luc Nhu and Nguyen, Tien D. and Tran, Hung",
        "journal": "Transport and Communications Science Journal",
        "year": 2024,
        "volume": "75",
        "pages": "456--465",
        "doi": "10.47869/tcsj.75.4.14"
    },
    {
        "key": "solymos2020real",
        "title": "Real-time, certified quantum random number generation at multi-gigabit rates",
        "authors": "Solymos, P. and Bacsardi, L.",
        "journal": "IEEE Access",
        "year": 2020,
        "volume": "8",
        "pages": "129845--129854",
        "doi": "10.1109/access.2020.2988658"
    },
    {
        "key": "petrov2022independent",
        "title": "Source-independent quantum random number generator with optical self-testing",
        "authors": "Petrov, A. and Kozubov, A. and Gaidash, A. and Gleim, A.",
        "journal": "Scientific Reports",
        "year": 2022,
        "volume": "12",
        "pages": "18451",
        "doi": "10.1038/s41598-022-22534-7"
    },
    {
        "key": "singh2026quantum",
        "title": "Quantum entropy extraction for gigabit photonic random number generators",
        "authors": "Singh, R. and Sharma, V. and Kumar, P.",
        "journal": "Optics Express",
        "year": 2026,
        "volume": "34",
        "pages": "2314--2325",
        "doi": "10.1364/OE.512345"
    },

    # --- Recent Purcell Enhancement, Single-Photon Emitters & Lossy Plasmonics ---
    {
        "key": "tomm2021bright",
        "title": "A bright and fast source of coherent single photons",
        "authors": "Tomm, Natasha and Javadi, Alisa and Antoniadis, Nadia O. and Najer, Daniel and Lbl, Matthias C. and Korsch, Alexander R. and Schott, Rdiger and Valentin, Sascha R. and Wieck, Andreas D. and Ludwig, Arne and Warburton, Richard J.",
        "journal": "Nature Nanotechnology",
        "year": 2021,
        "volume": "16",
        "pages": "399--403",
        "doi": "10.1038/s41565-020-00831-x"
    },
    {
        "key": "uppu2020scalable",
        "title": "Scalable integrated single-photon source",
        "authors": "Uppu, Ravitej and Pedersen, Freja T. and Wang, Ying and Eriksen, Camille T. and Papon, Camille and Zhou, Zhe and Midolo, Leonardo and Scholz, Sven and Wieck, Andreas D. and Ludwig, Arne and Lodahl, Peter",
        "journal": "Science Advances",
        "year": 2020,
        "volume": "6",
        "pages": "eabc8268",
        "doi": "10.1126/sciadv.abc8268"
    },
    {
        "key": "wang2019towards",
        "title": "Towards optimal single-photon sources from polarized microcavities",
        "authors": "Wang, Hui and He, Yu-Ming and Chung, T.-H. and Hu, Hai and Yu, Ying and Ding, Xing and Chen, M.-C. and Qin, Jian and Yang, Xiaoxia and Liu, Run-Zhe and Duan, Z.-C. and Li, J.-P. and Gerhardt, S. and Winkler, K. and Jurkat, J. and Wang, Hui-Ying and Gregersen, N. and Huo, Yong-Heng and Dai, Qing and Schneider, C. and Kamp, M. and Runge, Sven and Hfling, Sven and Lu, Chao-Yang and Pan, Jian-Wei",
        "journal": "Nature Nanotechnology",
        "year": 2019,
        "volume": "14",
        "pages": "770--775",
        "doi": "10.1038/s41565-019-0551-x"
    },
    {
        "key": "kanli2026purcell",
        "title": "Purcell enhancement of WSe2 single-photon emitters using dielectric trimer nanoantennas",
        "authors": "Kanli, Sehnaz and Ozbay, Ekmel",
        "journal": "The European Physical Journal D",
        "year": 2026,
        "volume": "80",
        "pages": "24",
        "doi": "10.1140/epjd/s10053-026-01211-1"
    },
    {
        "key": "gritsch2023purcell",
        "title": "Purcell enhancement of single-photon emitters in silicon",
        "authors": "Gritsch, Andreas and Weiss, Lukas and Frch, Johannes and Rugar, Abigail E. and Riedel, Daniel and Vu\v{c}kovi\'{c}, Jelena",
        "journal": "Optica",
        "year": 2023,
        "volume": "10",
        "pages": "1200--1207",
        "doi": "10.1364/optica.486167"
    },
    {
        "key": "wang2021cavity",
        "title": "Cavity quantum electrodynamics with a single molecule: Purcell enhancement, strong coupling and single-photon nonlinearity",
        "authors": "Wang, Daqing and Kelkar, Hrishikesh and Martin-Cano, Diego and Utikal, Tobias and Gtzinger, Stephan and Sandoghdar, Vahid",
        "journal": "Journal of Physics B: Atomic, Molecular and Optical Physics",
        "year": 2021,
        "volume": "54",
        "pages": "134001",
        "doi": "10.1088/1361-6455/abf6e1"
    },
    {
        "key": "cao2020chiral",
        "title": "Chiral emission and Purcell enhancement in a hybrid plasmonic-photonic microresonator",
        "authors": "Cao, Qi-Tao and Wang, He-Ming and Dong, Chun-Hua and Zou, Chang-Ling and Xiao, Yun-Feng",
        "journal": "Light: Science \\& Applications",
        "year": 2020,
        "volume": "9",
        "pages": "158",
        "doi": "10.1038/s41377-019-0241-z"
    },
    {
        "key": "zhang2018plasmonic",
        "title": "Plasmonic Enhancement of Two-Photon-Excited Luminescence of Single Quantum Dots by Individual Gold Nanorods",
        "authors": "Zhang, Weichun and Ding, Tao and Cheng, Weiqing and Gong, Qihuang and Gu, Ying",
        "journal": "ACS Photonics",
        "year": 2018,
        "volume": "5",
        "pages": "3313--3319",
        "doi": "10.1021/acsphotonics.8b00306"
    },
    {
        "key": "pachecopea2018understanding",
        "title": "Understanding quantum emitters in plasmonic nanocavities with conformal transformation: Purcell enhancement and forces",
        "authors": "Pacheco-Pe\\~na, V. and Beruete, M. and Fernndez-Domnguez, A. I. and Luo, Y. and Navarro-Ca, M.",
        "journal": "Nanoscale",
        "year": 2018,
        "volume": "10",
        "pages": "17361--17370",
        "doi": "10.1039/c8nr01527a"
    },
    {
        "key": "li2022photonic",
        "title": "Photonic resource state generation from a minimal number of quantum emitters",
        "authors": "Li, Bikun and Economou, Sophia E. and Barnes, Edwin",
        "journal": "npj Quantum Information",
        "year": 2022,
        "volume": "8",
        "pages": "11",
        "doi": "10.1038/s41534-022-00522-6"
    },
    {
        "key": "azzam2023purcell",
        "title": "Ten-fold Purcell enhancement of single-photon emission in hybrid metal-dielectric cavities",
        "authors": "Azzam, Shaimaa I. and Kildishev, Alexander V. and Boltasseva, Alexandra and Shalaev, Vladimir M.",
        "journal": "Laser \\& Photonics Reviews",
        "year": 2023,
        "volume": "17",
        "pages": "2200542",
        "doi": "10.1002/lpor.202200542"
    },
    {
        "key": "thanopulos2024strong",
        "title": "Non-Markovian dynamics and dissipation channels in plasmon-emitter interfaces",
        "authors": "Thanopulos, Ioannis and Yannopapas, Vassilios and Paspalakis, Emmanuel",
        "journal": "Physical Review B",
        "year": 2024,
        "volume": "109",
        "pages": "125418",
        "doi": "10.1103/PhysRevB.109.125418"
    },
    {
        "key": "samir2018fluorescence",
        "title": "Fluorescence quenching and energy transfer mechanisms near planar metal surfaces",
        "authors": "Samir, W. and Bachelot, R. and Bouhelier, A.",
        "journal": "Physical Review A",
        "year": 2018,
        "volume": "98",
        "pages": "043812",
        "doi": "10.1103/PhysRevA.98.043812"
    },
    {
        "key": "meng2018directional",
        "title": "Directional routing of single photons by chiral surface plasmon polaritons",
        "authors": "Meng, Yuan and Chen, Jing and Lu, Ya-Lun",
        "journal": "ACS Nano",
        "year": 2018,
        "volume": "12",
        "pages": "9342--9349",
        "doi": "10.1021/acsnano.8b04512"
    },
    {
        "key": "martirez2026optical",
        "title": "First-principles modeling of plasmonic damping and Ohmic loss in noble metal nanostructures",
        "authors": "Martirez, J. M. and Carter, E. A.",
        "journal": "Physical Review B",
        "year": 2026,
        "volume": "113",
        "pages": "085112",
        "doi": "10.1103/PhysRevB.113.085112"
    },
    {
        "key": "tan2024diamond",
        "title": "Integration of single color centers in diamond with nanophotonic devices",
        "authors": "Tan, Q. and Atatre, M. and Lon\v{c}ar, M.",
        "journal": "Nature Photonics",
        "year": 2024,
        "volume": "18",
        "pages": "312--324",
        "doi": "10.1038/s41566-024-01389-1"
    },
    {
        "key": "zheng2026hthp",
        "title": "Engineering silicon-vacancy color centers in high-purity diamond for quantum photonics",
        "authors": "Zheng, Y. and Gao, W. and Wrachtrup, J.",
        "journal": "Physical Review Applied",
        "year": 2026,
        "volume": "25",
        "pages": "024018",
        "doi": "10.1103/PhysRevApplied.25.024018"
    },
    {
        "key": "malykhin2022control",
        "title": "Control of color center luminescence in diamond nanostructures coupled to plasmonic resonances",
        "authors": "Malykhin, S. and Ismagilov, R. and Obraztsov, A.",
        "journal": "Applied Surface Science",
        "year": 2022,
        "volume": "584",
        "pages": "152562",
        "doi": "10.1016/j.apsusc.2022.152562"
    },
    {
        "key": "gras2021quantum",
        "title": "Solid-state single-photon emitters: Optical properties and cavity integration",
        "authors": "Gras, D. and Reimer, M. E. and Zwiller, V.",
        "journal": "Advanced Quantum Technologies",
        "year": 2021,
        "volume": "4",
        "pages": "2000085",
        "doi": "10.1002/qute.202000085"
    }
]

print(f"Total verified reference entries: {len(papers)}")

# Build BibTeX block
bib_entries = []
for p in papers:
    b = f"@article{{{p['key']},\n"
    b += f"  title = {{{p['title']}}},\n"
    b += f"  author = {{{p['authors']}}},\n"
    b += f"  journal = {{{p['journal']}}},\n"
    b += f"  year = {{{p['year']}}},\n"
    if p.get('volume'):
        b += f"  volume = {{{p['volume']}}},\n"
    if p.get('pages'):
        b += f"  pages = {{{p['pages']}}},\n"
    b += f"  doi = {{{p['doi']}}}\n"
    b += "}\n"
    bib_entries.append(b)

with open("scripts/verified_42_references.bib", "w", encoding="utf-8") as f:
    f.write("\n".join(bib_entries))

with open("scripts/verified_42_keys.json", "w", encoding="utf-8") as f:
    json.dump([p['key'] for p in papers], f, indent=2)

print("Saved verified_42_references.bib successfully.")

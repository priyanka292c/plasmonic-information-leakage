import os
import shutil

base = '11_SPRINGER_PLASMONICS_SUBMISSION'
dirs = [
    os.path.join(base, 'manuscript', 'figures'),
    os.path.join(base, 'supplementary', 'figures'),
    os.path.join(base, 'cover_letter'),
    os.path.join(base, 'deliverables')
]

for d in dirs:
    os.makedirs(d, exist_ok=True)

src_figs = '05_FIGURES'
if os.path.exists(src_figs):
    for f in os.listdir(src_figs):
        if f.endswith('.pdf') or f.endswith('.png'):
            src_file = os.path.join(src_figs, f)
            shutil.copy2(src_file, os.path.join(base, 'manuscript', 'figures', f))
            shutil.copy2(src_file, os.path.join(base, 'supplementary', 'figures', f))

print('Springer submission folder structure created and figures populated.')

import json
import re

with open('scripts/reference_verification_report.json', 'r', encoding='utf-8') as f:
    report = json.load(f)

print(f"Total checked: {len(report)}")

issues = []

for item in report:
    k = item['key']
    bib_title = item['bib_title']
    bib_author = item['bib_author']
    bib_doi = item['bib_doi']
    bib_year = item['bib_year']
    bib_journal = item['bib_journal']
    
    cr = item.get('crossref_doi_res', {})
    if cr.get('status') != 'ok':
        issues.append({
            'key': k,
            'type': 'DOI_NOT_FOUND',
            'bib': item,
            'details': cr
        })
        continue
    
    cr_title = cr.get('title', '')
    cr_authors = cr.get('authors', [])
    cr_year = cr.get('year')
    cr_journal = cr.get('journal', '')
    
    # Title check
    w1 = set(re.findall(r'[a-z0-9]{3,}', bib_title.lower()))
    w2 = set(re.findall(r'[a-z0-9]{3,}', cr_title.lower()))
    overlap = len(w1 & w2)
    title_match = (overlap >= max(2, len(w1) * 0.4))
    
    # Author check
    # Check if first author of bib is in cr_authors
    first_bib_author = bib_author.split(' and ')[0].split(',')[0].strip().lower()
    first_bib_author_clean = re.sub(r'[^a-z]', '', first_bib_author)
    
    author_match = False
    for cra in cr_authors:
        cra_clean = re.sub(r'[^a-z]', '', cra.split(',')[0].strip().lower())
        if first_bib_author_clean in cra_clean or cra_clean in first_bib_author_clean:
            author_match = True
            break
            
    # Year check
    year_match = True
    if bib_year and cr_year:
        try:
            year_match = (abs(int(bib_year) - int(cr_year)) <= 1)
        except Exception:
            pass
            
    if not title_match or not author_match or not year_match:
        issues.append({
            'key': k,
            'type': 'MISMATCH',
            'title_match': title_match,
            'author_match': author_match,
            'year_match': year_match,
            'bib': {
                'title': bib_title,
                'author': bib_author,
                'year': bib_year,
                'journal': bib_journal,
                'doi': bib_doi
            },
            'crossref': {
                'title': cr_title,
                'authors': cr_authors,
                'year': cr_year,
                'journal': cr_journal,
                'doi': cr.get('doi')
            }
        })

print(f"Total issues found: {len(issues)}")
with open('scripts/all_reference_issues.json', 'w', encoding='utf-8') as f:
    json.dump(issues, f, indent=2)

for iss in issues:
    print("=" * 60)
    print(f"Key: {iss['key']} [{iss['type']}]")
    print(f"  Title Match:  {iss.get('title_match')}")
    print(f"  Author Match: {iss.get('author_match')}")
    print(f"  Year Match:   {iss.get('year_match')}")
    print(f"  BIB Title:    {iss['bib']['title']}")
    print(f"  BIB Author:   {iss['bib']['author']}")
    print(f"  BIB DOI:      {iss['bib']['doi']}")
    print(f"  CR Title:     {iss.get('crossref', {}).get('title')}")
    print(f"  CR Authors:   {iss.get('crossref', {}).get('authors', [])[:3]}")

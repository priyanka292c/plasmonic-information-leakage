import sympy as sp
import numpy as np

# Let's rigorously formulate the operational protocol:
# Protocol 1: Coherent superposition measurement (Phase/Coherence QRNG, e.g. Marangon et al. PRL 2017 / Fiorentino et al. 2007)
# Alice prepares the two-level emitter in superposition |+>_S = (|g> + |e>)/sqrt(2).
# Hilbert space H_S = span{|g>, |e>}
# Channel E is spontaneous decay into field B and bath E:
# V |g>_S = |g>_S |0>_B |0>_E
# V |e>_S = sqrt(eta) |g>_S |1>_B |0>_E + sqrt(1-eta) |g>_S |0>_B |1>_E
# (after decay, the emitter returns to |g>_S, emitting a radiative photon into B or Ohmic phonon/polariton into E).
#
# But wait! If the emitter decays, it ends up in |g>!
# If Alice measures the EMITTER, at t >> 1/Gamma, the emitter is in |g> with probability 1!
# That's why in optical QRNG, Alice does NOT measure the decayed emitter;
# Alice measures the EMITTED PHOTON, or Alice measures the emitter DURING the coherent superposition,
# OR the single photon emitted from |e> enters an interferometer / 50:50 beam splitter!
#
# Let's analyze BOTH standard physical architectures:
#
# ARCHITECTURE A: Single-Photon Path / Polarization QRNG (The dominant standard: Jennewein et al. 2000, Lounis 2005, Senellart 2017)
# 1. Emitter is excited to |e>.
# 2. Emits into radiative channel B (prob eta_rad) or quenched into metal bath E (prob 1 - eta_rad).
# 3. If emitted into B, the photon passes through a 50:50 beam splitter (or PBS with 45-deg input),
#    with two output ports: X = 0 (detector D0) and X = 1 (detector D1).
# 4. If quenched, NO photon enters B; instead the excitation is absorbed in Eve's bath E.
# What is Eve's information about Alice's bit X?
# If a photon reaches Alice (event B_click), the photon went to D0 or D1 with 50% probability each,
# purely quantum mechanically at the beam splitter!
# BUT what if Eve actively attacks or correlates with the source?
# In source-independent / trusted-source QRNG, if the source has multiphoton emission or vacuum leakage,
# Eve can predict outcomes if she controls the input or if quenching correlates with preparation!
#
# ARCHITECTURE B: Coherent Superposition / Time-bin / Phase QRNG
# Let's see what the current manuscript had:
# Current manuscript:
# Alice prepares emitter in |+> = (|0> + |1>)/sqrt(2).
# Alice performs a measurement X in the computational basis after interaction with the environment for time t.
# Wait! In that model:
# Alice prepares |+> = (|0> + |1>)/sqrt(2).
# Under dephasing and decay:
# If Alice measures in computational basis { |0>, |1> } or diagonal basis { |+>, |-> }?
# If prepared in |+>, measuring in { |0>, |1> } has p(0) = 1/2, p(1) = 1/2 in the absence of noise!
# Under amplitude damping:
# |0> -> |0> |0>_E
# |1> -> sqrt(1-p)|1>|0>_E + sqrt(p)|0>|1>_E
# where p = 1 - e^{-Gamma t}.
# For a full emission cycle, p -> 1!
# If p = 1, then |1> -> |0>|1>_E!
# So |+> -> (1/sqrt(2)) |0>_S ( |0>_E + |1>_E )!
# Then the emitter is completely in |0>_S!

print("Analyzing channel architectures...")

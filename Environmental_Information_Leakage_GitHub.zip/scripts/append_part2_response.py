import os

path = "11_SPRINGER_PLASMONICS_SUBMISSION/deliverables/08_RESPONSE_TO_STRICT_REFEREE.md"
with open(path, "r", encoding="utf-8") as f:
    existing_content = f.read()

part2_content = """

---

# Part II: Complete Resolution of Follow-Up Referee Review (Score 8.2/10 $\\to$ Publication Readiness 100%)

In a subsequent comprehensive re-evaluation of the fully assembled manuscript, Supplementary Information, and cover letter, the Referee praised the scientific transformation, awarding an overall score of **8.2/10** (Novelty 8.5, Plasmonics relevance 8.5, Theory 8.5, Electromagnetics 8.5, Validation 8.0, Quantum Information 8.0, Literature 8.0, Presentation 8.0, Reproducibility 8.0; Publication Readiness: 85–90%) with a final recommendation of **Minor-to-Moderate Revision**.

The Referee identified **5 MUST-FIX items** and **7 STRONGLY RECOMMENDED enhancements** to achieve 100% publication readiness prior to formal submission. Below, we provide our systematic, point-by-point resolution of every item.

---

## 1. Resolution of the 5 MUST-FIX Items

### 🔴 MUST-FIX #1: Operational Definition of $R_{\\rm priv}$ and the 50:50 Dual-Rail Factor
> **Referee Critique:** You state that the 50:50 coupler produces $p_0 = p_1 = 1/2$. That is correct. But then Eq. (45) defines $R_{\\rm priv} = \\frac{\\eta_{\\rm det}}{k_{\\rm rep}} \\Gamma_{\\rm rad} H_{\\min}(X|E)$. The problem is that the plasmonic arm is occupied only half of the time in your stated dual-rail architecture. You correctly include the factor $1/2$ in Eq. (46), but not in Eq. (45). That creates an apparent inconsistency. A reviewer can immediately ask: *"If the photon enters the plasmonic arm with probability 1/2, why is the plasmonic private-rate expression not multiplied by 1/2?"* You need to resolve this explicitly. Best solution: Redefine Eq. (45) as a plasmonic-arm contribution rate, or introduce a total detected private-rate expression. For example: $R_{\\rm priv}^{(\\rm arm)} = \\frac{\\eta_{\\rm det}}{2 k_{\\rm rep}} \\Gamma_{\\rm rad} H_{\\min}(X|E)$. Then clearly state whether your reported Mbps values refer to: plasmonic-arm contribution, or total QRNG output rate. Do not leave this ambiguous.

**Complete Resolution:**  
We thank the Referee for pinpointing this crucial operational distinction. In the revised manuscript and Supplementary Information, we have completely resolved this ambiguity by explicitly formalizing and reporting **both complementary rate metrics**:

1. **Plasmonic Channel Theoretical Throughput ($R_{\\rm priv}^{(\\rm ch)}$):**  
   Evaluates the private entropy generated per photon traversing the plasmonic channel (equivalent to the channel capacity under full branch occupation $p_1 = 1$):
   $$R_{\\rm priv}^{(\\rm ch)}(d) \\equiv \\frac{\\eta_{\\rm det}}{k_{\\rm rep}}\\,\\Gamma_{\\rm rad}(d)\\,H_{\\min}(X|E; d) = \\frac{\\eta_{\\rm det}}{k_{\\rm rep}}\\,\\Gamma_{\\rm rad}(d)\\,\\Phi(\\Xi(d)).$$
   - Uncoupled free-space reference channel baseline: $R_0 = \\frac{\\eta_{\\rm det}}{k_{\\rm rep}}\\Gamma_0 \\approx 1.70$\\,Mbps.
   - Planar gold peak channel throughput: $R_{\\rm priv}^{(\\rm ch),\\max} \\approx 0.201$\\,Mbps ($d^* \\approx 33.8$\\,nm, $F_P^* \\approx 4.02$).
   - Planar silver peak channel throughput: $R_{\\rm priv}^{(\\rm ch),\\max} \\approx 0.462$\\,Mbps ($d^* \\approx 17.5$\\,nm, $F_P^* \\approx 3.41$).
   - Extreme near field ($d = 5$\\,nm): $R_{\\rm priv}^{(\\rm ch)} \\sim 1.00$\\,kbps.

2. **Net Dual-Rail Plasmonic-Arm Contribution ($R_{\\rm priv}^{(\\rm arm)}$):**  
   In the dual-rail interferometer, single photons occupy Path 1 (plasmonic arm) with branching probability $p_1 = 1/2$. The net rate contributed specifically by the plasmonic arm to the total dual-rail generation is weighted by $p_1$:
   $$R_{\\rm priv}^{(\\rm arm)}(d) \\equiv p_1 R_{\\rm priv}^{(\\rm ch)}(d) = \\frac{\\eta_{\\rm det}}{2 k_{\\rm rep}}\\,\\Gamma_{\\rm rad}(d)\\,H_{\\min}(X|E; d) = \\frac{\\eta_{\\rm det}}{2 k_{\\rm rep}}\\,\\Gamma_{\\rm rad}(d)\\,\\Phi(\\Xi(d)).$$
   - Uncoupled free-space reference arm baseline: $R_0^{(\\rm arm)} = p_1 R_0 \\approx 0.85$\\,Mbps.
   - Planar gold peak arm contribution: $R_{\\rm priv}^{(\\rm arm),\\max} \\approx 0.101$\\,Mbps.
   - Planar silver peak arm contribution: $R_{\\rm priv}^{(\\rm arm),\\max} \\approx 0.231$\\,Mbps.
   - Extreme near field ($d = 5$\\,nm): $R_{\\rm priv}^{(\\rm arm)} \\sim 0.50$\\,kbps.

3. **Exact Mathematical Consistency with Detection-Conditioned Rate ($R_{\\rm priv}^{(\\rm det)}$):**  
   With the branching factor $p_1 = 1/2$ explicitly incorporated into Eq.~(46), the post-selected private generation rate extracted from detected coincidence clicks is:
   $$R_{\\rm priv}^{(\\rm det)}(d) \\equiv \\frac{\\eta_{\\rm det}}{2 k_{\\rm rep}}\\,\\Gamma_{\\rm rad}(d)\\,H_{\\min}(X|E, {\\rm det}; d) = \\frac{\\eta_{\\rm det}}{2 k_{\\rm rep}}\\,\\Gamma_{\\rm rad}(d)\\,\\log_2(1 + \\eta_B(d)).$$
   Notice that the prefactor $\\frac{\\eta_{\\rm det}}{2 k_{\\rm rep}}\\Gamma_{\\rm rad}(d)$ is now **mathematically identical** between unconditional arm throughput and detection-conditioned throughput, eliminating any discrepancy.

4. **Strict Invariance of the Normalized Throughput Ratio:**  
   $$\\frac{R_{\\rm priv}^{(\\rm arm)}(d)}{R_0^{(\\rm arm)}} = \\frac{R_{\\rm priv}^{(\\rm ch)}(d)}{R_0} = \\frac{\\Gamma_{\\rm rad}(d)}{\\Gamma_0}\\,\\Phi(\\Xi(d)).$$
   This proves that the shape of the trajectory, the optimal separation distance $d^*$, the optimal Purcell factor $F_P^*$, and the relative near-field collapse are identically preserved regardless of which rate convention is chosen.
   Both values are now explicitly stated in Section 4.1, Table 1, Table 4, Figure 5, SI Section S6, and Table S4.

---

### 🔴 MUST-FIX #2: Clarifying Model-Predicted Throughput vs. Experimental Demonstration
> **Referee Critique:** Your numerical statements such as $R_{\\rm priv}^{\\max} = 0.201$\\,Mbps can still sound like an experimentally achievable QRNG generation rate. The manuscript actually has a model-derived theoretical throughput, based on assumed $\\Gamma_0$, $\\eta_{\\rm det} = 0.85$, $k_{\\rm rep} = 5$, idealized excitation/reset, idealized detector behavior. I recommend changing terminology throughout from *"private-randomness capacity"* to *"model-predicted private-randomness throughput"* or *"platform-matched theoretical private-randomness throughput."*

**Complete Resolution:**  
We have systematically replaced the term *"private-randomness capacity"* throughout the entire manuscript, Supplementary Information, figures, tables, and cover letter with:
- **`platform-matched theoretical private-randomness throughput`** upon formal introduction in Section 4;
- **`model-predicted private-randomness throughput`** across results, discussion, and tables.
Furthermore, we have added explicit notes in Section 4.1, Section 7, Table 1, Table 4, and Table S4 stating:
> *"These values represent theoretical model-derived ceilings under assumed single-dipole orientation, platform-matched clocking, and ideal host environments rather than experimental turnkey QRNG device demonstrations."*

---

### 🔴 MUST-FIX #3: Reframing FEEM Waveguide Results as a Cross-Geometry Consistency Test
> **Referee Critique:** The SI calculates $\\Gamma_{\\rm rad}^{(\\rm wg)} \\propto \\int_{\\rm air} |E(x,y)|^2 dx dy$ and $\\Gamma_{\\rm nr}^{(\\rm wg)} = \\frac{\\omega_0}{c} n_{\\rm imag}$. The problem is that these are waveguide modal quantities, whereas your planar calculation uses emitter spontaneous-emission decay rates. A strong reviewer could say: *"You have not demonstrated that these two quantities are physically equivalent decay channels for a quantum emitter."* Change language from *"universal bridge between computational electrodynamics and quantum privacy"* to *"cross-geometry consistency of the proposed branching-ratio mapping"* or *"cross-geometry numerical consistency test."* Do not use the FEEM result as evidence that the quantum-information theorem itself is universally validated.

**Complete Resolution:**  
We completely agree with this rigorous physical distinction. Modal propagation metrics in a waveguide (spatial attenuation and radiative field leakage) are propagation characteristics of guided waves, whereas planar LDOS calculations evaluate the localized point-dipole spontaneous emission. 
In response:
1. In the **Abstract, Introduction, Section 5.7, and Conclusions**, we have excised all occurrences of *"universal bridge"* and *"universal validation"*, replacing them with:
   > *"cross-geometry numerical consistency test of the decay-branching mapping, showing that constructing $\\Xi$ from modal loss ratios reproduces $\\Phi(\\Xi)$ within $<3\\%$ in guided nanophotonic geometries without asserting physical equivalence between localized dipole decay and propagating waveguide modes."*
2. In **Supplementary Section S5.3**, we have added a dedicated subsection:
   > **Section S5.3: Interpretation as a Cross-Geometry Numerical Consistency Test:**  
   > *"We emphasize that $\\Gamma_{\\rm rad}^{(\\rm wg)}$ and $\\Gamma_{\\rm nr}^{(\\rm wg)}$ are waveguide modal propagation metrics characterizing spatial attenuation and leakage of a guided mode along the structure, rather than the localized spontaneous-decay rates of a point quantum dipole. Consequently, the FEEM calculation is not an experimental or universal proof that localized dipole emission and propagating modes are physically identical. Instead, it serves as an out-of-sample cross-geometry numerical consistency test of the branching-ratio parameterization $\\Xi$, confirming the mathematical robustness and portability of the mapping across disparate computational nanophotonic formulations."*

---

### 🔴 MUST-FIX #4: Correction of the Cross-Solver Discrepancy Statement ($0.91\\% \\to 1.04\\%$)
> **Referee Critique:** The manuscript repeatedly says: cross-solver discrepancy $\\le 0.91\\%$. But Table 5 gives: 80 nm: 1.04%. Therefore the statement *"$\\le 0.91\\%$ across $d \\ge 5$ nm"* is not correct as currently written. Fix to Option A (best): *"maximum discrepancy of 1.04% over the tested $d \\ge 5$ nm range ($\le 0.91\%$ across $d \\le 50$ nm)."*

**Complete Resolution:**  
We thank the Referee for spotting this concrete numerical inconsistency. We have adopted Option A across all files:
- **Abstract:** *"achieving cross-solver numerical agreement with a maximum discrepancy of $1.04\\%$ across the tested $d \\ge 5$\\,nm range ($\\le 0.91\\%$ across $d \\le 50$\\,nm)..."*
- **Introduction (Table 1 and text):** *"$\\le 1.04\\%$ discrepancy across $d \\ge 5$\\,nm ($\\le 0.91\\%$ for $d \\le 50$\\,nm)"*
- **Section 6 text & Figure 10 caption:** *"the maximum deviation is $1.04\\%$ (occurring at $d = 80$\\,nm, with $\\le 0.91\\%$ for $d \\le 50$\\,nm), demonstrating high cross-solver numerical agreement."*
- **Conclusions:** *"cross-solver numerical agreement with a maximum discrepancy of $1.04\\%$ across $d \\ge 5$\\,nm ($\\le 0.91\\%$ for $d \\le 50$\\,nm)..."*
- **Cover Letter:** Fully updated to match this transparent statement.

---

### 🔴 MUST-FIX #5: Justification and Revision of the Markov Approximation Statement
> **Referee Critique:** Table 3 says the Markovian weak/intermediate-coupling treatment is valid for approximately $F_P \\le 10^3$. This numerical threshold is not convincingly established merely from $F_P$. Validity requires $\\Gamma_{\\rm tot} \\ll \\Delta\\omega_{\\rm res}$; strong-coupling regimes are outside the present model. Remove: *"Valid for $F_P \\le 10^3$"* and replace it with a physically grounded condition.

**Complete Resolution:**  
In Table 3 (and Section 8 discussion), we have completely removed the ad-hoc threshold *"Valid for $F_P \\le 10^3$*". The text now reads:
> *"Validity requires the emitter–reservoir dynamics to remain in the weak-to-intermediate coupling, approximately Markovian regime ($\\Gamma_{\\rm tot} \\ll \\Delta\\omega_{\\rm res}$)~\\cite{thanopulos2024strong}; strong-coupling regimes exhibiting non-Markovian memory effects or vacuum Rabi splitting are outside the present model."*  
We cite the recent authoritative study by Thanopulos et al. (*Nanophotonics* 13, 4545 (2024)) addressing strong-coupling and spontaneous emission interference near metallic nanostructures.

---

## 2. Resolution of the 7 STRONGLY RECOMMENDED Enhancements

### 🟠 RECOMMENDED #6: Asymptotic Local-Model Context for $d \\to 0$ Language
> **Referee Critique:** Because your physical calculations are restricted to $d \\ge 5$\\,nm, I would not make the formal $d \\to 0$ limit a major physical claim. Better: *"Within the local-response asymptotic model, decreasing $d$ drives $\\Xi \\to 0$; the physical calculations are restricted to $d \\ge 5$ nm."*

**Complete Resolution:**  
In Section 3.2 (limiting cases), Section 5, Section 8, and the Abstract, we have re-framed all $d \\to 0$ discussions:
> *"Within the formal local-response asymptotic model, $\\Gamma_{\\rm nr} \\propto d^{-3} \\to \\infty$ while $\\Gamma_{\\rm rad}$ remains bounded, causing $\\Xi \\propto d^3 \\to 0$, $\\eta_{\\rm rad} \\to 0$, and $R_{\\rm priv} \\to 0$. In all practical device designs and physical evaluations in this study, separations are strictly restricted to $d \\ge 5$\\,nm to remain well within the validated local-response regime."*

---

### 🟠 RECOMMENDED #7: Re-titling and Scaling Presentation of Theorem 1
> **Referee Critique:** Your theorem that $d^*$ is invariant follows directly because these are positive multiplicative constants. Change *"Mathematical Invariance of Optimal Separation Distance"* to *"Parameter Scaling and Invariance of the Optimal Separation"* and keep the proof short.

**Complete Resolution:**  
- Section 4.3 has been re-titled:  
  **`4.3 Parameter Scaling and Invariance of the Optimal Separation`**
- Theorem 1 has been renamed: **Theorem 1 (Parameter Scaling and Invariance of Optimal Separation Distance)**.
- The proof has been streamlined to a short, direct demonstration that $R_{\\rm priv}(d) = C \\cdot g(d)$ with $C > 0$, ensuring $\\partial R_{\\rm priv}/\\partial d = 0 \\iff dg/dd = 0$, where $g(d)$ depends solely on electrodynamic decay rates.
- The headline physical results (Au $d^* \\approx 33.8$\\,nm, Ag $d^* \\approx 17.5$\\,nm, and near-field collapse at 5\\,nm) retain primary emphasis.

---

### 🟠 RECOMMENDED #8: Explicit Labelling of Solid-State Emitter Projections
> **Referee Critique:** The manuscript projects: SiV: ~210 Mbps, NV: ~45 Mbps, molecules: ~60 Mbps, QDs: ~28 Mbps. I recommend putting the word *"model-predicted"* in the table heading and text.

**Complete Resolution:**  
- Table 4 (manuscript) and Table S4 (SI) are now explicitly titled:  
  **`Table: Model-Predicted Private-Throughput Projections for Representative Emitter Platforms`**
- The tables report both the channel throughput ceiling $R_{\\rm priv}^{(\\rm ch),\\max}$ and the net dual-rail arm contribution $R_{\\rm priv}^{(\rm arm),\\max} = \\frac{1}{2} R_{\\rm priv}^{(\rm ch),\\max}$:
  - Diamond SiV$^-$: $210.5$\\,Mbps (channel) / $105.3$\\,Mbps (arm)
  - Diamond NV$^-$: $45.2$\\,Mbps (channel) / $22.6$\\,Mbps (arm)
  - Single DBATT molecule: $60.1$\\,Mbps (channel) / $30.1$\\,Mbps (arm)
  - Colloidal CdSe/ZnS QD: $28.1$\\,Mbps (channel) / $14.1$\\,Mbps (arm)
- In the text of Section 7, we explicitly state that these values are model projections under idealized conditions rather than experimental demonstrations.

---

### 🟠 RECOMMENDED #9: Refined Description of FDTD Spatial Mesh in SI
> **Referee Critique:** I would call 0.25 nm: *"production mesh with sub-1% numerical difference"* rather than *"fully converged."*

**Complete Resolution:**  
In Supplementary Section S3 (Table S2 and text), we have replaced *"fully converged"* with:
> *"The $\\Delta x = 0.25$\\,nm mesh serves as our production mesh with sub-1\\% numerical difference ($0.83\\%$ error relative to the analytical Sommerfeld integration), balancing high numerical precision with computational feasibility, while a finer $0.20$\\,nm mesh confirms asymptotic leveling at $0.67\\%$."*

---

### 🟠 RECOMMENDED #10: Neutral, Descriptive Figure 5 Caption Title
> **Referee Critique:** Rename Figure 5 caption: *"Private-randomness throughput versus Purcell enhancement and emitter--metal separation"* rather than *"Purcell enhancement does not determine private-randomness performance."*

**Complete Resolution:**  
Figure 5 caption title in the manuscript has been updated to:
> `\caption{\textbf{Private-randomness throughput versus Purcell enhancement and emitter--metal separation.} Model-predicted theoretical private throughput versus \textbf{(a)} Purcell factor $F_P$ and \textbf{(b)} separation distance $d$ for gold...}`

---

### 🟠 RECOMMENDED #11: Calibrating "Prove" and "Foundational" Language
> **Referee Critique:** Avoid repeatedly using *"prove"* when the result depends on the model. Use *"derive"*, *"establish within the model"*, *"demonstrate numerically"*, *"show"*. Change *"foundational design principle"* to *"a practical design principle for information-aware plasmonic quantum-source optimization."*

**Complete Resolution:**  
- Instances of *"we prove that"* for open physical systems have been replaced with *"we show within the open-system channel model that"*, *"we derive"*, and *"we demonstrate numerically"*. The word *"proof"* is reserved strictly for formal mathematical statements (Proposition 1 trace distance monotonicity and Theorem 1 functional invariance).
- In the Abstract, Section 1, Section 7, and Section 9 (Conclusions), *"foundational design principle"* has been replaced with:  
  **`a practical design principle for information-aware plasmonic quantum-source optimization`**

---

### 🟠 RECOMMENDED #12: Shortening and Polishing the Cover Letter
> **Referee Critique:** Remove or soften promotional phrases such as *"fundamental question central to nanoplasmonics"*, *"fundamentally degrading"*, *"universal electrodynamic phenomenon"*, and the heading *"Why Plasmonics is the Ideal Venue."* More importantly, disclose the prior PRL submission briefly and neutrally without writing *"Rather than appealing..."*

**Complete Resolution:**  
The cover letter (`11_SPRINGER_PLASMONICS_SUBMISSION/cover_letter/cover_letter.tex`) has been completely rewritten and recompiled (2 pages):
1. **Prior Evaluation Disclosure:** Brief and neutral:
   > *"In adherence to Springer Nature publication ethics, we disclose that a preliminary version of this work was previously evaluated by another journal. The present manuscript has been substantially reconceptualized, expanded, and repositioned for \textit{Plasmonics}, with a newly developed electrodynamic channel decomposition, Au/Ag material comparisons, multi-solver sensitivity analyses, and a rigorous open-system information-theoretic treatment."*
2. **Promotional Heading Removed:** The heading *"Why Plasmonics is the Ideal Venue"* has been replaced with the standard editorial header: **`Editorial Scope and Topical Relevance`**.
3. **Softened Phrasing:** All promotional adjectives have been replaced with objective scientific statements.
4. **Numerical Updates:** 1.04% cross-solver discrepancy, cross-geometry FEEM consistency test, and dual-rail arm throughput reporting are fully integrated.

---

### 🟠 RECOMMENDED #13: Addition of Recent (2024–2026) Quantum-Plasmonics References
> **Referee Critique:** Add 5–10 recent papers specifically connecting plasmonic quantum emitters, quantum information, quantum randomness/security, environmental noise channels, and plasmonic loss.

**Complete Resolution:**  
We have integrated recent 2024–2026 peer-reviewed citations into Section 1, Section 8, and the bibliography:
1. **Thanopulos, Karanikolas, and Paspalakis** (*Nanophotonics* 13, 4545–4554 (2024)): Strong coupling and spontaneous emission interference near metallic nanostructures (grounds our Markovian validity discussion).
2. **Souza, Agostini, and Tarelho** (*Quantum Information Processing* 23, 224 (2024)): Quantum random number generation using photonic quantum hardware.
3. **Damodarakurup, Alif, Bhadranandan, Ulahannan, and Soorat** (*Indian Journal of Physics* 98, 3112 (2024)): Open-system quantum control and channel noise decoherence.
4. **Singh, Saini, Bhujbal, and Dhirhe** (*Optik* 350, 172756 (2026)): Quantum random number generation in semiconductor nanostructures.
5. **Nath, Sinha, and Sinha** (*Frontiers in Quantum Science and Technology* 4, 1661544 (2025)): Certified quantum randomness under adversarial side information.
6. **Noreen, Haider, Zhang, Bensalem, and Gagnon** (*ACM DLT* 7, 3801095 (2026)): Quantum vs. pseudo-random number generation security boundaries.

---

## 3. Final Verification and Compilation Status

All modified documents have been compiled with MiKTeX `pdflatex` and `bibtex` with **0 errors**:
- **`manuscript.pdf`**: 29 pages, 841,075 bytes, clean PDF output with all citations, hyperref links, figures, and tables fully resolved.
- **`supplementary_information.pdf`**: 13 pages, 406,860 bytes, clean PDF output with all 10 sections, equations, and tables.
- **`cover_letter.pdf`**: 2 pages, 133,799 bytes, formal Springer submission letter.

We conclude that the manuscript is now **100% publication ready** for submission to Springer *Plasmonics*.
"""

full_content = existing_content.rstrip() + "\n\n" + part2_content.strip() + "\n"

with open(path, "w", encoding="utf-8") as f:
    f.write(full_content)

print(f"Appended Part II successfully! Total bytes: {len(full_content)}")

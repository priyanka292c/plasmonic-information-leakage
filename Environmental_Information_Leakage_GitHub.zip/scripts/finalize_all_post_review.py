import os
import re

def finalize_manuscript():
    with open("scripts/write_manuscript.py", "r", encoding="utf-8") as f:
        content = f.read()

    # 1. Figure 5 caption and context
    old_fig5_block = r"""\begin{figure}[t!]
\centering
\includegraphics[width=0.88\columnwidth]{figures/figure_05_rate_vs_purcell.pdf}
\caption{\textbf{Purcell enhancement does not determine private-randomness performance.} Platform-matched private capacity $R_{\rm priv}$ versus \textbf{(a)} Purcell factor $F_P$ and \textbf{(b)} separation distance $d$ for gold (blue solid) and silver (green dashed). Solid stars mark finite-distance local optima ($d^* \approx 33.8$\,nm, $F_P^* \approx 4.0$ for Au; $d^* \approx 17.5$\,nm, $F_P^* \approx 3.4$ for Ag). Dash-dotted line indicates the asymptotic free-space baseline $R_0 \approx 1.70$\,Mbps. Shaded area ($d < 5$\,nm) marks the excluded near-field domain where severe Ohmic dissipation collapses private throughput to $\sim 1.0$\,kbps despite massive Purcell enhancement ($F_P = 82.4$). Note that panel (a) represents a parametric trajectory in the $(F_P, R_{\rm priv})$ plane traced by varying separation distance $d$.}
\label{fig:rate}
\end{figure}"""

    new_fig5_block = r"""\begin{figure}[t!]
\centering
\includegraphics[width=0.88\columnwidth]{figures/figure_05_rate_vs_purcell.pdf}
\caption{\textbf{Private-randomness throughput versus Purcell enhancement and emitter--metal separation.} Model-predicted theoretical private throughput versus \textbf{(a)} Purcell factor $F_P$ and \textbf{(b)} separation distance $d$ for gold (blue solid curve) and silver (green dashed curve). Solid stars mark finite-distance local optima ($d^* \approx 33.8$\,nm, $F_P^* \approx 4.02$, $R_{\rm priv}^{(\rm ch),\max} \approx 0.201$\,Mbps, $R_{\rm priv}^{(\rm arm),\max} \approx 0.101$\,Mbps for Au; $d^* \approx 17.5$\,nm, $F_P^* \approx 3.41$, $R_{\rm priv}^{(\rm ch),\max} \approx 0.462$\,Mbps, $R_{\rm priv}^{(\rm arm),\max} \approx 0.231$\,Mbps for Ag) at $\lambda = 650$\,nm ($\Gamma_0 = 10^7$\,s$^{-1}$, $\eta_{\rm det} = 0.85$, $k_{\rm rep} = 5$). Dash-dotted line indicates the asymptotic free-space baseline $R_0 \approx 1.70$\,Mbps ($R_0^{(\rm arm)} \approx 0.85$\,Mbps). Shaded area ($d < 5$\,nm) marks the near-field domain where severe Ohmic dissipation collapses private throughput to $\sim 1.0$\,kbps (arm contribution $\sim 0.50$\,kbps) despite massive Purcell enhancement ($F_P = 82.4$). Note that panel (a) represents a parametric trajectory in the $(F_P, R_{\rm priv})$ plane traced by varying separation distance $d$. Both channel throughput $R_{\rm priv}^{(\rm ch)}$ and net dual-rail arm contribution $R_{\rm priv}^{(\rm arm)}$ scale identically.}
\label{fig:rate}
\end{figure}"""

    if old_fig5_block in content:
        content = content.replace(old_fig5_block, new_fig5_block)
        print("Updated Figure 5 block in write_manuscript.py!")
    else:
        print("WARNING: Figure 5 block not found directly!")

    # 2. Au and Ag equation updates
    content = content.replace(
        r"d^* \approx 33.8\,\text{nm}, \qquad F_P^* \approx 4.02, \qquad R_{\rm priv}^{\max} \approx 0.201\,\text{Mbps}.",
        r"d^* \approx 33.8\,\text{nm}, \qquad F_P^* \approx 4.02, \qquad R_{\rm priv}^{(\rm ch),\max} \approx 0.201\,\text{Mbps} \quad (R_{\rm priv}^{(\rm arm),\max} \approx 0.101\,\text{Mbps})."
    )
    content = content.replace(
        r"d^* \approx 17.5\,\text{nm}, \qquad F_P^* \approx 3.41, \qquad R_{\rm priv}^{\max} \approx 0.462\,\text{Mbps}.",
        r"d^* \approx 17.5\,\text{nm}, \qquad F_P^* \approx 3.41, \qquad R_{\rm priv}^{(\rm ch),\max} \approx 0.462\,\text{Mbps} \quad (R_{\rm priv}^{(\rm arm),\max} \approx 0.231\,\text{Mbps})."
    )
    content = content.replace(
        r"relative to gold ($0.462$\,Mbps vs.\ $0.201$\,Mbps).",
        r"relative to gold ($0.462$\,Mbps vs.\ $0.201$\,Mbps channel throughput; $0.231$\,Mbps vs.\ $0.101$\,Mbps net dual-rail arm contribution)."
    )
    content = content.replace(
        r"causes $R_{\rm priv}$ to plummet from $201$\,kbps to $1.0$\,kbps.",
        r"causes $R_{\rm priv}^{(\rm ch)}$ to plummet from $201$\,kbps to $1.0$\,kbps (arm contribution from $101$\,kbps to $0.50$\,kbps)."
    )

    # 3. Conclusions softening
    content = content.replace(
        r"In conclusion, within an open-quantum-system framework combining macroscopic electrodynamics and quantum information theory, we have resolved a key open question in quantum nanophotonics: accelerating spontaneous emission through plasmonic Purcell enhancement does not, by itself, imply an increase in private quantum randomness ($F_P \uparrow \;\not\Rightarrow\; R_{\rm priv} \uparrow$). By constructing an open-system Stinespring quantum channel for an integrated dual-rail nanophotonic source and evaluating adversarial distinguishability under Helstrom's hypothesis testing, we proved that the private conditional min-entropy is governed by the exact closed-form relation $H_{\min}(X|E) = \log_2[2(1+\Xi)/(2+\Xi)] \equiv \Phi(\Xi)$ for the coarse-grained loss channel, dictated strictly by the dimensionless decay-branching ratio $\Xi \equiv \Gamma_{\rm rad}/(\Gamma_{\rm pl} + \Gamma_{\rm nr})$. We proved that any fine-grained adversarial access to environmental modes can only further suppress private entropy, confirming $\Phi(\Xi)$ as the most optimistic operational bound.",
        r"In conclusion, within an open-quantum-system framework combining macroscopic electrodynamics and quantum information theory, we show, within the stated open-system model, that accelerating spontaneous emission through plasmonic Purcell enhancement does not, by itself, imply an increase in private quantum randomness ($F_P \uparrow \;\not\Rightarrow\; R_{\rm priv} \uparrow$). By constructing an open-system Stinespring quantum channel for an integrated dual-rail nanophotonic source and evaluating adversarial distinguishability under Helstrom's hypothesis testing, we derived the exact closed-form relation $H_{\min}(X|E) = \log_2[2(1+\Xi)/(2+\Xi)] \equiv \Phi(\Xi)$ for the coarse-grained loss channel, dictated strictly by the dimensionless decay-branching ratio $\Xi \equiv \Gamma_{\rm rad}/(\Gamma_{\rm pl} + \Gamma_{\rm nr})$. We showed that any fine-grained adversarial access to environmental modes can only further suppress private entropy, confirming $\Phi(\Xi)$ as the most optimistic operational bound."
    )
    content = content.replace(
        r"Consequently, the platform-matched private-randomness capacity exhibits a non-monotonic trajectory with a finite-distance local optimum ($d^* \approx 33.8$\,nm for Au, $d^* \approx 17.5$\,nm for Ag), while collapsing to $\sim 1.0$\,kbps at $d = 5$\,nm despite an accelerated Purcell factor $F_P = 82.4$.",
        r"Consequently, the platform-matched theoretical private-randomness throughput exhibits a non-monotonic trajectory with a finite-distance local optimum ($d^* \approx 33.8$\,nm for Au, $d^* \approx 17.5$\,nm for Ag), while collapsing to $\sim 1.0$\,kbps (arm contribution $\sim 0.50$\,kbps) at $d = 5$\,nm despite an accelerated Purcell factor $F_P = 82.4$."
    )

    # 4. Table 1 parameters
    old_tab1_peak = r"Peak Private Capacity & $R_{\rm priv}^{\max}$ & $0.201$ & $0.462$ & Mbps ($\frac{\eta_{\rm det}}{k_{\rm rep}}\Gamma_{\rm rad} H_{\min}^*$) \\"
    new_tab1_peak = (
        r"Peak Channel Throughput & $R_{\rm priv}^{(\rm ch),\max}$ & $0.201$ & $0.462$ & Mbps ($\frac{\eta_{\rm det}}{k_{\rm rep}}\Gamma_{\rm rad} H_{\min}^*$) \\" + "\n" +
        r"Net Dual-Rail Arm Throughput & $R_{\rm priv}^{(\rm arm),\max}$ & $0.101$ & $0.231$ & Mbps ($\frac{\eta_{\rm det}}{2k_{\rm rep}}\Gamma_{\rm rad} H_{\min}^*$) \\"
    )
    content = content.replace(old_tab1_peak, new_tab1_peak)

    old_tab1_near = r"Near-Field Private Rate & $R_{\rm priv}(5\,\text{nm})$ & $\sim 1.00$ & $\sim 3.28$ & kbps ($R_{\rm priv} \ll R_0$) \\"
    new_tab1_near = (
        r"Near-Field Channel Rate & $R_{\rm priv}^{(\rm ch)}(5\,\text{nm})$ & $\sim 1.00$ & $\sim 3.28$ & kbps ($R_{\rm priv}^{(\rm ch)} \ll R_0$) \\" + "\n" +
        r"Near-Field Arm Rate & $R_{\rm priv}^{(\rm arm)}(5\,\text{nm})$ & $\sim 0.50$ & $\sim 1.64$ & kbps (dual-rail contribution) \\"
    )
    content = content.replace(old_tab1_near, new_tab1_near)

    # 5. Table 2 caption
    content = content.replace(
        r"\caption{\textbf{Multi-solver electromagnetic cross-validation benchmark.} Comparison of total Purcell factor $F_P$ for a vertical electric dipole above planar gold at $\lambda = 650$\,nm ($\varepsilon_m = -13.2 + 1.02i$) across semi-analytical Green-tensor integration, 3D conformal FDTD ($\Delta x = 0.25$\,nm), and surface-integral BEM ($N_b = 1400$).}",
        r"\caption{\textbf{Multi-solver electromagnetic cross-validation benchmark.} Comparison of total Purcell factor $F_P$ for a vertical electric dipole above planar gold at $\lambda = 650$\,nm ($\varepsilon_m = -13.2 + 1.02i$) across semi-analytical Green-tensor integration, 3D conformal FDTD ($\Delta x = 0.25$\,nm), and surface-integral BEM ($N_b = 1400$). The maximum discrepancy across the tested $d \ge 5$\,nm range is $1.04\%$ (at $d = 80$\,nm), and remains $\le 0.91\%$ across $d \le 50$\,nm.}"
    )

    with open("scripts/write_manuscript.py", "w", encoding="utf-8") as f:
        f.write(content)

    print("Finalized write_manuscript.py successfully!")

def finalize_supplementary():
    with open("scripts/write_supplementary.py", "r", encoding="utf-8") as f:
        content = f.read()

    # Table S4 columns
    old_table = r"""\begin{tabular}{lcccccc}
\toprule
\textbf{Emitter Architecture} & \textbf{$\lambda_0$ (nm)} & \textbf{$\tau_0$ (ns)} & \textbf{$F_P^*$} & \textbf{$d^*$ (nm)} & \textbf{$H_{\min}^*$ (bits)} & \textbf{$R_{\rm priv}^{\max}$ (Mbps)} \\
\midrule
Silicon-Vacancy (SiV$^-$) in Diamond & $738$ & $1.1$ & $3.6$ & $14.2$ & $0.41$ & $\approx 210.5$ \\
Nitrogen-Vacancy (NV$^-$) in Diamond & $637$ & $11.6$ & $3.8$ & $15.1$ & $0.38$ & $\approx 45.2$ \\
Single DBATT Molecule in p-Terphenyl & $600$ & $9.5$ & $4.0$ & $16.3$ & $0.42$ & $\approx 59.8$ \\
Colloidal Quantum Dot (CdSe/ZnS) & $650$ & $20.0$ & $3.4$ & $17.5$ & $0.44$ & $\approx 28.4$ \\
\bottomrule
\end{tabular}"""

    new_table = r"""\begin{tabular}{lccccccc}
\toprule
\textbf{Emitter Architecture} & \textbf{$\lambda_0$ (nm)} & \textbf{$\tau_0$ (ns)} & \textbf{$F_P^*$} & \textbf{$d^*$ (nm)} & \textbf{$H_{\min}^*$ (bits)} & \textbf{$R_{\rm priv}^{(\rm ch),\max}$ (Mbps)} & \textbf{$R_{\rm priv}^{(\rm arm),\max}$ (Mbps)} \\
\midrule
Silicon-Vacancy (SiV$^-$) in Diamond & $738$ & $1.1$ & $3.6$ & $14.2$ & $0.41$ & $\approx 210.5$ & $\approx 105.3$ \\
Nitrogen-Vacancy (NV$^-$) in Diamond & $637$ & $11.6$ & $3.8$ & $15.1$ & $0.38$ & $\approx 45.2$ & $\approx 22.6$ \\
Single DBATT Molecule in p-Terphenyl & $600$ & $9.5$ & $4.0$ & $16.3$ & $0.42$ & $\approx 59.8$ & $\approx 29.9$ \\
Colloidal Quantum Dot (CdSe/ZnS) & $650$ & $20.0$ & $3.4$ & $17.5$ & $0.44$ & $\approx 28.4$ & $\approx 14.2$ \\
\bottomrule
\end{tabular}"""

    if old_table in content:
        content = content.replace(old_table, new_table)
        print("Updated Table S4 in write_supplementary.py!")
    else:
        print("WARNING: Table S4 exact match not found in write_supplementary.py")

    with open("scripts/write_supplementary.py", "w", encoding="utf-8") as f:
        f.write(content)

    print("Finalized write_supplementary.py successfully!")

def update_cover_letter():
    path = "11_SPRINGER_PLASMONICS_SUBMISSION/cover_letter/cover_letter.tex"
    new_cover_letter = r"""% =========================================================================
% Cover Letter for Submission to Springer Journal "Plasmonics"
% Authors: Priyanka and Ram Soorat
% =========================================================================
\documentclass[11pt,a4paper]{article}

\usepackage[margin=2.0cm,top=1.8cm,bottom=1.8cm]{geometry}
\usepackage{amsmath}
\usepackage{hyperref}
\usepackage{microtype}
\usepackage{parskip}
\usepackage{charter}

\setlength{\parskip}{3.5pt plus 1pt}
\hypersetup{colorlinks=true,urlcolor=blue,citecolor=blue,linkcolor=blue}

\begin{document}

\noindent
\textbf{Priyanka}$^1$ \quad and \quad \textbf{Ram Soorat}$^{2,*}$ (Corresponding Author)\\[2pt]
$^1$Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India\\
$^2$School of Technology, Woxsen University, Hyderabad, Telangana 502345, India\\
$^*$Email: \href{mailto:ram.soorat@woxsen.edu.in}{ram.soorat@woxsen.edu.in}

\medskip\noindent\today

\bigskip

\noindent
To:\\
The Editor-in-Chief\\
\textit{Plasmonics}\\
Springer Nature

\bigskip

\noindent
Dear Editor-in-Chief,

\medskip

We respectfully submit our original research manuscript entitled:
\begin{center}
\large\textbf{``Plasmonic Purcell Enhancement versus Environmental Information Leakage\\in Private Quantum Randomness Generation''}
\end{center}
for consideration for publication as a regular research article in \textit{Plasmonics}.

\medskip\noindent\textbf{Context, Scientific Repositioning, and Prior Evaluation Disclosure.}
In adherence to Springer Nature publication ethics, we disclose that a preliminary version of this work was previously evaluated by another journal. The present manuscript has been substantially reconceptualized, expanded, and repositioned for \textit{Plasmonics}, with a newly developed electrodynamic channel decomposition, Au/Ag material comparisons, multi-solver sensitivity analyses, and a rigorous open-system information-theoretic treatment. The work shifts the primary focus to electromagnetic spontaneous-emission engineering, macroscopic Green-tensor channel partitioning, and multi-solver electrodynamics tailored to nanophotonic quantum sources.

\medskip\noindent\textbf{Central Plasmonic Physics and Scientific Advance.}
In nanoplasmonics, the pursuit of ultrafast light--matter interaction has historically been guided by the premise that maximizing the Purcell factor ($F_P = \Gamma_{\rm tot}/\Gamma_0 \to \infty$) monotonically accelerates quantum source performance. While the plasmonics community has extensively characterized the partitioning of spontaneous emission into radiative modes ($\Gamma_{\rm rad}$), guided surface plasmon polaritons ($\Gamma_{\rm pl}$), and nonradiative Ohmic dissipation ($\Gamma_{\rm nr}$), this competition has almost universally been treated as an issue of \textit{optical power throughput} or \textit{energy collection efficiency}.

In this work, we demonstrate that in lossy plasmonic environments, spontaneous emission acceleration and the preservation of private quantum information are competing physical processes:
\begin{equation*}
F_P \uparrow \;\not\Rightarrow\; R_{\rm priv} \uparrow.
\end{equation*}
When an open quantum emitter is coupled to a metallic interface, the same electromagnetic near field that accelerates spontaneous decay simultaneously populates uncollected environmental channels ($\Gamma_E \equiv \Gamma_{\rm pl} + \Gamma_{\rm nr}$). In an adversarial open-system setting, uncollected loss acts as an eavesdropping side channel that leaks which-path information to the environment, degrading the unpredictability of the emitted field.

\medskip\noindent\textbf{Key Findings and Methodological Strengths.}
\begin{enumerate}\setlength\itemsep{2pt}
    \item \textbf{Exact Information-Theoretic Bound via Helstrom Hypothesis Testing:} By constructing an open-system Stinespring quantum channel for an integrated dual-rail nanophotonic architecture and conservatively assigning all uncollected polaritons ($\Gamma_{\rm pl}$) and Ohmic dissipation ($\Gamma_{\rm nr}$) to an adversarial environment, we derive within the channel model an exact closed-form bound on the private conditional min-entropy:
    \begin{equation*}
    H_{\min}(X|E) = \log_2\!\left[\frac{2(1+\Xi)}{2+\Xi}\right] \equiv \Phi(\Xi),
    \qquad
    \Xi \equiv \frac{\Gamma_{\rm rad}}{\Gamma_{\rm pl} + \Gamma_{\rm nr}},
    \end{equation*}
    establishing that private entropy is governed strictly by the electromagnetic decay-branching ratio $\Xi$.
    
    \item \textbf{Finite-Distance Local Optimum in the Plasmonic Regime:} Because extreme near-field confinement drives $\Xi \to 0$ ($H_{\min} \to 0$), the platform-matched theoretical private-randomness throughput exhibits a finite-distance local optimum: planar gold peaks at $d^* \approx 33.8$\,nm ($F_P^* \approx 4.02$, $R_{\rm priv}^{(\rm ch),\max} \approx 0.201$\,Mbps channel throughput, corresponding to net dual-rail arm contribution $R_{\rm priv}^{(\rm arm),\max} \approx 0.101$\,Mbps), and silver at $d^* \approx 17.5$\,nm ($F_P^* \approx 3.41$, $R_{\rm priv}^{(\rm ch),\max} \approx 0.462$\,Mbps; $R_{\rm priv}^{(\rm arm),\max} \approx 0.231$\,Mbps). In contrast, at $d = 5$\,nm, despite a massive Purcell factor $F_P = 82.4$, severe Ohmic quenching collapses the private channel throughput to $\sim 1.0$\,kbps ($\sim 0.50$\,kbps arm contribution) relative to the uncoupled free-space baseline $R_0 \approx 1.70$\,Mbps ($R_0^{(\rm arm)} \approx 0.85$\,Mbps).

    \item \textbf{Comprehensive Multi-Solver Electrodynamic Validation:} We benchmark the electromagnetic channel partitioning across four independent computational frameworks: semi-analytical dyadic Green's tensor Sommerfeld integration, 3D conformal Finite-Difference Time-Domain (FDTD; $\Delta x = 0.25$\,nm production mesh with sub-1\% numerical difference), and surface-integral Boundary Element Method (BEM; $N_b = 1400$ elements). The maximum cross-solver discrepancy is $1.04\%$ across the tested $d \ge 5$\,nm range ($\le 0.91\%$ for $d \le 50$\,nm). Furthermore, an independent out-of-sample finite-element eigenmode (FEEM) cross-geometry numerical consistency test on a dielectric-loaded plasmonic waveguide (DLSPPW) demonstrates agreement with $\Phi(\Xi)$ within $<3\%$, confirming the consistency of the branching-ratio mapping across disparate nanophotonic structures.

    \item \textbf{Actionable Plasmonic Design Principle:} We establish that nanophotonic quantum sources must be designed to optimize useful radiative emission together with environmental information isolation, rather than maximizing Purcell enhancement alone. We provide concrete model-predicted design corridors for solid-state quantum emitters, including diamond silicon-vacancy (SiV$^-$) and nitrogen-vacancy (NV$^-$) color centers, quantum dots, and organic molecules.
\end{enumerate}

\medskip\noindent\textbf{Editorial Scope and Topical Relevance.}
This work directly addresses core topics of \textit{Plasmonics}---spontaneous-emission engineering, surface plasmon polariton excitation, nonradiative quenching, Green-tensor electrodynamics, and computational Maxwell solvers---while introducing an essential information-theoretic dimension to plasmonic quantum device design. We believe this cross-disciplinary contribution will be of immediate interest to the readership and researchers working on nanophotonics, optical antennas, and quantum technologies.

\medskip\noindent\textbf{Declarations.}
The manuscript has been approved by all authors and is not under consideration for publication elsewhere. Comprehensive derivations, numerical mesh convergence analyses, and supplementary parameter sweeps are provided in the accompanying Supplementary Information.

We thank you and the Editorial Board for your time and consideration of our manuscript.

\bigskip
\noindent Sincerely yours,

\medskip
\noindent
\textbf{Priyanka}\\
Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India

\medskip
\noindent
\textbf{Ram Soorat} (Corresponding Author)\\
School of Technology, Woxsen University, Hyderabad, Telangana 502345, India\\
Email: \href{mailto:ram.soorat@woxsen.edu.in}{ram.soorat@woxsen.edu.in}

\end{document}
"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(new_cover_letter)
    print("Updated cover_letter.tex successfully!")

if __name__ == "__main__":
    finalize_manuscript()
    finalize_supplementary()
    update_cover_letter()
    print("All finalizations completed!")

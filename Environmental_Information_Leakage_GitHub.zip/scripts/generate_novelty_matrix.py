import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

data = [
    {
        "Dimension": "Primary Paradigm",
        "Previous Paper (QuantumPlasmonicsBench)": "Classical & semi-classical electrodynamics benchmark: Green tensor computation, spontaneous decay rates, two-emitter concurrence.",
        "New Paper (PRL Submission)": "Fundamental quantum information limits: Open quantum reservoir theory, entropic uncertainty, certified quantum randomness bounds.",
        "Scientific Difference": "Shifts from computational benchmarking of emitter decay/coupling to fundamental information-theoretic limits on certifiable entropy.",
        "Mathematical Difference": "Previous: Lindblad equations for 2 qubits, concurrence C(rho), Purcell factor F_P.\nNew: Conditional min-entropy H_min(X|E), guessing probability P_guess(X|E), entropic uncertainty relations with quantum memory.",
        "Simulation Difference": "Previous: FDTD & BEM benchmarks of nanospheres, core-shell, nanorod dimers, bowties.\nNew: Canonical planar metal-dielectric and dielectric-loaded plasmonic waveguides coupled to full quantum master equations and side-information purifications.",
        "Observable Difference": "Previous: Radiative Purcell factor, emission spectra, two-qubit concurrence vs distance.\nNew: Certified bit generation rate R_cert, conditional min-entropy H_min(X|E), universal control parameter Xi, and non-monotonic collapse threshold F_P*.",
        "Expected Novelty Level": "Groundbreaking: Establishes that extreme Purcell enhancement actively destroys certified randomness, providing a universal bound for quantum nanophotonics."
    },
    {
        "Dimension": "Nanophotonic Geometry",
        "Previous Paper (QuantumPlasmonicsBench)": "Extensive library of nanorods, dimers, bowtie nanoantennas, core-shell nanoparticles, nanostars.",
        "New Paper (PRL Submission)": "Geometry-independent universal analytical framework; validated on planar interfaces, thin films, and plasmonic waveguides.",
        "Scientific Difference": "Eliminates antenna geometry optimization bias; focuses entirely on universal reservoir dispersion, Ohmic dissipation, and LDOS partitioning.",
        "Mathematical Difference": "Previous: Discrete numerical mesh comparisons across intricate shapes.\nNew: Analytical Sommerfeld integrals, exact Green tensor decompositions into radiative, guided, and nonradiative loss channels.",
        "Simulation Difference": "Previous: Shape-dependent resonant scattering and near-field hot spots.\nNew: Cross-solver validation (FDTD, FEEM, BEM) of universal scaling laws and parameter collapse across distinct loss regimes.",
        "Observable Difference": "Previous: Local field enhancement |E/E0|^2, mode volume V_eff.\nNew: Scaling collapse of H_min(X|E) onto a universal master curve Phi(Xi).",
        "Expected Novelty Level": "Universal: Independent of specific antenna morphology, applicable to any lossy polaritonic or nanophotonic platform."
    },
    {
        "Dimension": "Loss & Dissipation Role",
        "Previous Paper (QuantumPlasmonicsBench)": "Treated Ohmic loss as an unavoidable decay accelerator or damping mechanism for Rabi splitting.",
        "New Paper (PRL Submission)": "Treats Ohmic loss as an adversarial quantum side-information leak to environmental reservoir degrees of freedom (E).",
        "Scientific Difference": "Connects microscopic Joule heating / electron-hole pair excitations directly to quantum cryptographic security and state certification.",
        "Mathematical Difference": "Previous: Gamma_nr included in total decay Gamma_tot = Gamma_rad + Gamma_nr.\nNew: Environmental purification |Psi_SE>, partial trace Tr_S(|Psi_SE><Psi_SE|), and adversary guessing power P_guess(X|E).",
        "Simulation Difference": "Previous: Power integration on Poynting boxes.\nNew: Rigorous partitioning of absorbed flux vs radiative flux mapped to eavesdropper distinguishing advantage.",
        "Observable Difference": "Previous: Nonradiative Purcell factor.\nNew: Information leakage epsilon_leak and security failure parameter.",
        "Expected Novelty Level": "Fundamental: Resolves the open question of how metallic dissipation impacts certified quantum security."
    },
    {
        "Dimension": "Optimization Target",
        "Previous Paper (QuantumPlasmonicsBench)": "Maximize Purcell factor F_P and concurrence C.",
        "New Paper (PRL Submission)": "Disproves the dogma 'Higher F_P = Better Quantum Source'; identifies universal optimum F_P* and certified rate R_max.",
        "Scientific Difference": "Demonstrates that extreme Purcell enhancement (F_P -> inf) drives certifiable randomness to zero (R_cert -> 0).",
        "Mathematical Difference": "Previous: Monotonic curves or geometry-tuned peaks.\nNew: Analytical derivation of critical separation d* and optimal Purcell factor F_P* via dR_cert/dF_P = 0.",
        "Simulation Difference": "Previous: Parametric antenna sweeps.\nNew: Multi-parameter phase diagram (F_P, Xi) delineating quantum certifiable vs classical leaking regimes.",
        "Observable Difference": "Previous: Lifetime shortening.\nNew: Certified bits per second under strict security thresholds.",
        "Expected Novelty Level": "Paradigm Shift: Provides the definitive design boundary for high-speed quantum random number generators (QRNGs)."
    }
]

df = pd.DataFrame(data)
wb = openpyxl.Workbook()
ws = wb.active
ws.title = "Novelty Firewall Matrix"

# Headers
headers = list(df.columns)
ws.append(headers)

for row in df.itertuples(index=False):
    ws.append(list(row))

# Styling
header_fill = PatternFill(start_color="1F497D", end_color="1F497D", fill_type="solid")
header_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
cell_font = Font(name="Calibri", size=10)
wrap_alignment = Alignment(wrap_text=True, vertical="top")
thin_border = Border(
    left=Side(style='thin', color='D9D9D9'),
    right=Side(style='thin', color='D9D9D9'),
    top=Side(style='thin', color='D9D9D9'),
    bottom=Side(style='thin', color='D9D9D9')
)

for col_idx, col in enumerate(ws.iter_cols(min_row=1, max_row=len(df)+1), 1):
    col_letter = openpyxl.utils.get_column_letter(col_idx)
    ws.column_dimensions[col_letter].width = 25 if col_idx <= 2 else 32
    for row_idx, cell in enumerate(col, 1):
        if row_idx == 1:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        else:
            cell.font = cell_font
            cell.alignment = wrap_alignment
            cell.border = thin_border

wb.save("NOVELTY_MATRIX.xlsx")
print("NOVELTY_MATRIX.xlsx generated successfully.")

# Also generate NOVELTY_MATRIX.md
md_content = """# Novelty Firewall Matrix

**Project Title**: Fundamental Limit of Quantum Randomness in Lossy Plasmonic Environments  
**Target Journal**: Physical Review Letters (PRL)  
**Authors**: Ram Soorat (Woxsen University) & Priyanka (University of Delhi)  

---

### Strict Novelty Firewall Declaration
The previous submitted manuscript (*"QuantumPlasmonicsBench: A Reproducible Computational Benchmark Framework for Quantum Plasmonics"*) established numerical benchmarks for electrodynamic Green tensors, Purcell factors, and two-emitter concurrence across canonical nanoantenna geometries (nanorods, bowties, nanostars). 

**The present manuscript operates beyond a strict novelty firewall:**
1. **No Geometry Re-optimization**: We strictly prohibit repeating nanorod/bowtie/nanostar Purcell factor optimizations.
2. **Conceptual Paradigm Shift**: We transition from classical/semi-classical electrodynamic benchmark calculations to **open-quantum-system information theory**, entropic uncertainty, and the fundamental physics of certifiable quantum randomness in lossy reservoirs.
3. **Universal Theoretical Bound**: The central result is an analytical trade-off showing that extreme Purcell enhancement actively destroys certifiable randomness due to environmental information leakage into Ohmic degrees of freedom.

---

| Dimension | Previous Paper (QuantumPlasmonicsBench) | New Paper (PRL Submission) | Scientific Difference | Mathematical Difference | Simulation Difference | Observable Difference | Novelty Level |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Primary Paradigm** | Classical/semi-classical electrodynamics: Green tensors, Purcell factor, two-qubit concurrence. | Open-quantum-system information theory: Entropic uncertainty, certified randomness, reservoir leakage. | Shifts from computational decay benchmarks to fundamental limits on certifiable entropy. | Lindblad 2-qubit dynamics vs. Conditional min-entropy $H_{\\min}(X\\|E)$, adversary guessing power $P_{\\text{guess}}(X\\|E)$. | Antenna hot spots vs. reservoir state purification and open-system master equations. | Concurrence $C(\\rho)$ vs. Certified randomness rate $R_{\\text{cert}}$ and universal parameter $\\Xi$. | **Groundbreaking** |
| **Geometry Strategy** | Intricate shapes (nanostars, nanorod dimers, bowties). | Universal geometry-independent analytical theory, verified on canonical planar interfaces & waveguides. | Eliminates shape-optimization bias; focuses on universal polaritonic dispersion and Ohmic dissipation. | Discrete mesh sweeps vs. Analytical Sommerfeld integrals & rigorous LDOS partitioning. | Shape-dependent hot spot hunting vs. Cross-solver validation of scaling laws. | Local field enhancement vs. Universal scaling collapse onto master curve $\\Phi(\\Xi)$. | **Universal** |
| **Loss & Dissipation** | Ohmic damping as decay rate accelerator or Rabi splitting damper. | Ohmic dissipation as adversarial quantum side-information leak ($E$). | Connects Joule heating to quantum cryptographic security failure. | $\\Gamma_{\\text{tot}} = \\Gamma_{\\text{rad}} + \\Gamma_{\\text{nr}}$ vs. Environmental purification $\\|\\Psi_{SE}\\rangle$, $P_{\\text{guess}}(X\\|E)$. | Poynting flux integration vs. Quantum side-information distillation. | Nonradiative Purcell factor vs. Information leakage parameter $\\varepsilon_{\\text{leak}}$. | **Fundamental** |
| **Optimization Target** | Maximize Purcell factor $F_P$ and concurrence $C$. | Disproves 'Higher $F_P$ = Better Source'; proves optimal $F_P^*$ beyond which randomness collapses to zero. | Disproves prevailing nanophotonic dogma; proves existence of non-monotonic randomness optimum. | Monotonic curves vs. Analytical stationarity $\\partial R_{\\text{cert}}/\\partial F_P = 0$ yielding critical distance $d^*$. | Antenna parameter sweeps vs. Universal phase diagram $(F_P, \\Xi)$ defining security boundary. | Lifetime shortening vs. Provably certified bits per second. | **Paradigm Shift** |

"""

with open("NOVELTY_MATRIX.md", "w", encoding="utf-8") as f:
    f.write(md_content)
print("NOVELTY_MATRIX.md generated successfully.")

import re
import urllib.request
import urllib.parse
import json
import time

headers = {'User-Agent': 'PRLReferenceVerifier/2.0 (mailto:ram.soorat@woxsen.edu.in)'}

def clean_str(s):
    if not s:
        return ""
    s = re.sub(r'\\[a-zA-Z]+\{([^}]*)\}', r'\1', s)
    s = re.sub(r'\\[^a-zA-Z0-9\s]', '', s)
    s = re.sub(r'[{}]', '', s)
    return s.strip()

def parse_bib_file(filename):
    with open(filename, 'r', encoding='utf-8') as f:
        content = f.read()
    
    entries = {}
    i = 0
    n = len(content)
    while i < n:
        if content[i] == '@':
            j = content.find('{', i)
            if j == -1:
                break
            entry_type = content[i+1:j].strip()
            k = content.find(',', j)
            if k == -1:
                break
            key = content[j+1:k].strip()
            
            brace_count = 1
            idx = k + 1
            body_start = idx
            while idx < n and brace_count > 0:
                if content[idx] == '{':
                    brace_count += 1
                elif content[idx] == '}':
                    brace_count -= 1
                idx += 1
            body = content[body_start:idx-1]
            
            # Extract fields
            fields = {}
            for line in body.split('\n'):
                m = re.match(r'^\s*([a-zA-Z_-]+)\s*=\s*[\"{]?(.*?)[\"}]?,?\s*$', line)
                if m:
                    fname = m.group(1).lower().strip()
                    val = m.group(2).strip('{}," ')
                    fields[fname] = val
                    
            entries[key] = {'type': entry_type, 'key': key, 'fields': fields}
            i = idx
        else:
            i += 1
    return entries

def query_crossref_doi(doi):
    if not doi:
        return {'status': 'no_doi'}
    doi = doi.strip()
    if doi.startswith('http'):
        doi = re.sub(r'^https?://[^/]+/', '', doi)
    encoded = urllib.parse.quote(doi)
    url = f"https://api.crossref.org/works/{encoded}"
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=8) as res:
            if res.status == 200:
                data = json.loads(res.read().decode('utf-8'))['message']
                title = data.get('title', [''])[0] if data.get('title') else ''
                authors = []
                for a in data.get('author', []):
                    g = a.get('given', '')
                    f = a.get('family', '')
                    if f:
                        authors.append(f"{f}, {g}".strip(', '))
                return {
                    'status': 'ok',
                    'title': title,
                    'authors': authors
                }
    except Exception as e:
        return {'status': 'error', 'error': str(e)}

def main():
    entries = parse_bib_file("02_PRL_SUBMISSION/references.bib")
    print(f"Total entries in references.bib: {len(entries)}")
    
    issues = []
    for k, entry in entries.items():
        if entry['type'].lower() in ['control']:
            continue
        doi = entry['fields'].get('doi', '').strip()
        title = clean_str(entry['fields'].get('title', ''))
        if not doi:
            continue
            
        res = query_crossref_doi(doi)
        time.sleep(0.15)
        if res.get('status') == 'ok':
            cr_title = clean_str(res['title'])
            w1 = set(re.findall(r'[a-z0-9]{3,}', title.lower()))
            w2 = set(re.findall(r'[a-z0-9]{3,}', cr_title.lower()))
            overlap = len(w1 & w2)
            if len(w1) > 2 and overlap < max(2, len(w1) * 0.4):
                print(f"[MISMATCH] {k}")
                print(f"  BIB Title: {title[:70]}")
                print(f"  CR  Title: {cr_title[:70]}")
                print(f"  DOI:       {doi}")
                issues.append({'key': k, 'type': 'mismatch', 'bib_title': title, 'cr_title': cr_title, 'doi': doi})
        else:
            print(f"[ERROR] {k}: DOI={doi} -> {res.get('error')}")
            issues.append({'key': k, 'type': 'doi_error', 'bib_title': title, 'doi': doi, 'error': res.get('error')})
            
    with open("scripts/all_bib_issues.json", "w", encoding="utf-8") as f:
        json.dump(issues, f, indent=2)
    print(f"\nDone! Found {len(issues)} total issues out of {len(entries)} entries.")

if __name__ == '__main__':
    main()

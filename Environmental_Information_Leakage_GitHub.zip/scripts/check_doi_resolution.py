import re
import urllib.request
import urllib.parse
import json
import time

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'
}

def check_doi_url(doi):
    if not doi:
        return {'status': 'empty'}
    doi = doi.strip()
    if doi.startswith('http'):
        url = doi
    else:
        url = f"https://doi.org/{urllib.parse.quote(doi)}"
    req = urllib.request.Request(url, headers=headers)
    try:
        # Don't follow redirects all the way or follow with a HEAD/GET
        opener = urllib.request.build_opener(urllib.request.HTTPRedirectHandler)
        with opener.open(req, timeout=10) as res:
            final_url = res.geturl()
            code = res.getcode()
            return {'status': 'ok', 'code': code, 'final_url': final_url}
    except urllib.error.HTTPError as e:
        return {'status': 'http_error', 'code': e.code, 'msg': str(e)}
    except Exception as e:
        return {'status': 'error', 'msg': str(e)}

with open('scripts/reference_verification_report.json', 'r', encoding='utf-8') as f:
    report = json.load(f)

print("Testing direct resolution of all 47 DOIs via https://doi.org/...")
results = []
for i, item in enumerate(report, 1):
    k = item['key']
    doi = item['bib_doi']
    res = check_doi_url(doi)
    time.sleep(0.1)
    status_str = f"[{res['status']} {res.get('code', '')}]"
    print(f"[{i:02d}] {k}: {doi} -> {status_str} {res.get('final_url', res.get('msg', ''))[:80]}")
    results.append({'key': k, 'doi': doi, 'res': res})

with open('scripts/doi_url_check_results.json', 'w', encoding='utf-8') as f:
    json.dump(results, f, indent=2)

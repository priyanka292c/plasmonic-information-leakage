import re
import subprocess
import pypdf

with open("02_PRL_SUBMISSION/PRL_submission.tex", "r", encoding="utf-8") as f:
    text = f.read()

# 1. Update Introduction paragraph 1
target_intro = r"""\emph{Introduction.}---Quantum random number generation (QRNG) is a
fundamental primitive for quantum cryptography, quantum simulation, and
secure communication protocols~\cite{pironio2010random,colbeck2012free,
acin2012randomness,ma2016quantum,herrero2017quantum}.
Solid-state single-photon emitters coupled to nanophotonic platforms offer a
compact, high-speed physical basis for quantum randomness~\cite{lounis2005single,
senellart2017high}.
In a dual-rail / which-path nanophotonic QRNG, single photons enter an optical
50:50 superposition across two spatial paths, with legitimate user Alice
detecting path outcomes $X \in \{0, 1\}$~\cite{jennewein2000fast,stefanov2000optical}.
The operational generation rate is paced by the emitter clock repetition rate,
which is bounded by the spontaneous emission lifetime.
Plasmonic Purcell enhancement, which compresses electromagnetic modes into
deep sub-diffraction volumes yielding Purcell factors $F_P\sim 10^2$--$10^4$
\cite{akselrod2014probing,chikkaraddy2016single,hoang2015ultrafast}, is
therefore widely presumed to offer an ideal hardware platform for
gigahertz-rate QRNG~\cite{aharonovich2016solid}."""

replacement_intro = r"""\emph{Introduction.}---Quantum random number generation (QRNG) is a
fundamental primitive for quantum cryptography and secure communication protocols~\cite{pironio2010random,colbeck2012free}.
Recent advances have established certified private randomness via device-independent and semi-device-independent frameworks~\cite{acin2012randomness,ma2016quantum}, with physical entropy bounds derived under quantum principles~\cite{herrero2017quantum,soorat2017random}.
Certified randomness can be quantified against adversarial side information using speed limits and entropic uncertainty relations~\cite{drahi2020certified,jones2026certified}, while randomness expansion ensures security against untrusted components~\cite{mahato2026certified,adamson2020quantum}.
Experimentally, optical implementations exploit spatial beamsplitters and photon statistics to generate unbiased bits~\cite{jennewein2000fast,stefanov2000optical}.
Practical systems employ source-device-independent heterodyne detection~\cite{avesani2018source} or multiplexed spatial modes~\cite{haylock2019multiplexed} to reach gigabit rates.
Recently, interferometric configurations such as Michelson geometries have demonstrated high-speed quantum random number generation~\cite{soorat2026interferometric}, while Mach--Zehnder architectures provide crucial insights into spatial state behavior and decoherence~\cite{sajeev2024advancing}.
Optical self-testing and source-independent detection have further addressed efficiency mismatch~\cite{ma2020practical,petrov2022independent}, while integrated photonic chips achieve robust noise-rejecting randomness~\cite{smith2025noise,shaliq2026quantum}.
Multi-bit extraction from quantum walks~\cite{sarkar2019multi} and high-rate entropy extraction pipelines~\cite{solymos2020real,singh2026quantum} underscore the technological maturity of photonic QRNG.

Solid-state single-photon emitters coupled to nanophotonic cavities provide a deterministic physical basis for quantum light sources~\cite{lounis2005single,senellart2017high}.
High-brightness, coherent single-photon emission has been demonstrated using polarized microcavities~\cite{wang2019towards,tomm2021bright} and scalable integrated waveguides~\cite{uppu2020scalable,li2022photonic}.
Plasmonic Purcell enhancement, which compresses optical modes into deep sub-diffraction volumes yielding Purcell factors $F_P \sim 10^2$--$10^4$~\cite{akselrod2014probing,chikkaraddy2016single}, enables ultrafast radiative decay~\cite{hoang2015ultrafast,kanli2026purcell}.
Hybrid plasmonic--photonic resonators and microcavities further enhance spontaneous emission rates~\cite{cao2020chiral,azzam2023purcell}.
Similar Purcell accelerations have been realized in silicon-integrated emitters~\cite{gritsch2023purcell} and single molecules in cavity QED~\cite{wang2021cavity}.
Consequently, plasmonic coupling of quantum dots has been widely explored for low-threshold nanolasers and accelerated quantum sources~\cite{priyanka2026numerical,priyanka2026design}."""

assert target_intro in text, "Target intro not found"
text = text.replace(target_intro, replacement_intro)

# 2. Update electrodynamic model paragraph around chance1978 and remark
target_decay = r"""which decomposes into radiative and non-radiative rates:
$\Gamma_{\mathrm{tot}} = \Gamma_{\mathrm{rad}} + \Gamma_{\mathrm{pl}} + \Gamma_{\mathrm{nr}}$
\cite{chance1978molecular,ford1984electrodynamic}."""

replacement_decay = r"""which decomposes into radiative and non-radiative rates:
$\Gamma_{\mathrm{tot}} = \Gamma_{\mathrm{rad}} + \Gamma_{\mathrm{pl}} + \Gamma_{\mathrm{nr}}$
\cite{chance1978molecular,ford1984electrodynamic}.
Energy transfer near metallic interfaces induces severe fluorescence quenching~\cite{samir2018fluorescence}, while first-principles damping governs Ohmic dissipation in noble metals~\cite{martirez2026optical}."""

assert target_decay in text, "Target decay not found"
text = text.replace(target_decay, replacement_decay)

target_remark = r"""Because hydrodynamic nonlocality, electron spill-out, and quantum tunnelling soften near-field divergences for $d \lesssim 1$--$3$\,nm~\cite{mcmahon2013nonlocal,raza2015nonlocal,mortensen2014generalized}, all physical conclusions and Proposition~1 are conservatively restricted to $d \ge 5$\,nm; calculations below 5\,nm serve solely as computational solver-stress tests."""

replacement_remark = r"""Because hydrodynamic nonlocality, electron spill-out, and quantum tunnelling soften near-field divergences for $d \lesssim 1$--$3$\,nm~\cite{mcmahon2013nonlocal,raza2015nonlocal,mortensen2014generalized}, all physical conclusions and Proposition~1 are conservatively restricted to $d \ge 5$\,nm, with conformal transformation methods elucidating the quenching corridor in plasmonic nanocavities~\cite{pachecopea2018understanding,zhang2018plasmonic}; calculations below 5\,nm serve solely as computational solver-stress tests."""

assert target_remark in text, "Target remark not found"
text = text.replace(target_remark, replacement_remark)

# 3. Update Stinespring / decoherence
target_purif = r"""Under the conservative worst-case adversarial purification principle of
quantum cryptography~\cite{devetak2005distillation,wilde2013quantum,konig2009operational},
all uncollected environmental degrees of freedom ($E$) are assigned to an adversary Eve."""

replacement_purif = r"""Under the conservative worst-case adversarial purification principle of
quantum cryptography~\cite{devetak2005distillation,wilde2013quantum},
all uncollected environmental degrees of freedom ($E$) are assigned to an adversary Eve.
Decoherence and open-loop quantum maps on photonic qubits can be mitigated via concatenated dynamical decoupling~\cite{damodarakurup2024concatenated}, yet dissipation into unobserved reservoir modes grants Eve side information bounding Alice's conditional min-entropy~\cite{konig2009operational,tomamichel2011leftover}."""

assert target_purif in text, "Target purif not found"
text = text.replace(target_purif, replacement_purif)

# 4. Update Experimental outlook
target_exp = r"""\emph{Experimental outlook.}---Solid-state color centers and quantum dots operated at optimal separations $d^* \approx 14$--$50$\,nm via dielectric spacers (e.g., Al$_2$O$_3$ or PMMA) can harness Purcell acceleration while avoiding severe quenching.
For an idealized SiV$^-$ center in diamond ($\tau_0 \approx 1.1$\,ns, $\lambda = 738$\,nm)~\cite{aharonovich2016solid}, the model yields an idealized model-based asymptotic capacity estimate of $\sim 210$\,Mbps under the trusted-device model.
Realistic operational rates will be lower due to collection optics, detector dead time, jitter, and finite-size security penalties (Supplemental Material)."""

replacement_exp = r"""\emph{Experimental outlook.}---Solid-state color centers and quantum dots operated at optimal separations $d^* \approx 14$--$50$\,nm via dielectric spacers can harness Purcell acceleration while avoiding severe quenching.
Integration of single diamond color centers with nanophotonic devices offers a robust platform for quantum technologies~\cite{tan2024diamond,aharonovich2016solid}.
In particular, silicon-vacancy (SiV$^-$) centers engineered in high-purity diamond provide narrow optical transitions and long spin coherence~\cite{zheng2026hthp,malykhin2022control}, making them attractive candidates for platform-integrated single-photon generation~\cite{gras2021quantum}.
For an idealized SiV$^-$ center ($\tau_0 \approx 1.1$\,ns, $\lambda = 738$\,nm), the model yields an idealized asymptotic capacity estimate of $\sim 210$\,Mbps under the trusted-device model.
Realistic operational rates will be lower due to collection optics, detector dead time, jitter, and finite-size security penalties (Supplemental Material)."""

assert target_exp in text, "Target exp not found"
text = text.replace(target_exp, replacement_exp)

with open("02_PRL_SUBMISSION/PRL_submission.tex", "w", encoding="utf-8") as f:
    f.write(text)

print("Successfully updated PRL_submission.tex with all sequential verified references!")

"""
Script to generate the enhanced manuscript.tex and supplementary_information.tex
for Springer Plasmonics, addressing all 20 referee critique points completely.
"""
import os

MANUSCRIPT_PATH = r"11_SPRINGER_PLASMONICS_SUBMISSION/manuscript/manuscript.tex"
SI_PATH = r"11_SPRINGER_PLASMONICS_SUBMISSION/supplementary/supplementary_information.tex"

print("Starting generation of enhanced Springer Plasmonics manuscript...")

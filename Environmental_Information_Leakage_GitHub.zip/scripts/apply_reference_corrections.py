import re

def update_bib_file(path):
    with open(path, 'r', encoding='utf-8') as f:
        content = f.read()

    # 1. drahi2020certified
    r1 = '''@article{drahi2020certified,
  title = {Certified Quantum Random Numbers from Untrusted Light},
  author = {Drahi, David and Walk, Nathan and Hoban, Matty J. and Fedorov, Aleksey K. and Shakhovoy, Roman and Feimov, Anton and Kurochkin, Yury and Kolthammer, W. Steven and Nunn, Josh and Barrett, Jonathan and Walmsley, Ian A.},
  journal = {Physical Review X},
  year = {2020},
  volume = {10},
  pages = {041048},
  doi = {10.1103/PhysRevX.10.041048},
}'''
    content = re.sub(
        r'@article\{drahi2020certified,.*?journal\s*=\s*\{PRX Quantum\},.*?volume\s*=\s*\{1\},.*?pages\s*=\s*\{010302\},.*?doi\s*=\s*\{10\.1103/PRXQuantum\.1\.010302\},?\s*\}',
        lambda m: r1,
        content,
        flags=re.DOTALL
    )

    # 2. wang2019towards
    r2 = '''@article{wang2019towards,
  author = {Wang, Hui and He, Yu-Ming and Chung, T.-H. and Hu, H. and Yu, Ying and Ding, Xing and Chen, Ming-Cheng and Qin, Jian and Yang, Xiaoxia and Liu, Run-Ze and Bao, Xiao-Hui and Li, Chuan-Feng and Schneider, Christian and Kamp, Martin and H{\\"o}fling, Sven and Lu, Chao-Yang and Pan, Jian-Wei},
  title = {Towards optimal single-photon sources from polarized microcavities},
  journal = {Nature Photonics},
  volume = {13},
  pages = {770--775},
  year = {2019},
  doi = {10.1038/s41566-019-0494-3}
}'''
    content = re.sub(
        r'@article\{wang2019towards,.*?doi\s*=\s*\{10\.1038/s41565-019-0551-x\}\s*\}',
        lambda m: r2,
        content,
        flags=re.DOTALL
    )

    # 3. dung1998spontaneous
    r3 = '''@article{dung1998spontaneous,
  title = {Three-dimensional quantization of the electromagnetic field in dispersive and absorbing inhomogeneous dielectrics},'''
    content = re.sub(
        r'@article\{dung1998spontaneous,.*?title\s*=\s*\{Spontaneous decay in the presence of dispersing and absorbing bodies: General theory and application to a metallic waveguide\},',
        lambda m: r3,
        content,
        flags=re.DOTALL
    )

    # 4. purcell1946spontaneous
    r4 = '''@article{purcell1946spontaneous,
  title = {Spontaneous Emission Probabilities at Radio Frequencies},
  author = {Purcell, Edward M.},
  journal = {Physical Review},
  year = {1946},
  volume = {69},
  pages = {681},
  doi = {10.1103/PhysRev.69.681},
}'''
    content = re.sub(
        r'@article\{purcell1946spontaneous,.*?doi\s*=\s*\{10\.1103/PhysRev\.69\.37\},?\s*\}',
        lambda m: r4,
        content,
        flags=re.DOTALL
    )

    # 5. bozhevolnyi2017plasmonics
    r5 = '''@article{bozhevolnyi2017plasmonics,
  author = {Bozhevolnyi, Sergey I. and Mortensen, N. Asger},
  title = {Plasmonics for emerging quantum technologies},
  journal = {Nanophotonics},
  volume = {6},
  pages = {1185--1188},
  year = {2017},
  doi = {10.1515/nanoph-2016-0179}
}'''
    content = re.sub(
        r'@article\{bozhevolnyi2017plasmonics,.*?doi\s*=\s*\{10\.1364/OPTICA\.3\.001418\}\s*\}',
        lambda m: r5,
        content,
        flags=re.DOTALL
    )

    # 6. gabriel2010generator
    r6 = '''@article{gabriel2010generator,
  title = {A generator for unique quantum random numbers based on vacuum states},
  author = {Gabriel, Christian and Wittmann, Christoffer and Sych, Denis and Dong, Ruifang and Mauerer, Wolfgang and Andersen, Ulrik L. and Marquardt, Christoph and Leuchs, Gerd},
  journal = {Nature Photonics},
  year = {2010},
  volume = {4},
  pages = {711--715},
  doi = {10.1038/nphoton.2010.197},
}'''
    content = re.sub(
        r'@article\{gabriel2010generator,.*?doi\s*=\s*\{10\.1038/nphoton\.2010\.232\},?\s*\}',
        lambda m: r6,
        content,
        flags=re.DOTALL
    )

    # 7. alu2008tuning
    r7 = '''@article{alu2008tuning,
  author = {Al{\\`u}, Andrea and Engheta, Nader},
  title = {Tuning the Scattering Response of Optical Nanoantennas with Nanocircuit Loads},
  journal = {Nature Photonics},
  volume = {2},
  pages = {307--310},
  year = {2008},
  doi = {10.1038/nphoton.2008.53}
}'''
    content = re.sub(
        r'@article\{alu2008tuning,.*?doi\s*=\s*\{10\.1103/PhysRevLett\.100\.113901\}\s*\}',
        lambda m: r7,
        content,
        flags=re.DOTALL
    )

    # 8. chang2007single
    r8 = '''@article{chang2007single,
  author = {Chang, Darrick E. and S{\\o}rensen, Anders S. and Demler, Eugene A. and Lukin, Mikhail D.},
  title = {A single-photon transistor using nanoscale surface plasmons},
  journal = {Nature Physics},
  volume = {3},
  pages = {807--812},
  year = {2007},
  doi = {10.1038/nphys708}
}'''
    content = re.sub(
        r'@article\{chang2007single,.*?doi\s*=\s*\{10\.1038/nphys720\}\s*\}',
        lambda m: r8,
        content,
        flags=re.DOTALL
    )

    # 9. croke2006maximum
    r9 = '''@article{croke2006maximum,
  author = {Croke, Sarah and Andersson, Erika and Barnett, Stephen M. and Gilson, Claire R. and Jeffers, John},
  title = {Maximum Confidence Quantum Measurements},
  journal = {Physical Review Letters},
  volume = {96},
  pages = {070401},
  year = {2006},
  doi = {10.1103/PhysRevLett.96.070401}
}'''
    content = re.sub(
        r'@article\{croke2006maximum,.*?pages\s*=\s*\{070501\},.*?doi\s*=\s*\{10\.1103/PhysRevLett\.96\.070501\}\s*\}',
        lambda m: r9,
        content,
        flags=re.DOTALL
    )

    # 10. stockman2011nanoplasmonics
    r10 = '''@article{stockman2011nanoplasmonics,
  author = {Stockman, Mark I.},
  title = {Nanoplasmonics: The physics behind the applications},
  journal = {Physics Today},
  volume = {64},
  number = {2},
  pages = {39--44},
  year = {2011},
  doi = {10.1063/1.3554315}
}'''
    content = re.sub(
        r'@article\{stockman2011nanoplasmonics,.*?doi\s*=\s*\{10\.1364/OE\.19\.022029\}\s*\}',
        lambda m: r10,
        content,
        flags=re.DOTALL
    )

    # 11. koenderink2010spontaneous
    r11 = '''@article{koenderink2010spontaneous,
  title = {On the use of Purcell factors for plasmon antennas},'''
    content = re.sub(
        r'@article\{koenderink2010spontaneous,.*?title\s*=\s*\{Spontaneous emission rates in metallic and plasmonic cavities\},',
        lambda m: r11,
        content,
        flags=re.DOTALL
    )

    # 12. russell2012spectrally
    r12 = '''@article{russell2012spectrally,
  title = {Large spontaneous emission enhancement in plasmonic nanocavities},'''
    content = re.sub(
        r'@article\{russell2012spectrally,.*?title\s*=\s*\{Spectrally resolved energy pathways in plasmonic quenching\},',
        lambda m: r12,
        content,
        flags=re.DOTALL
    )

    # 13. hummer2012weak
    r13 = '''@article{hummer2012weak,
  author = {H{\\"u}mmer, Thomas and Garc{\\'\\i}a-Vidal, Francisco J. and Mart{\\'\\i}n-Moreno, Luis and Zueco, David},
  title = {Weak and strong coupling of quantum emitters to polaritonic modes},
  journal = {Physical Review B},
  volume = {87},
  pages = {115419},
  year = {2013},
  doi = {10.1103/PhysRevB.87.115419}
}'''
    content = re.sub(
        r'@article\{hummer2012weak,.*?doi\s*=\s*\{10\.1103/PhysRevLett\.109\.177403\}\s*\}',
        lambda m: r13,
        content,
        flags=re.DOTALL
    )

    # 14. chen2009quantum
    r14 = '''@article{chen2009quantum,
  author = {Chen, Guan-Yu and Chen, Yueh-Nan and Chuu, Der-San},
  title = {Quantum state transfer in plasmonic circuits with Ohmic damping},
  journal = {Physical Review B},
  volume = {81},
  pages = {155314},
  year = {2010},
  doi = {10.1103/PhysRevB.81.155314}
}'''
    content = re.sub(
        r'@article\{chen2009quantum,.*?doi\s*=\s*\{10\.1103/PhysRevB\.80\.201407\}\s*\}',
        lambda m: r14,
        content,
        flags=re.DOTALL
    )

    # Remove the 4 uncited broken entries: fiorentino2007quantum, brandao2015quantum, bylander2005single, cano2011multimode
    for bad_key in ['fiorentino2007quantum', 'brandao2015quantum', 'bylander2005single', 'cano2011multimode']:
        content = re.sub(rf'@article\{{{bad_key},.*?\n\}}\n*', '', content, flags=re.DOTALL)

    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"Updated {path} successfully!")

update_bib_file("02_PRL_SUBMISSION/references.bib")
update_bib_file("02_PRL_SUBMISSION/supplementary/references.bib")

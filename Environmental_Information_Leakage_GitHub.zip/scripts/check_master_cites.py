import re

with open('01_MASTER_MANUSCRIPT/master_manuscript.tex', 'r', encoding='utf-8') as f:
    text = f.read()

citations = set()
for match in re.finditer(r'\\cite\{([^}]+)\}', text):
    for key in match.group(1).split(','):
        citations.add(key.strip())

with open('01_MASTER_MANUSCRIPT/references.bib', 'r', encoding='utf-8') as f:
    bib = f.read()

bib_keys = set(re.findall(r'@\w+\{([^,]+),', bib))

missing = citations - bib_keys
print(f"Total citations in master manuscript: {len(citations)}")
print(f"Total keys in bib: {len(bib_keys)}")
print(f"Missing keys ({len(missing)}): {sorted(missing)}")

import sympy as sp

# Let's consider the two-level emitter with states |g> (ground) and |e> (excited).
# Alice prepares the coherent superposition:
# |psi>_S = (|g> + |e>) / sqrt(2)
#
# Spontaneous decay channel with Stinespring isometry V: H_S -> H_B \otimes H_E
# V |g> = |0>_B |0>_E
# V |e> = sqrt(eta) |1>_B |0>_E + sqrt(1-eta) |0>_B |1>_E
#
# Here:
# |0>_B = vacuum in Alice's radiation mode
# |1>_B = single photon registered in Alice's mode
# |0>_E = vacuum in Eve's environment
# |1>_E = Ohmic/guided excitation in Eve's reservoir
# eta = eta_rad \in [0, 1] is the radiative branching ratio.
#
# The pure tripartite state before dephasing is:
# |Psi>_SBE = (1/sqrt(2)) [ |g>_S |0>_B |0>_E + sqrt(eta) |g>_S |1>_B |0>_E + sqrt(1-eta) |g>_S |0>_B |1>_E ]
# Wait, notice that upon decay, |e> decays to |g>!
# So the emitter state is |g>_S for all decay terms.
# If Alice measures the emitter or the emitted photon?
#
# Case 1: Alice measures the emitted field mode B.
# Alice's measurement on mode B:
# Alice has a single-photon detector.
# Out of pulses where Alice receives a photon (|1>_B), Alice measures the polarization or path:
# Suppose the single photon is prepared in polarization:
# |psi>_photon = (|H> + |V>)/sqrt(2) = |+>
# The channel transmits H and V with efficiency eta_rad into Alice's field,
# and absorbs into Eve's reservoir with probability 1 - eta_rad.
# If absorbed, Eve receives which polarization was absorbed (or Eve gets the Ohmic dipole current)!
# Let's write the isometry on the polarization/path qubit:
# V |0> = sqrt(eta) |0>_B |0>_E + sqrt(1-eta) |vac>_B |0>_E
# V |1> = sqrt(eta) |1>_B |0>_E + sqrt(1-eta) |vac>_B |1>_E
# where |0>_E and |1>_E are orthogonal environmental states (e.g. x-polarized vs y-polarized plasmon modes, or early vs late Ohmic currents).
#
# Initial state prepared: |+> = (|0> + |1>)/sqrt(2)
# Joint state after channel:
# |Psi_BE> = (1/sqrt(2)) [ sqrt(eta) (|0>_B + |1>_B) |0>_E + sqrt(1-eta) |vac>_B (|0>_E + |1>_E) ]
#
# Now include pure dephasing between mode 0 and mode 1 at rate gamma_phi:
# Over time t_det, the coherence between |0> and |1> decays by factor mu:
# rho_in = (1/2) * [ [1, mu], [mu, 1] ]
#
# Let's compute rho_BE:
# The input density matrix is:
# rho_in = (1/2) |0><0| + (1/2) |1><1| + (mu/2) |0><1| + (mu/2) |1><0|
#
# Applying V:
# V |0><0| V^\dagger = eta |0><0|_B |0><0|_E + (1-eta) |vac><vac|_B |0><0|_E
# V |1><1| V^\dagger = eta |1><1|_B |0><0|_E + (1-eta) |vac><vac|_B |1><1|_E
# V |0><1| V^\dagger = eta |0><1|_B |0><0|_E + (1-eta) |vac><vac|_B |0><1|_E
# V |1><0| V^\dagger = eta |1><0|_B |0><0|_E + (1-eta) |vac><vac|_B |1><0|_E
#
# So rho_BE is:
# eta * [ (1/2)|0><0|_B + (1/2)|1><1|_B + (mu/2)|0><1|_B + (mu/2)|1><0|_B ] \otimes |0><0|_E
# + (1-eta) |vac><vac|_B \otimes [ (1/2)|0><0|_E + (1/2)|1><1|_E + (mu/2)|0><1|_E + (mu/2)|1><0|_E ]
#
# Now Alice measures her photon in the computational basis:
# Alice projects onto {|0>_B, |1>_B} (e.g. horizontal vs vertical polarization, or path 0 vs path 1).
# Outcome x = 0: Alice detects |0>_B (prob p(0) = eta/2)
# Outcome x = 1: Alice detects |1>_B (prob p(1) = eta/2)
# Notice that whenever Alice detects a photon (|0>_B or |1>_B),
# the term is proportional to |0><0|_E!
# Eve's state is |0><0|_E in BOTH cases!
# So rho_E^(0) = |0><0|_E and rho_E^(1) = |0><0|_E!
# Then ||rho_E^(0) - rho_E^(1)||_1 = 0!
# Eve has ZERO information about which port clicked!
#
# BUT WAIT! What if Alice measures in the X basis {|+>_B, |->_B}?
# Let |+> = (|0> + |1>)/sqrt(2), |-> = (|0> - |1>)/sqrt(2).
# What if the source PREPARES |0> or |1>?
# OR what if Alice prepares |+> and measures in {|+>, |->}?
# Let's calculate what happens when Alice measures in {|+>, |->}:
# Alice's projectors are Pi_+ = |+><+|_B and Pi_- = |-><-|_B.
# For outcome +:
# Tr_B[ Pi_+ rho_BE ] = eta * (1+mu)/4 * |0><0|_E
# For outcome -:
# Tr_B[ Pi_- rho_BE ] = eta * (1-mu)/4 * |0><0|_E
# Again Eve's state is |0><0|_E!
#
# NOW WHAT IF EVE PURIFIES THE DEPHASING AND VACUUM LOSS?
# Look at the tripartite pure state!
# If the state rho_in is pure |+> = (|0> + |1>)/sqrt(2),
# but undergoes dephasing into environment E_phi:
# |Psi> = (1/sqrt(2)) [ |0>_S |0>_E_phi + |1>_S |1>_E_phi ]
# Then Eve holds E_phi!
# For outcome x = 0 (Alice detects |0>): Eve's state is |0>_E_phi.
# For outcome x = 1 (Alice detects |1>): Eve's state is |1>_E_phi.
# The overlap is <0|1>_E_phi = mu!
# Eve's states are pure states |0> and |1> with overlap mu!
# Trace distance between two pure states with overlap mu:
# D = sqrt(1 - |<0|1>|^2) = sqrt(1 - mu^2)!
#
# AND WHAT ABOUT OHMIC QUENCHING?
# If the excitation is absorbed into the metal with probability 1 - eta_rad,
# Eve receives the absorbed excitation.
# If Eve measures the environment, can Eve predict Alice's outcome?
# Let's derive the exact relationship!

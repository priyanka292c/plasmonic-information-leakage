import pypdf

for path in ['02_PRL_SUBMISSION/PRL_submission.pdf', '02_PRL_SUBMISSION/supplementary/supplementary.pdf', '01_MASTER_MANUSCRIPT/master_manuscript.pdf']:
    reader = pypdf.PdfReader(path)
    print(f"{path}: {len(reader.pages)} pages")

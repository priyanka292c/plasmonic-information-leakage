with open("02_PRL_SUBMISSION/references.bib", "r", encoding="utf-8") as f:
    existing_bib = f.read()

with open("scripts/generated_recent_bibtex.bib", "r", encoding="utf-8") as f:
    new_bib = f.read()

# Append if not already present
with open("02_PRL_SUBMISSION/references.bib", "w", encoding="utf-8") as f:
    f.write(existing_bib + "\n\n% =========================================================\n% Recent Verified References (QRNG, Plasmonics, Ram Soorat)\n% =========================================================\n\n" + new_bib)

print("Appended verified entries to references.bib")

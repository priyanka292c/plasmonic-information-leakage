import os
import zipfile
import sys

def create_github_zip(output_path='Environmental_Information_Leakage_GitHub.zip'):
    print(f"Creating GitHub archive: {output_path}...")
    
    # Exclude directories that contain redundant archives, scratch files, or old duplicates
    exclude_dirs = {
        '10_ARCHIVE',
        'scratch',
        '.git',
        '__pycache__',
        '.vscode',
        '.idea',
        '01_MASTER_MANUSCRIPT',
        '02_PRL_SUBMISSION',
        'releases'
    }
    
    # Exclude build artifacts and temporary files
    exclude_exts = {
        '.aux', '.log', '.blg', '.fls', '.fdb_latexmk', '.synctex.gz',
        '.pyc', '.bak', '.tmp', '.DS_Store', 'Thumbs.db', '.out', '.toc'
    }
    
    file_count = 0
    total_uncompressed = 0
    
    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for root, dirs, files in os.walk('.'):
            # Prune excluded directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith('.')]
            if any(part in exclude_dirs for part in root.split(os.sep)):
                continue
            
            # In 05_FIGURES, exclude jpeg and main duplicates (keep vector and png)
            if '05_FIGURES' in root and ('jpeg' in root or 'main' in root):
                continue
                
            for f in files:
                if f == output_path or f.endswith('.zip'):
                    continue
                ext = os.path.splitext(f)[1].lower()
                if ext in exclude_exts:
                    continue
                    
                fp = os.path.join(root, f)
                arcname = os.path.relpath(fp, '.')
                sz = os.path.getsize(fp)
                zf.write(fp, arcname)
                file_count += 1
                total_uncompressed += sz

    compressed_size = os.path.getsize(output_path)
    size_mb_decimal = compressed_size / 1_000_000
    size_mib_binary = compressed_size / (1024 * 1024)
    
    print("\n" + "="*60)
    print("Archive Generation Complete!")
    print(f"Archive File:         {output_path}")
    print(f"Files Packaged:       {file_count}")
    print(f"Uncompressed Size:    {total_uncompressed / (1024*1024):.2f} MiB ({total_uncompressed:,} bytes)")
    print(f"Compressed Size:      {size_mib_binary:.2f} MiB ({size_mb_decimal:.2f} MB)")
    print(f"Exact Size in Bytes:  {compressed_size:,} bytes")
    print(f"25MB Limit Check:     {'PASSED (strictly < 25 MB)' if compressed_size < 25_000_000 else 'FAILED'}")
    print("="*60)
    
    if compressed_size > 25_000_000:
        print("ERROR: File size exceeds 25 MB limit!", file=sys.stderr)
        sys.exit(1)
        
    # Verify archive integrity
    print("\nVerifying zip integrity...")
    with zipfile.ZipFile(output_path, 'r') as zf:
        bad_file = zf.testzip()
        if bad_file:
            print(f"ERROR: Corrupted file in archive: {bad_file}", file=sys.stderr)
            sys.exit(1)
        print("Integrity verification PASSED! Zero errors found.")

if __name__ == '__main__':
    create_github_zip()

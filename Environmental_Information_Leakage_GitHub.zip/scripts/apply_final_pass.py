import os

def update_manuscript():
    path = "scripts/write_manuscript.py"
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()

    # 1. Replace universal bridge
    old_bridge = r"This cross-geometry agreement demonstrates that the decay-branching ratio $\Xi$ provides an accurate universal bridge between computational electrodynamics and quantum privacy across diverse nanophotonic platforms."
    new_bridge = r"This cross-geometry agreement demonstrates the cross-geometry consistency of the branching-ratio mapping within the investigated model across disparate nanophotonic structures, showing that constructing $\Xi$ from modal loss ratios reproduces $\Phi(\Xi)$ within $<3\%$ without asserting physical equivalence between localized dipole decay and propagating waveguide modes."
    text = text.replace(old_bridge, new_bridge)

    # 2. Replace Universal phase diagram
    old_phase = r"\caption{\textbf{Universal phase diagram in the $(F_P, \Xi)$ parameter plane.}"
    new_phase = r"\caption{\textbf{Information-aware phase diagram in the $(F_P, \Xi)$ parameter plane.}"
    text = text.replace(old_phase, new_phase)

    # 3. Replace universal scaling
    old_scaling = r"Figure~\ref{fig:scaling} displays the universal scaling of $H_{\min}(X|E)$ across five orders of magnitude of $\Xi$"
    new_scaling = r"Figure~\ref{fig:scaling} displays the model-predicted scaling of $H_{\min}(X|E)$ across five orders of magnitude of $\Xi$"
    text = text.replace(old_scaling, new_scaling)

    old_branching_uni = r"where we introduce the universal dimensionless decay-branching ratio:"
    new_branching_uni = r"where we introduce the dimensionless decay-branching ratio:"
    text = text.replace(old_branching_uni, new_branching_uni)

    old_noble_uni = r"This confirms that the non-monotonic rate trajectory is a universal feature of noble-metal plasmonics across the visible spectrum."
    new_noble_uni = r"This confirms that the non-monotonic rate trajectory is a general feature of noble-metal plasmonic interfaces across the visible spectrum."
    text = text.replace(old_noble_uni, new_noble_uni)

    # 4. Replace certifiable by Alice
    old_cert = r"zero environmental leakage ensures that the full quantum entropy of the spatial superposition is certifiable by Alice."
    new_cert = r"zero environmental leakage ensures that the full quantum entropy of the spatial superposition is retained by Alice as private quantum entropy (approaching the theoretical maximum of 1 bit)."
    text = text.replace(old_cert, new_cert)

    # 5. Add definition sentence immediately after rate definitions in Section 4.1
    old_enum_end = r"""    Under this arm-weighted definition, the uncoupled reference baseline is $R_0^{(\rm arm)} \equiv p_1 R_0 \approx 0.85$\,Mbps. The peak plasmonic-arm throughput is $R_{\rm priv}^{(\rm arm),\max} \approx 0.101$\,Mbps for planar gold and $R_{\rm priv}^{(\rm arm),\max} \approx 0.231$\,Mbps for silver. At $d = 5$\,nm, the arm rate collapses to $\sim 0.50$\,kbps.
\end{enumerate}"""

    new_enum_end = r"""    Under this arm-weighted definition, the uncoupled reference baseline is $R_0^{(\rm arm)} \equiv p_1 R_0 \approx 0.85$\,Mbps. The peak plasmonic-arm throughput is $R_{\rm priv}^{(\rm arm),\max} \approx 0.101$\,Mbps for planar gold and $R_{\rm priv}^{(\rm arm),\max} \approx 0.231$\,Mbps for silver. At $d = 5$\,nm, the arm rate collapses to $\sim 0.50$\,kbps.
\end{enumerate}
Accordingly, both $R_{\rm priv}^{(\rm ch)}$ and $R_{\rm priv}^{(\rm arm)}$ should be interpreted as model-based private-randomness throughput metrics rather than demonstrated extractor output rates. They quantify the operational quantum information delivered through the optical channel under ideal single-photon detection and source reset, serving as theoretical throughput ceilings for device optimization."""

    text = text.replace(old_enum_end, new_enum_end)

    # 6. Re-title Section 4.3 and Theorem 1
    old_sec43 = r"\subsection{Parameter Scaling and Invariance of the Optimal Separation}"
    new_sec43 = r"\subsection{Invariance of the Optimal Separation under Repetition-Rate Scaling}"
    text = text.replace(old_sec43, new_sec43)

    old_thm1 = r"\begin{theorem}[Parameter Scaling and Invariance of Optimal Separation Distance]"
    new_thm1 = r"\begin{theorem}[Invariance of Optimal Separation under Repetition-Rate Scaling]"
    text = text.replace(old_thm1, new_thm1)

    with open(path, "w", encoding="utf-8") as f:
        f.write(text)

    print("Updated write_manuscript.py successfully in final pass!")

def update_supplementary():
    path = "scripts/write_supplementary.py"
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()

    # Soften 92% finite-statistics claim in Section S7
    old_92 = r"the certifiable smooth min-entropy rate for security parameter $\varepsilon_{\rm sec} = 10^{-10}$ converges to within $92\%$ of the asymptotic bound $\Phi(\Xi)$ for block sizes $N \ge 10^5$."
    new_92 = r"finite-block statistical corrections can be incorporated using the Leftover Hash Lemma with quantum side information~\cite{tomamichel2011leftover}; for sufficiently large blocks ($N \ge 10^5$), the smooth min-entropy rate for security parameter $\varepsilon_{\rm sec} = 10^{-10}$ closely approaches the asymptotic theoretical bound $\Phi(\Xi)$."
    text = text.replace(old_92, new_92)

    with open(path, "w", encoding="utf-8") as f:
        f.write(text)

    print("Updated write_supplementary.py successfully in final pass!")

def update_cover_letter():
    path = "11_SPRINGER_PLASMONICS_SUBMISSION/cover_letter/cover_letter.tex"
    streamlined_letter = r"""% =========================================================================
% Cover Letter for Submission to Springer Journal "Plasmonics"
% Authors: Priyanka and Ram Soorat
% =========================================================================
\documentclass[11pt,a4paper]{article}

\usepackage[margin=2.2cm,top=2.0cm,bottom=2.0cm]{geometry}
\usepackage{amsmath}
\usepackage{hyperref}
\usepackage{microtype}
\usepackage{parskip}
\usepackage{charter}

\setlength{\parskip}{4pt plus 1pt}
\hypersetup{colorlinks=true,urlcolor=blue,citecolor=blue,linkcolor=blue}

\begin{document}

\noindent
\textbf{Priyanka}$^1$ \quad and \quad \textbf{Ram Soorat}$^{2,*}$ (Corresponding Author)\\[2pt]
$^1$Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India\\
$^2$School of Technology, Woxsen University, Hyderabad, Telangana 502345, India\\
$^*$Email: \href{mailto:ram.soorat@woxsen.edu.in}{ram.soorat@woxsen.edu.in}

\medskip\noindent\today

\bigskip

\noindent
To:\\
The Editor-in-Chief\\
\textit{Plasmonics}, Springer Nature

\bigskip

\noindent
Dear Editor-in-Chief,

\medskip

We respectfully submit our original research manuscript entitled:
\begin{center}
\large\textbf{``Plasmonic Purcell Enhancement versus Environmental Information Leakage\\in Private Quantum Randomness Generation''}
\end{center}
for consideration for publication as a regular research article in \textit{Plasmonics}.

\medskip\noindent\textbf{Context and Prior Evaluation Disclosure.}
In adherence to Springer Nature publication ethics, we disclose that a preliminary version of this work was previously evaluated by another journal. The present manuscript has been substantially reconceptualized, expanded, and repositioned for \textit{Plasmonics}. It features a newly formulated macroscopic Green-tensor channel decomposition, Au/Ag material dispersion comparisons, multi-solver electrodynamic benchmarks, and a rigorous open-system information-theoretic analysis tailored to nanophotonic quantum sources.

\medskip\noindent\textbf{Core Physics and Key Findings.}
In nanoplasmonics, spontaneous-emission engineering has traditionally focused on maximizing the Purcell factor ($F_P = \Gamma_{\rm tot}/\Gamma_0 \to \infty$). While decay partitioning into radiative modes ($\Gamma_{\rm rad}$), surface plasmon polaritons ($\Gamma_{\rm pl}$), and Ohmic dissipation ($\Gamma_{\rm nr}$) is well established, this competition has typically been analyzed as an issue of optical collection efficiency.

In this work, we show that in lossy plasmonic environments, spontaneous-emission acceleration and private quantum information preservation are competing physical processes:
\begin{equation*}
F_P \uparrow \;\not\Rightarrow\; R_{\rm priv} \uparrow.
\end{equation*}
When an open quantum emitter is coupled to a metallic interface, uncollected polaritonic and Ohmic loss ($\Gamma_E \equiv \Gamma_{\rm pl} + \Gamma_{\rm nr}$) acts as an eavesdropping side channel that leaks which-path information to the environment. Within an open-system Stinespring channel model, we establish that private conditional min-entropy is governed by an exact closed-form relation:
\begin{equation*}
H_{\min}(X|E) = \log_2\!\left[\frac{2(1+\Xi)}{2+\Xi}\right] \equiv \Phi(\Xi),
\qquad
\Xi \equiv \frac{\Gamma_{\rm rad}}{\Gamma_{\rm pl} + \Gamma_{\rm nr}}.
\end{equation*}
Because extreme near-field confinement drives $\Xi \to 0$, the model-predicted private-randomness throughput exhibits a finite-distance local optimum: planar gold peaks at $d^* \approx 33.8$\,nm ($R_{\rm priv}^{(\rm ch),\max} \approx 0.201$\,Mbps channel throughput; $R_{\rm priv}^{(\rm arm),\max} \approx 0.101$\,Mbps net dual-rail arm contribution), and silver at $d^* \approx 17.5$\,nm ($R_{\rm priv}^{(\rm ch),\max} \approx 0.462$\,Mbps; $R_{\rm priv}^{(\rm arm),\max} \approx 0.231$\,Mbps). At $d = 5$\,nm, despite a massive Purcell factor $F_P = 82.4$, Ohmic quenching collapses throughput to $\sim 1.0$\,kbps ($\sim 0.50$\,kbps arm contribution).

\medskip\noindent\textbf{Computational Validation and Topical Relevance.}
Our electrodynamic channel partitioning is benchmarked across four independent methodologies: semi-analytical Sommerfeld Green-tensor integration, 3D conformal FDTD, surface-integral BEM, and FEEM waveguide calculations, yielding a maximum cross-solver discrepancy of $1.04\%$ across $d \ge 5$\,nm ($\le 0.91\%$ for $d \le 50$\,nm) and confirming cross-geometry numerical consistency on dielectric-loaded waveguides within $<3\%$.

This study directly addresses core topics of \textit{Plasmonics}---spontaneous-emission engineering, SPP excitation, nonradiative quenching, and computational Maxwell solvers---while providing a practical design principle for information-aware plasmonic quantum device optimization.

\medskip\noindent\textbf{Declarations.}
The manuscript has been approved by all authors and is not under consideration elsewhere. Comprehensive mathematical derivations and numerical convergence tests are included in the accompanying Supplementary Information.

We thank you and the Editorial Board for your time and consideration.

\bigskip
\noindent Sincerely yours,

\medskip
\noindent
\textbf{Priyanka} (University of Delhi) \quad and \quad \textbf{Ram Soorat}$^*$ (Woxsen University, Corresponding Author)\\
Email: \href{mailto:ram.soorat@woxsen.edu.in}{ram.soorat@woxsen.edu.in}

\end{document}
"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(streamlined_letter)
    print("Streamlined cover_letter.tex successfully!")

if __name__ == "__main__":
    update_manuscript()
    update_supplementary()
    update_cover_letter()
    print("Final pass applied successfully!")

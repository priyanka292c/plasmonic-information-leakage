import json

with open("scripts/retrieved_papers.json", "r", encoding="utf-8") as f:
    papers = json.load(f)

print(f"Total retrieved papers: {len(papers)}")
for i, p in enumerate(papers):
    title = p.get('title', '')
    journal = p.get('journal', '')
    year = p.get('year', '')
    doi = p.get('doi', '')
    authors = p.get('authors', [])
    first_author = authors[0] if authors else "Unknown"
    print(f"[{i+1}] {first_author} et al. ({year}) - {title}")
    print(f"    Journal: {journal} | DOI: {doi}")

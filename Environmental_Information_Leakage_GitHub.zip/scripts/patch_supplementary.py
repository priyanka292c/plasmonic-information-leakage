import os

path = "scripts/write_supplementary.py"
with open(path, "r", encoding="utf-8") as f:
    text = f.read()

# 1. Update S3 mesh description in text and table
text = text.replace(
    r"$0.25$ & $24.20$ & $0.83\%$ & $0.069$ & Fully converged (production) \\",
    r"$0.25$ & $24.20$ & $0.83\%$ & $0.069$ & Production mesh (sub-1\% numerical difference) \\"
)

text = text.replace(
    r"At $\Delta x = 0.25$\,nm, the numerical discrepancy is below $0.9\%$, confirming asymptotic convergence.",
    r"The $\Delta x = 0.25$\,nm mesh serves as our production mesh with sub-1\% numerical difference ($0.83\%$ error relative to the analytical Sommerfeld integration), balancing high numerical precision with computational feasibility, while a finer $0.20$\,nm mesh confirms asymptotic leveling at $0.67\%$."
)

# 2. Update S5 FEEM section to clarify modal quantities and cross-geometry consistency
old_feem_ending = r"""The modal branching ratio $\Xi_{\rm wg} = \Gamma_{\rm rad}^{(\rm wg)} / \Gamma_{\rm nr}^{(\rm wg)}$ was evaluated for ridge widths $w = 300, 500, 700$\,nm without reference to $\Phi(\Xi)$. As shown in main-text Fig.~4, the resulting points agree with $\Phi(\Xi)$ within $<3\%$ relative discrepancy."""

new_feem_ending = r"""The modal branching ratio $\Xi_{\rm wg} = \Gamma_{\rm rad}^{(\rm wg)} / \Gamma_{\rm nr}^{(\rm wg)}$ was evaluated for ridge widths $w = 300, 500, 700$\,nm without reference to $\Phi(\Xi)$. As shown in main-text Fig.~4, the resulting points agree with $\Phi(\Xi)$ within $<3\%$ relative discrepancy.

\subsection{Interpretation as a Cross-Geometry Numerical Consistency Test}
We emphasize that $\Gamma_{\rm rad}^{(\rm wg)}$ and $\Gamma_{\rm nr}^{(\rm wg)}$ are waveguide modal propagation metrics characterizing spatial attenuation and leakage of a guided mode along the structure, rather than the localized spontaneous-decay rates of a point quantum dipole. Consequently, the FEEM calculation is not an experimental or universal proof that localized dipole emission and propagating modes are physically identical. Instead, it serves as an out-of-sample cross-geometry numerical consistency test of the branching-ratio parameterization $\Xi$. It demonstrates that when an effective loss parameter $\Xi$ is constructed from electrodynamic modal loss ratios in an independent guided nanophotonic geometry, evaluating the channel model $\Phi(\Xi)$ yields values consistent with the master curve within $<3\%$, confirming the mathematical consistency and portability of the branching-ratio mapping across disparate computational nanophotonic formulations."""

text = text.replace(old_feem_ending, new_feem_ending)

# 3. Update S6 with dual-rail branching probability clarification
old_isometry = r"""The isometry condition $V^\dagger V = \mathbb{I}_{\rm opt}$ holds identically:"""

new_isometry = r"""\subsection{Dual-Rail Architecture Branching Probability and Rate Definitions}
In the balanced dual-rail spatial architecture, single photons prepared by the 50:50 coupler enter Path~0 (reference arm) with probability $p_0 = 1/2$ and Path~1 (plasmonic arm) with probability $p_1 = 1/2$. We explicitly distinguish:
\begin{enumerate}
    \item The \textbf{plasmonic channel throughput} $R_{\rm priv}^{(\rm ch)}(d) \equiv \frac{\eta_{\rm det}}{k_{\rm rep}} \Gamma_{\rm rad}(d) H_{\min}(X|E; d)$, which measures the private entropy generation rate per photon traversing the plasmonic channel (equivalent to full occupation $p_1 = 1$).
    \item The \textbf{net plasmonic-arm contribution throughput} $R_{\rm priv}^{(\rm arm)}(d) \equiv p_1 R_{\rm priv}^{(\rm ch)}(d) = \frac{\eta_{\rm det}}{2 k_{\rm rep}} \Gamma_{\rm rad}(d) H_{\min}(X|E; d)$, which accounts for the $p_1 = 1/2$ occupation fraction of Path~1 in the interferometer.
    \item The \textbf{post-selected private generation rate} $R_{\rm priv}^{(\rm det)}(d) \equiv \frac{\eta_{\rm det}}{2 k_{\rm rep}} \Gamma_{\rm rad}(d) \log_2(1 + \eta_B(d))$.
\end{enumerate}
Crucially, because $p_1 = 1/2$ is a constant prefactor, the normalized relative throughput:
\begin{equation}
\frac{R_{\rm priv}^{(\rm arm)}(d)}{R_0^{(\rm arm)}} = \frac{R_{\rm priv}^{(\rm ch)}(d)}{R_0} = \frac{\Gamma_{\rm rad}(d)}{\Gamma_0} \Phi(\Xi(d))
\end{equation}
is identically independent of whether the channel throughput or arm-weighted throughput is considered, leaving the optimal distance $d^*$, Purcell factor $F_P^*$, and relative near-field collapse unchanged.

\subsection{Isometry and Joint Post-Channel State}
The isometry condition $V^\dagger V = \mathbb{I}_{\rm opt}$ holds identically:"""

text = text.replace(old_isometry, new_isometry)

# 4. Update S9 Platform Table
old_s9_table = r"""\begin{table}[h!]
\centering
\small
\setlength{\tabcolsep}{4pt}
\caption{\textbf{Projected private-randomness capacities for experimental solid-state quantum emitter architectures.}}
\label{tab:s_platforms}
\vspace{0.5em}
\begin{tabular}{lcccccc}
\toprule
\textbf{Emitter Architecture} & \textbf{$\lambda_0$ (nm)} & \textbf{$\tau_0$ (ns)} & \textbf{$F_P^*$} & \textbf{$d^*$ (nm)} & \textbf{$H_{\min}^*$ (bits)} & \textbf{$R_{\rm priv}^{\max}$ (Mbps)} \\
\midrule
Silicon-Vacancy (SiV$^-$) in Diamond & $738$ & $1.1$ & $3.6$ & $14.2$ & $0.41$ & $\approx 210.5$ \\
Nitrogen-Vacancy (NV$^-$) in Diamond & $637$ & $11.6$ & $3.8$ & $15.1$ & $0.38$ & $\approx 45.2$ \\
Single DBATT Molecule in p-terphenyl & $618$ & $9.5$ & $3.5$ & $16.0$ & $0.39$ & $\approx 60.1$ \\
Colloidal CdSe/ZnS Core-Shell QD & $650$ & $20.0$ & $3.4$ & $17.5$ & $0.39$ & $\approx 28.1$ \\
\bottomrule
\end{tabular}
\end{table}"""

new_s9_table = r"""\begin{table}[h!]
\centering
\small
\setlength{\tabcolsep}{3.5pt}
\caption{\textbf{Model-predicted private-randomness throughput projections for representative solid-state quantum emitter architectures.} Theoretical model projections evaluated at platform-matched clocks ($k_{\rm rep} = 5$, $\eta_{\rm det} = 0.85$); values represent upper-bound theoretical ceilings under assumed single-dipole orientation and ideal host environments rather than experimental QRNG demonstrations. Both channel throughput $R_{\rm priv}^{(\rm ch),\max}$ and net dual-rail arm contribution $R_{\rm priv}^{(\rm arm),\max} = \frac{1}{2} R_{\rm priv}^{(\rm ch),\max}$ are reported.}
\label{tab:s_platforms}
\vspace{0.5em}
\begin{tabular}{lccccccc}
\toprule
\textbf{Emitter Architecture} & \textbf{$\lambda_0$ (nm)} & \textbf{$\tau_0$ (ns)} & \textbf{$F_P^*$} & \textbf{$d^*$ (nm)} & \textbf{$H_{\min}^*$ (bits)} & \textbf{$R_{\rm priv}^{(\rm ch),\max}$ (Mbps)} & \textbf{$R_{\rm priv}^{(\rm arm),\max}$ (Mbps)} \\
\midrule
Silicon-Vacancy (SiV$^-$) in Diamond & $738$ & $1.1$ & $3.6$ & $14.2$ & $0.41$ & $\approx 210.5$ & $\approx 105.3$ \\
Nitrogen-Vacancy (NV$^-$) in Diamond & $637$ & $11.6$ & $3.8$ & $15.1$ & $0.38$ & $\approx 45.2$ & $\approx 22.6$ \\
Single DBATT Molecule in p-terphenyl & $618$ & $9.5$ & $3.5$ & $16.0$ & $0.39$ & $\approx 60.1$ & $\approx 30.1$ \\
Colloidal CdSe/ZnS Core-Shell QD & $650$ & $20.0$ & $3.4$ & $17.5$ & $0.39$ & $\approx 28.1$ & $\approx 14.1$ \\
\bottomrule
\end{tabular}
\end{table}"""

text = text.replace(old_s9_table, new_s9_table)

with open(path, "w", encoding="utf-8") as f:
    f.write(text)

print("Successfully patched write_supplementary.py!")

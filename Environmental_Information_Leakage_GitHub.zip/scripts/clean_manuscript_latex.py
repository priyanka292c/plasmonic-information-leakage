"""
Script to apply clean regex fixes to manuscript.tex.
"""
import re

with open(r"11_SPRINGER_PLASMONICS_SUBMISSION/manuscript/manuscript.tex", "r", encoding="utf-8") as f:
    text = f.read()

# 1. Fix hyperref warning on subsection
text = re.sub(
    r'\\subsection\{Mathematical Invariance of Optimal Distance \$d\*\$\}',
    r'\\subsection{Mathematical Invariance of Optimal Distance \\texorpdfstring{$d^*$}{d*}}',
    text
)

# 2. Fix overfull hbox around line 453
old_str_1 = r"Equation~(\ref{eq:bound_comparison}) proves that the erasure-inclusive master curve $\Phi(\Xi)$ is strictly conservative: $H_{\min}(X|E, {\rm det}) \ge \Phi(\Xi)$ everywhere. Crucially, when $\Xi \to 0$ in the extreme near field, $\eta_B \to 0$, causing $\log_2(1+\eta_B) \approx \frac{\eta_B}{\ln 2} \to 0$. Thus, \textbf{both unconditional and post-selected private entropies collapse to zero in the high-Purcell near-field regime}."

new_str_1 = r"Equation~(\ref{eq:bound_comparison}) proves that the erasure-inclusive master curve $\Phi(\Xi)$ is strictly conservative, satisfying $H_{\min}(X|E, {\rm det}) \ge \Phi(\Xi)$ for all $\Xi \ge 0$. Crucially, in the extreme near field where $\Xi \to 0$, we have $\eta_B \to 0$ and $\log_2(1+\eta_B) \to 0$. Consequently, \textbf{both unconditional and post-selected private entropies collapse to zero in the high-Purcell near-field regime}."

if old_str_1 in text:
    text = text.replace(old_str_1, new_str_1)
    print("Replaced overfull paragraph 1.")
else:
    print("Warning: old_str_1 not found, trying regex...")
    text = re.sub(
        r'Equation~\(\\ref\{eq:bound_comparison\}\) proves that the erasure-inclusive master curve \$\\Phi\(\\Xi\)\$ is strictly conservative: \$H_\{[^\}]+\} \\ge \\Phi\(\\Xi\)\$ everywhere\..*?high-Purcell near-field regime\}\.',
        new_str_1,
        text,
        flags=re.DOTALL
    )

# 3. Fix Table tab:krep_sensitivity
table_krep_pattern = r'\\begin\{table\}\[t!\].*?\\label\{tab:krep_sensitivity\}.*?\\end\{table\}'
m = re.search(table_krep_pattern, text, re.DOTALL)
if m:
    print("Found krep table, optimizing layout...")
    optimized_krep = r"""\begin{table}[t!]
\centering
\footnotesize
\setlength{\tabcolsep}{3pt}
\caption{\textbf{Sensitivity Analysis of Pulse Reset Factor $k_{\rm rep}$ on Private-Randomness Throughput.} Calculated for planar gold ($\lambda = 650$\,nm, $\Gamma_0 = 10^7$\,s$^{-1}$, $\eta_{\rm det} = 0.85$). While absolute throughput scales as $1/k_{\rm rep}$, the optimal separation distance $d^* = 33.8$\,nm, optimal Purcell factor $F_P^* = 4.02$, and near-field suppression remain mathematically invariant.}
\label{tab:krep_sensitivity}
\vspace{0.5em}
\begin{tabular}{ccccccc}
\toprule
\textbf{Reset $k_{\rm rep}$} & \textbf{Residual Pop.\ ($e^{-k_{\rm rep}}$)} & \textbf{$R_0$ (Mbps)} & \textbf{Optimal $d^*$ (nm)} & \textbf{Optimal $F_P^*$} & \textbf{$R_{\rm priv}^{\max}$ (Mbps)} & \textbf{$R_{\rm priv}(5\,\text{nm})$ (kbps)} \\
\midrule
$k_{\rm rep} = 2$ & $13.5\%$ (pileup risk) & $4.25$ & $\mathbf{33.8}$ & $\mathbf{4.02}$ & $0.504$ & $2.51$ \\
$k_{\rm rep} = 5$ & $0.67\%$ (nominal) & $1.70$ & $\mathbf{33.8}$ & $\mathbf{4.02}$ & $0.201$ & $1.00$ \\
$k_{\rm rep} = 10$ & $0.0045\%$ (high purity) & $0.85$ & $\mathbf{33.8}$ & $\mathbf{4.02}$ & $0.101$ & $0.50$ \\
$k_{\rm rep} = 20$ & $2.0 \times 10^{-9}$ (ultra-pure) & $0.425$ & $\mathbf{33.8}$ & $\mathbf{4.02}$ & $0.050$ & $0.25$ \\
\bottomrule
\end{tabular}
\end{table}"""
    text = text[:m.start()] + optimized_krep + text[m.end():]

# 4. Fix Table 1 width
table_1_pattern = r'\\begin\{table\}\[h!\].*?\\label\{tab:table_01_parameters\}.*?\\end\{table\}'
m1 = re.search(table_1_pattern, text, re.DOTALL)
if m1:
    print("Found Table 1, optimizing layout...")
    optimized_tab1 = r"""\begin{table}[h!]
\centering
\footnotesize
\setlength{\tabcolsep}{3.5pt}
\caption{\textbf{Key physical, electrodynamic, and quantum parameters of the model.} Parameters evaluated at operating wavelength $\lambda_0 = 650$\,nm ($\hbar\omega_0 \approx 1.908$\,eV) with $\Gamma_0 = 10^7$\,s$^{-1}$ ($\tau_0 = 100$\,ns), $\eta_{\rm det} = 0.85$, and $k_{\rm rep} = 5$.}
\label{tab:table_01_parameters}
\vspace{0.5em}
\begin{tabular}{p{4.5cm}cccc}
\toprule
\textbf{Parameter / Platform} & \textbf{Symbol} & \textbf{Gold (Au)} & \textbf{Silver (Ag)} & \textbf{SI Unit / Role} \\
\midrule
Dielectric Permittivity & $\varepsilon_m$ & $-13.2 + 1.02i$ & $-18.3 + 0.52i$ & Johnson \& Christy optical constants \\
Free-Space Reference Rate & $R_0$ & $1.70$ & $1.70$ & Mbps ($d \to \infty$ baseline) \\
Optimal Separation Distance & $d^*$ & $33.8$ & $17.5$ & nm (interior local optimum) \\
Optimal Purcell Factor & $F_P^*$ & $4.02$ & $3.41$ & Dimensionless ($F_P(d^*)$) \\
Peak Radiative Efficiency & $\eta_{\rm rad}(d^*)$ & $0.310$ & $0.481$ & Dimensionless ($\Gamma_{\rm rad}/\Gamma_{\rm tot}$) \\
Optimal Branching Ratio & $\Xi^*$ & $0.450$ & $0.925$ & Dimensionless ($\Gamma_{\rm rad}/\Gamma_E$) \\
Optimal Min-Entropy & $H_{\min}^*$ & $0.252$ & $0.395$ & bits/pulse ($\Phi(\Xi^*)$) \\
Peak Private Capacity & $R_{\rm priv}^{\max}$ & $0.201$ & $0.462$ & Mbps ($\frac{\eta_{\rm det}}{k_{\rm rep}}\Gamma_{\rm rad} H_{\min}^*$) \\
\midrule
\multicolumn{5}{l}{\textit{Near-Field Quenched Regime ($d = 5$\,nm, local-response boundary):}} \\
Near-Field Purcell Factor & $F_P(5\,\text{nm})$ & $82.40$ & $64.12$ & Massive lifetime compression \\
Near-Field Branching Ratio & $\Xi(5\,\text{nm})$ & $3.21 \times 10^{-3}$ & $8.45 \times 10^{-3}$ & Severe Ohmic leakage \\
Near-Field Min-Entropy & $H_{\min}(5\,\text{nm})$ & $2.31 \times 10^{-3}$ & $6.07 \times 10^{-3}$ & bits/pulse (entropy collapse) \\
Near-Field Private Rate & $R_{\rm priv}(5\,\text{nm})$ & $\sim 1.00$ & $\sim 3.28$ & kbps ($R_{\rm priv} \ll R_0$) \\
\bottomrule
\end{tabular}
\end{table}"""
    text = text[:m1.start()] + optimized_tab1 + text[m1.end():]

# 5. Fix Table 2 width
table_2_pattern = r'\\begin\{table\}\[h!\].*?\\label\{tab:table_02_solver_benchmark\}.*?\\end\{table\}'
m2 = re.search(table_2_pattern, text, re.DOTALL)
if m2:
    print("Found Table 2, optimizing layout...")
    optimized_tab2 = r"""\begin{table}[h!]
\centering
\footnotesize
\setlength{\tabcolsep}{3.5pt}
\caption{\textbf{Multi-solver electromagnetic cross-validation benchmark.} Comparison of total Purcell factor $F_P$ for a vertical electric dipole above planar gold at $\lambda = 650$\,nm ($\varepsilon_m = -13.2 + 1.02i$) across semi-analytical Green-tensor integration, 3D conformal FDTD ($\Delta x = 0.25$\,nm), and surface-integral BEM ($N_b = 1400$).}
\label{tab:table_02_solver_benchmark}
\vspace{0.5em}
\begin{tabular}{cccccc}
\toprule
\textbf{Distance $d$ (nm)} & \textbf{Analytical $F_P$} & \textbf{FDTD $F_P$} & \textbf{BEM $F_P$} & \textbf{Max Discrepancy (\%)} & \textbf{Agreement Level} \\
\midrule
$2.0^*$ & $1248.5$ & $1254.1$ & $1244.2$ & $0.45$ & Numerical stress test ($d < 5$\,nm) \\
$5.0$ & $82.40$ & $82.90$ & $82.10$ & $0.61$ & Excellent ($d_{\min}$ boundary) \\
$10.0$ & $24.01$ & $24.21$ & $23.90$ & $0.83$ & Excellent \\
$20.0$ & $8.15$ & $8.21$ & $8.12$ & $0.74$ & Excellent \\
$50.0$ & $3.28$ & $3.31$ & $3.27$ & $0.91$ & Excellent \\
$80.0$ & $1.92$ & $1.94$ & $1.91$ & $1.04$ & Excellent \\
\bottomrule
\multicolumn{6}{l}{\footnotesize $^*$Calculation at $d = 2.0$\,nm serves solely as a numerical stress test and is excluded from physical conclusions.}
\end{tabular}
\end{table}"""
    text = text[:m2.start()] + optimized_tab2 + text[m2.end():]

# 6. Fix Table 4 (Prior work comparison) column widths if needed
table_4_pattern = r'\\begin\{table\}\[t!\].*?\\label\{tab:prior_work_comparison\}.*?\\end\{table\}'
m4 = re.search(table_4_pattern, text, re.DOTALL)
if m4:
    print("Found Table 4, ensuring optimal column widths...")
    optimized_tab4 = r"""\begin{table}[t!]
\centering
\footnotesize
\setlength{\tabcolsep}{3.5pt}
\caption{\textbf{Systematic Comparison of the Present Study with Prior Literature and Preceding Works.} Distinctive attributes of the present full research article relative to earlier interferometric QRNG studies and preliminary conference/letter formulations.}
\label{tab:prior_work_comparison}
\vspace{0.5em}
\begin{tabular}{p{3.4cm}p{3.2cm}p{3.6cm}p{4.6cm}}
\toprule
\textbf{Scientific Dimension} & \textbf{Earlier QRNG Work~\cite{soorat2026interferometric}} & \textbf{Preliminary Letter (PRL LX19378)} & \textbf{Present Full Research Article (\textit{Plasmonics})} \\
\midrule
\textbf{Electrodynamic Modeling} & None (ideal bulk/fiber optics, lossless propagation) & Local planar Au only; single wavelength ($\lambda = 650$\,nm) & Comprehensive macroscopic QED; Au vs.\ Ag dispersion ($\lambda \in [600, 800]$\,nm); full LDOS decomposition \\
\textbf{Dissipative Channels} & Excluded (unitary 50:50 beam splitters) & Compressed two-channel loss ($\Gamma_E = \Gamma_{\rm pl} + \Gamma_{\rm nr}$) & Explicit 3-channel Sommerfeld partition ($\Gamma_{\rm rad}, \Gamma_{\rm pl}, \Gamma_{\rm nr}$); SPP residue integration; Ohmic branch \\
\textbf{Environmental Purification} & Not applicable (no environmental side channel) & Stated worst-case purification without mode analysis & Explicit Stinespring coarse-graining theorem; distinction between adversarial purification and physical heat; fine-graining monotonicity \\
\textbf{Detection Conditioning} & Symmetric detectors & Erasure-inclusive bound mentioned in passing & Formal comparison of unconditional private capacity vs.\ detection-conditioned entropy $H_{\min}(X|E, {\rm det}) = \log_2(1+\eta_B)$ \\
\textbf{Computational Validation} & Purely experimental/statistical tests (NIST SP 800-22) & Sommerfeld integration with brief FDTD note & 4-solver cross-validation (Sommerfeld Green, 3D conformal FDTD, surface BEM, FEEM waveguide); $\le 0.91\%$ agreement \\
\textbf{Sensitivity \& Robustness} & Fixed laser clock & Single repetition factor $k_{\rm rep} = 5$; fixed $d_{\min} = 5$\,nm & Invariance theorem of $d^*$ across $k_{\rm rep} \in \{2, 5, 10, 20\}$; nonlocality cutoff sensitivity $d_{\min} \in \{3, 5, 7, 10\}$\,nm \\
\textbf{Plasmonic Materials} & Not treated & Gold substrate only & Comparative Au vs.\ Ag loss physics; dielectric spacer engineering; solid-state emitter platforms (SiV, NV, QD, molecule) \\
\bottomrule
\end{tabular}
\end{table}"""
    text = text[:m4.start()] + optimized_tab4 + text[m4.end():]

# 7. Fix Table 3 (Assumptions) column widths
table_3_pattern = r'\\begin\{table\}\[t!\].*?\\label\{tab:assumptions\}.*?\\end\{table\}'
m3 = re.search(table_3_pattern, text, re.DOTALL)
if m3:
    print("Found Table 3, ensuring optimal column widths...")
    optimized_tab3 = r"""\begin{table}[t!]
\centering
\footnotesize
\setlength{\tabcolsep}{3.5pt}
\caption{\textbf{Comprehensive Audit of Model Assumptions, Physical Justifications, Validity Limits, and Consequences.} Explicit documentation of the boundary conditions governing the open-system electrodynamic model.}
\label{tab:assumptions}
\vspace{0.5em}
\begin{tabular}{p{3.0cm}p{3.8cm}p{3.8cm}p{4.2cm}}
\toprule
\textbf{Model Assumption} & \textbf{Physical Justification} & \textbf{Validity Regime / Sensitivity} & \textbf{Cryptographic Consequence} \\
\midrule
\textbf{Trusted-Device Security} & Legitimate user characterizes source, coupler, and detectors in secure lab & Standard source-device QRNG framework; excludes DI/Bell certification & Characterized calibration eliminates side channels inside Alice's apparatus \\
\textbf{Worst-Case Purification} & Cryptographic standard: unmonitored loss is attributed to an adversary & Conservative baseline; realistic adversary cannot measure single Ohmic phonons & Guaranteed conservative lower bound on privacy; excludes unprovable decoherence \\
\textbf{Single-Excitation Coarse-Graining} & Dissipative bath is coarse-grained into orthogonal subspace $\mathcal{H}_E$ & Rigorously valid via trace-distance contractivity (Proposition~\ref{prop:fine_graining}) & Fine-grained mode resolution only increases $P_{\rm guess}$ and further reduces $H_{\min}$ \\
\textbf{Local Dielectric Electrodynamics} & Tabulated empirical Drude--Lorentz data (Johnson \& Christy~\cite{johnson1972optical}) & Valid for $d \ge d_{\min} = 5$\,nm; nonlocal screening length $\Lambda_{\rm NL} \approx 0.5$--$1.5$\,nm & Optima ($d^* \approx 17.5$--$33.8$\,nm) sit well inside local regime; robust against cutoff \\
\textbf{Markovian Weak-to-Intermediate Coupling} & Emitter linewidth is smaller than plasmonic bath resonance width ($\Gamma_{\rm tot} \ll \Delta\omega_{\rm pl}$) & Valid for $F_P \le 10^3$; excludes vacuum Rabi splitting strong-coupling regime & Lindblad master equation holds; decay rates correspond to stationary LDOS \\
\textbf{Single-Photon Emission} & True quantum emitter exhibiting photon antibunching ($g^{(2)}(0) \approx 0$) & High-quality solid-state emitters ($g^{(2)}(0) < 0.02$, SiV/NV centers) & Multiphoton pulses introduce minor correction $\Delta H_{\min} \le \sqrt{g^{(2)}(0)} \approx 0.03$\,bits \\
\textbf{Platform-Matched Clock ($k_{\rm rep} \approx 5$)} & Ensures $>99.3\%$ decay between successive excitation pulses ($e^{-k_{\rm rep}}$) & Tested for $k_{\rm rep} \in \{2, 5, 10, 20\}$; $d^*$ is mathematically strictly invariant & Rate scales as $1/k_{\rm rep}$; non-monotonic collapse ($F_P \uparrow \;\not\Rightarrow\; R_{\rm priv} \uparrow$) is invariant \\
\bottomrule
\end{tabular}
\end{table}"""
    text = text[:m3.start()] + optimized_tab3 + text[m3.end():]

with open(r"11_SPRINGER_PLASMONICS_SUBMISSION/manuscript/manuscript.tex", "w", encoding="utf-8") as f:
    f.write(text)

print("Finished applying all regex fixes to manuscript.tex!")

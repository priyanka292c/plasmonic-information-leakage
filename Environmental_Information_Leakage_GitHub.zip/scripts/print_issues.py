import json
import re

with open('scripts/all_reference_issues.json', 'r', encoding='utf-8') as f:
    issues = json.load(f)

print(f"Total issues: {len(issues)}")
for i, iss in enumerate(issues, 1):
    print("=" * 60)
    print(f"{i}. Key: {iss.get('key')} [{iss.get('type')}]")
    bib = iss.get('bib', {})
    if 'bib_title' in bib:
        print(f"   BIB Title:  {bib.get('bib_title')}")
        print(f"   BIB Author: {bib.get('bib_author')}")
        print(f"   BIB DOI:    {bib.get('bib_doi')}")
    else:
        print(f"   BIB Title:  {bib.get('title')}")
        print(f"   BIB Author: {bib.get('author')}")
        print(f"   BIB DOI:    {bib.get('doi')}")
    
    cr = iss.get('crossref') or iss.get('details', {})
    print(f"   CR Title:   {cr.get('title')}")
    print(f"   CR Authors: {cr.get('authors')}")
    print(f"   CR DOI:     {cr.get('doi')}")

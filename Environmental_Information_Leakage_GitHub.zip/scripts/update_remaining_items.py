import os
import re

def update_manuscript():
    path = "scripts/write_manuscript.py"
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()

    replacements = [
        # Intro list item for 4-solver
        (
            r"demonstrating cross-solver numerical agreement within $\le 0.91\%$ discrepancy for planar systems and $<3\%$ for out-of-sample waveguides.",
            r"demonstrating cross-solver numerical agreement with a maximum discrepancy of $1.04\%$ across $d \ge 5$\,nm ($\le 0.91\%$ for $d \le 50$\,nm) and $<3\%$ for out-of-sample guided waveguides."
        ),
        # Fig 10 caption
        (
            r"Across the local-response validity domain ($d \ge 5$\,nm), the maximum deviation is strictly $\le 0.91\%$, proving numerical cross-solver agreement.}",
            r"Across the local-response validity domain ($d \ge 5$\,nm), the maximum deviation is $1.04\%$ (occurring at $d = 80$\,nm, with $\le 0.91\%$ for $d \le 50$\,nm), demonstrating high cross-solver numerical agreement.}"
        ),
        # Section 6 text
        (
            r"the maximum relative discrepancy between FDTD, BEM, and analytical Green-tensor integration remains strictly $\le 0.91\%$ [Fig.~\ref{fig:benchmark}]. Furthermore, the independent FEEM waveguide test confirms cross-geometry consistency with $\Phi(\Xi)$ within $<3\%$ relative discrepancy.",
            r"the maximum relative discrepancy between FDTD, BEM, and analytical Green-tensor integration is $1.04\%$ across the tested $d \ge 5$\,nm range ($\le 0.91\%$ for $d \le 50$\,nm) [Fig.~\ref{fig:benchmark}]. Furthermore, the independent FEEM waveguide test confirms cross-geometry consistency with $\Phi(\Xi)$ within $<3\%$ relative discrepancy."
        ),
        # Section 9 conclusions
        (
            r"confirm cross-solver numerical agreement within $\le 0.91\%$ discrepancy for planar interfaces and $<3\%$ for waveguides.",
            r"confirm cross-solver numerical agreement with a maximum discrepancy of $1.04\%$ across $d \ge 5$\,nm ($\le 0.91\%$ for $d \le 50$\,nm) and $<3\%$ for guided waveguides."
        ),
        (
            r"These findings establish a foundational design principle for open quantum nanophotonics:",
            r"These findings establish a practical design principle for information-aware plasmonic quantum-source optimization:"
        ),
        # Fig 5 caption
        (
            r"\caption{\textbf{Purcell enhancement does not determine private-randomness performance.} Platform-matched private capacity $R_{\rm priv}$ versus \textbf{(a)} Purcell factor $F_P$ and \textbf{(b)} separation distance $d$ for gold (blue solid) and silver (green dashed). Solid stars mark finite-distance local optima ($d^* \approx 33.8$\,nm, $F_P^* \approx 4.0$ for Au; $d^* \approx 17.5$\,nm, $F_P^* \approx 3.4$ for Ag). Dash-dotted line indicates the asymptotic free-space baseline $R_0 \approx 1.70$\,Mbps. Shaded area ($d < 5$\,nm) marks the excluded near-field domain where severe Ohmic quenching collapses private throughput.}",
            r"\caption{\textbf{Private-randomness throughput versus Purcell enhancement and emitter--metal separation.} Model-predicted theoretical private throughput $R_{\rm priv}$ versus \textbf{(a)} Purcell factor $F_P$ and \textbf{(b)} separation distance $d$ for gold (blue solid curve, $d^* \approx 33.8$\,nm, $F_P^* \approx 4.02$, $R_{\rm priv}^{(\rm ch),\max} \approx 0.201$\,Mbps, $R_{\rm priv}^{(\rm arm),\max} \approx 0.101$\,Mbps) and silver (green dashed curve, $d^* \approx 17.5$\,nm, $F_P^* \approx 3.41$, $R_{\rm priv}^{(\rm ch),\max} \approx 0.462$\,Mbps, $R_{\rm priv}^{(\rm arm),\max} \approx 0.231$\,Mbps) at $\lambda = 650$\,nm ($\Gamma_0 = 10^7$\,s$^{-1}$, $\eta_{\rm det} = 0.85$, $k_{\rm rep} = 5$). Solid stars mark the finite-distance local optima. Dash-dotted line indicates the asymptotic free-space baseline $R_0 \approx 1.70$\,Mbps ($R_0^{(\rm arm)} \approx 0.85$\,Mbps). Shaded area ($d < 5$\,nm) marks the near-field domain where severe Ohmic quenching collapses private throughput. Both channel throughput $R_{\rm priv}^{(\rm ch)}$ and net dual-rail arm contribution $R_{\rm priv}^{(\rm arm)}$ scale identically.}"
        ),
        # Emitter platforms in Section 7
        (
            r"With $\tau_0 \approx 11.6$\,ns~\cite{aharonovich2016solid,martirez2026optical}, NV$^-$ centers at $d^* \approx 15$\,nm achieve $R_{\rm priv}^{\max} \approx 45$\,Mbps.",
            r"With $\tau_0 \approx 11.6$\,ns~\cite{aharonovich2016solid,martirez2026optical}, NV$^-$ centers at $d^* \approx 15$\,nm achieve model-predicted channel throughput $R_{\rm priv}^{(\rm ch),\max} \approx 45$\,Mbps (net dual-rail arm contribution $R_{\rm priv}^{(\rm arm),\max} \approx 22.5$\,Mbps)."
        ),
        (
            r"\item \textbf{Single Organic Molecules (DBATT in p-terphenyl):} Short lifetime ($\tau_0 \approx 9.5$\,ns) yields $R_{\rm priv}^{\max} \approx 60$\,Mbps at $d^* \approx 16$\,nm.",
            r"\item \textbf{Single Organic Molecules (DBATT in p-terphenyl):} Short lifetime ($\tau_0 \approx 9.5$\,ns) yields model-predicted channel throughput $R_{\rm priv}^{(\rm ch),\max} \approx 60$\,Mbps ($R_{\rm priv}^{(\rm arm),\max} \approx 30$\,Mbps) at $d^* \approx 16$\,nm."
        ),
        (
            r"\item \textbf{Colloidal CdSe/ZnS Quantum Dots:} Longer lifetime ($\tau_0 \approx 20$\,ns) yields $R_{\rm priv}^{\max} \approx 28$\,Mbps at $d^* \approx 18$\,nm.",
            r"\item \textbf{Colloidal CdSe/ZnS Quantum Dots:} Longer lifetime ($\tau_0 \approx 20$\,ns) yields model-predicted channel throughput $R_{\rm priv}^{(\rm ch),\max} \approx 28$\,Mbps ($R_{\rm priv}^{(\rm arm),\max} \approx 14$\,Mbps) at $d^* \approx 18$\,nm.\n    We emphasize that these numbers represent model-predicted theoretical throughput projections under assumed single-dipole orientation and ideal host environments rather than experimental QRNG device demonstrations."
        ),
        # Soften 'prove' in Section 5
        (
            r"our results prove that it is counterproductive for quantum hardware",
            r"our results demonstrate within the open-system channel model that it is counterproductive for quantum hardware"
        )
    ]

    applied = 0
    for target, repl in replacements:
        if target in content:
            content = content.replace(target, repl)
            applied += 1
        else:
            print(f"WARNING (manuscript): Target not found: {target[:60]}...")

    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

    print(f"Successfully applied {applied} additional replacements in write_manuscript.py")

def update_supplementary():
    path = "scripts/write_supplementary.py"
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()

    replacements = [
        # S3 mesh sentence
        (
            r"At $\Delta x = 0.25$\,nm, the numerical discrepancy is below $0.9\%$, confirming asymptotic convergence.",
            r"The $\Delta x = 0.25$\,nm mesh serves as our production mesh with sub-1\% numerical difference ($0.83\%$ error relative to the analytical Sommerfeld integration), balancing high numerical precision with computational feasibility, while a finer $0.20$\,nm mesh confirms asymptotic leveling at $0.67\%$."
        ),
        # S9 Platform table caption & columns
        (
            r"\caption{\textbf{Projected private-randomness capacities for experimental solid-state quantum emitter architectures.}}",
            r"\caption{\textbf{Model-predicted private-randomness throughput projections for representative solid-state quantum emitter architectures.} Theoretical model projections evaluated at platform-matched clocks ($k_{\rm rep} = 5$, $\eta_{\rm det} = 0.85$); values represent upper-bound theoretical ceilings under assumed single-dipole orientation and ideal host environments rather than experimental QRNG demonstrations. Both channel throughput $R_{\rm priv}^{(\rm ch),\max}$ and net dual-rail arm contribution $R_{\rm priv}^{(\rm arm),\max} = \frac{1}{2} R_{\rm priv}^{(\rm ch),\max}$ are reported.}"
        ),
        (
            r"\begin{tabular}{lcccccc}" + "\n" + r"\toprule" + "\n" + r"\textbf{Emitter Architecture} & \textbf{$\lambda_0$ (nm)} & \textbf{$\tau_0$ (ns)} & \textbf{$F_P^*$} & \textbf{$d^*$ (nm)} & \textbf{$H_{\min}^*$ (bits)} & \textbf{$R_{\rm priv}^{\max}$ (Mbps)} \\" + "\n" + r"\midrule" + "\n" + r"Silicon-Vacancy (SiV$^-$) in Diamond & $738$ & $1.1$ & $3.6$ & $14.2$ & $0.41$ & $\approx 210.5$ \\" + "\n" + r"Nitrogen-Vacancy (NV$^-$) in Diamond & $637$ & $11.6$ & $4.1$ & $33.5$ & $0.39$ & $\approx 45.2$ \\" + "\n" + r"Organic Molecule (DBATT) & $600$ & $9.5$ & $3.8$ & $16.1$ & $0.42$ & $\approx 59.8$ \\" + "\n" + r"Colloidal Quantum Dot (CdSe/ZnS) & $650$ & $20.0$ & $3.4$ & $17.5$ & $0.44$ & $\approx 28.4$ \\" + "\n" + r"\bottomrule",
            r"\begin{tabular}{lccccccc}" + "\n" + r"\toprule" + "\n" + r"\textbf{Emitter Architecture} & \textbf{$\lambda_0$ (nm)} & \textbf{$\tau_0$ (ns)} & \textbf{$F_P^*$} & \textbf{$d^*$ (nm)} & \textbf{$H_{\min}^*$ (bits)} & \textbf{$R_{\rm priv}^{(\rm ch),\max}$ (Mbps)} & \textbf{$R_{\rm priv}^{(\rm arm),\max}$ (Mbps)} \\" + "\n" + r"\midrule" + "\n" + r"Silicon-Vacancy (SiV$^-$) in Diamond & $738$ & $1.1$ & $3.6$ & $14.2$ & $0.41$ & $\approx 210.5$ & $\approx 105.3$ \\" + "\n" + r"Nitrogen-Vacancy (NV$^-$) in Diamond & $637$ & $11.6$ & $4.1$ & $33.5$ & $0.39$ & $\approx 45.2$ & $\approx 22.6$ \\" + "\n" + r"Organic Molecule (DBATT) & $600$ & $9.5$ & $3.8$ & $16.1$ & $0.42$ & $\approx 59.8$ & $\approx 29.9$ \\" + "\n" + r"Colloidal Quantum Dot (CdSe/ZnS) & $650$ & $20.0$ & $3.4$ & $17.5$ & $0.44$ & $\approx 28.4$ & $\approx 14.2$ \\" + "\n" + r"\bottomrule"
        )
    ]

    applied = 0
    for target, repl in replacements:
        if target in content:
            content = content.replace(target, repl)
            applied += 1
        else:
            print(f"WARNING (SI): Target not found: {target[:60]}...")

    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

    print(f"Successfully applied {applied} additional replacements in write_supplementary.py")

if __name__ == "__main__":
    update_manuscript()
    update_supplementary()
    print("Done!")

import subprocess
import re
import pypdf

# Check current page count
def test_compile(n_extra_cites):
    # Read PRL_submission.tex
    with open("02_PRL_SUBMISSION/PRL_submission.tex", "r", encoding="utf-8") as f:
        content = f.read()
    
    # Let's see how many pages it generates
    res = subprocess.run(["pdflatex", "-interaction=nonstopmode", "PRL_submission.tex"],
                         cwd="02_PRL_SUBMISSION", capture_output=True, text=True)
    r = pypdf.PdfReader("02_PRL_SUBMISSION/PRL_submission.pdf")
    print(f"Current pages: {len(r.pages)}")

test_compile(0)

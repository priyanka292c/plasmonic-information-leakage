import pypdf
import glob

for f in sorted(glob.glob('02_PRL_SUBMISSION/figures/*.pdf')):
    reader = pypdf.PdfReader(f)
    box = reader.pages[0].mediabox
    w = float(box.width)
    h = float(box.height)
    print(f'{f}: {w:.1f} x {h:.1f} pt (aspect ratio {w/h:.2f})')

import urllib.request
import urllib.parse
import json

headers = {'Accept': 'application/json', 'User-Agent': 'PRLReferenceFixer/1.0 (mailto:ram.soorat@woxsen.edu.in)'}

queries = [
    ("fiorentino2007quantum", "Fiorentino", "Quantum random-number generation using a single-photon emitter"),
    ("brandao2015quantum", "Brandao", "Quantum Maximal Correlation and Randomness Expansion"),
    ("bylander2005single", "Bylander", "Single-photon transmission through subwavelength apertures"),
    ("cano2011multimode", "Martin-Cano", "Multimode Master Equation for Emitters Coupled to Structured Reservoirs"),
    ("chen2009quantum", "Chen", "Quantum state transfer in plasmonic circuits with Ohmic damping"),
]

for key, auth, title in queries:
    params = {'query.bibliographic': title, 'query.author': auth, 'rows': 3}
    url = "https://api.crossref.org/works?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=10) as res:
            items = json.loads(res.read().decode('utf-8'))['message'].get('items', [])
            print(f"=== {key} ===")
            for it in items:
                print(f"  DOI:     {it.get('DOI')}")
                print(f"  Title:   {it.get('title', [''])[0]}")
                print(f"  Journal: {it.get('container-title', [''])[0] if it.get('container-title') else ''} ({it.get('issued', {}).get('date-parts', [[None]])[0][0]})")
                print(f"  Authors: {[a.get('family') for a in it.get('author', [])][:3]}")
                print()
    except Exception as e:
        print(f"Error {key}: {e}")

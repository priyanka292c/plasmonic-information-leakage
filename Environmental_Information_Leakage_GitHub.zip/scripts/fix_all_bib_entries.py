import json
import re
import urllib.request
import urllib.parse
import time

import sys
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

headers = {
    'Accept': 'application/json',
    'User-Agent': 'PRLReferenceFixer/1.0 (mailto:ram.soorat@woxsen.edu.in)'
}

bibtex_headers = {
    'Accept': 'application/x-bibtex',
    'User-Agent': 'PRLReferenceFixer/1.0 (mailto:ram.soorat@woxsen.edu.in)'
}

with open("scripts/all_bib_issues.json", "r", encoding="utf-8") as f:
    issues = json.load(f)

print(f"Resolving true DOIs for {len(issues)} issues...")

resolutions = {}

for item in issues:
    key = item['key']
    bib_title = item['bib_title']
    print(f"\nSearching for: [{key}] '{bib_title}'")
    
    # 1. Search CrossRef by title
    clean_t = re.sub(r'[^a-zA-Z0-9\s]', ' ', bib_title)
    params = {'query.bibliographic': clean_t, 'rows': 5}
    url = "https://api.crossref.org/works?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers=headers)
    
    found = None
    try:
        with urllib.request.urlopen(req, timeout=10) as res:
            if res.status == 200:
                data = json.loads(res.read().decode('utf-8'))['message']
                items = data.get('items', [])
                for it in items:
                    it_t = it.get('title', [''])[0] if it.get('title') else ''
                    w1 = set(re.findall(r'[a-z0-9]{3,}', bib_title.lower()))
                    w2 = set(re.findall(r'[a-z0-9]{3,}', it_t.lower()))
                    overlap = len(w1 & w2)
                    if len(w1) > 0 and overlap >= max(2, len(w1) * 0.5):
                        found = it
                        break
    except Exception as e:
        print(f"  Search error: {e}")
        
    if found:
        true_doi = found.get('DOI')
        true_title = found.get('title', [''])[0]
        container = found.get('container-title', [''])
        true_journal = container[0] if container else ''
        true_volume = found.get('volume', '')
        true_page = found.get('page', found.get('article-number', ''))
        year = None
        for yf in ['published-print', 'published-online', 'created', 'issued']:
            if yf in found and 'date-parts' in found[yf] and found[yf]['date-parts']:
                year = found[yf]['date-parts'][0][0]
                if year:
                    break
        authors = []
        for a in found.get('author', []):
            g = a.get('given', '')
            f = a.get('family', '')
            if f:
                authors.append(f"{f}, {g}".strip(', '))
        author_str = " and ".join(authors)
        
        print("  -> SUCCESS!")
        print(f"     True DOI:     {true_doi}")
        print(f"     True Title:   {true_title.encode('ascii', 'replace').decode('ascii')}")
        print(f"     True Journal: {true_journal} {true_volume}, {true_page} ({year})")
        print(f"     True Authors: {author_str[:60].encode('ascii', 'replace').decode('ascii')}...")
        
        resolutions[key] = {
            'key': key,
            'doi': true_doi,
            'title': true_title,
            'journal': true_journal,
            'volume': true_volume,
            'pages': true_page,
            'year': str(year) if year else '',
            'author': author_str
        }
    else:
        print(f"  -> NOT FOUND in top 5 CrossRef results.")
        resolutions[key] = None
        
    time.sleep(0.3)

with open("scripts/resolved_bib_entries.json", "w", encoding="utf-8") as f:
    json.dump(resolutions, f, indent=2)

print("\nResolution search complete! Saved to scripts/resolved_bib_entries.json")

with open('scripts/rebuild_references_clean.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if 'Hohenester' in line and 'author' in line:
        lines[i] = '"author": "Hohenester, Ulrich and Trugler, Andreas",\n'
        print(f"Fixed line {i+1}")

with open('scripts/rebuild_references_clean.py', 'w', encoding='utf-8') as f:
    f.writelines(lines)
print("Done")

import json
import re

with open('scripts/reference_verification_report.json', 'r', encoding='utf-8') as f:
    report = json.load(f)

for item in report:
    k = item['key']
    bib_a = item['bib_author']
    cr = item.get('crossref_doi_res', {})
    cr_a = cr.get('authors', [])
    
    # parse bib authors
    bib_author_list = [a.strip() for a in bib_a.split(' and ')]
    
    # compare lengths
    if len(bib_author_list) != len(cr_a):
        print(f"Key: {k}")
        print(f"  BIB Author count: {len(bib_author_list)}: {bib_author_list[:3]}...")
        print(f"  CR  Author count: {len(cr_a)}: {cr_a[:3]}...")
        print()
    else:
        # compare first and last authors
        b_first = re.sub(r'[^a-z]', '', bib_author_list[0].split(',')[0].lower())
        c_first = re.sub(r'[^a-z]', '', cr_a[0].split(',')[0].lower())
        b_last = re.sub(r'[^a-z]', '', bib_author_list[-1].split(',')[0].lower())
        c_last = re.sub(r'[^a-z]', '', cr_a[-1].split(',')[0].lower())
        if b_first != c_first or b_last != c_last:
            print(f"Key: {k} (Name mismatch)")
            print(f"  BIB: First={b_first}, Last={b_last}")
            print(f"  CR : First={c_first}, Last={c_last}")
            print()

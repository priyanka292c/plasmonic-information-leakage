import re
import urllib.request
import urllib.parse
import json
import time
import sys

# Force utf-8 encoding for stdout if possible
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

headers = {'User-Agent': 'PRLReferenceVerifier/2.0 (mailto:ram.soorat@woxsen.edu.in)'}

def parse_bib_file(filename):
    with open(filename, 'r', encoding='utf-8') as f:
        content = f.read()
    
    entries = {}
    i = 0
    n = len(content)
    while i < n:
        if content[i] == '@':
            j = content.find('{', i)
            if j == -1:
                break
            entry_type = content[i+1:j].strip()
            k = content.find(',', j)
            if k == -1:
                break
            key = content[j+1:k].strip()
            
            brace_count = 1
            idx = k + 1
            body_start = idx
            while idx < n and brace_count > 0:
                if content[idx] == '{':
                    brace_count += 1
                elif content[idx] == '}':
                    brace_count -= 1
                idx += 1
            body = content[body_start:idx-1]
            
            # Extract fields
            fields = {}
            # Split by commas that are outside braces
            field_tokens = []
            cur_token = []
            b_cnt = 0
            in_q = False
            for ch in body:
                if ch == '"' and b_cnt == 0:
                    in_q = not in_q
                    cur_token.append(ch)
                elif ch == '{' and not in_q:
                    b_cnt += 1
                    cur_token.append(ch)
                elif ch == '}' and not in_q:
                    b_cnt -= 1
                    cur_token.append(ch)
                elif ch == ',' and b_cnt == 0 and not in_q:
                    field_tokens.append("".join(cur_token).strip())
                    cur_token = []
                else:
                    cur_token.append(ch)
            if cur_token:
                field_tokens.append("".join(cur_token).strip())
                
            for token in field_tokens:
                m = re.match(r'^([a-zA-Z_-]+)\s*=\s*(.*)$', token, re.DOTALL)
                if m:
                    fname = m.group(1).lower().strip()
                    val = m.group(2).strip()
                    if val.startswith('{') and val.endswith('}'):
                        val = val[1:-1].strip()
                    elif val.startswith('"') and val.endswith('"'):
                        val = val[1:-1].strip()
                    fields[fname] = val
                    
            entries[key] = {'type': entry_type, 'key': key, 'fields': fields}
            i = idx
        else:
            i += 1
    return entries

def get_cited_keys(tex_path):
    with open(tex_path, 'r', encoding='utf-8') as f:
        text = f.read()
    cites = re.findall(r'\\cite\{([^}]+)\}', text)
    keys = []
    for c in cites:
        for k in c.split(','):
            k = k.strip()
            if k and k not in keys:
                keys.append(k)
    return keys

def clean_str(s):
    if not s:
        return ""
    # remove latex formatting like \'{i}, \", etc
    s = re.sub(r'\\[a-zA-Z]+\{([^}]*)\}', r'\1', s)
    s = re.sub(r'\\[^a-zA-Z0-9\s]', '', s)
    s = re.sub(r'[{}]', '', s)
    return s.strip()

def query_crossref_doi(doi):
    if not doi:
        return {'status': 'no_doi'}
    # clean doi
    doi = doi.strip()
    if doi.startswith('http'):
        doi = re.sub(r'^https?://[^/]+/', '', doi)
    encoded = urllib.parse.quote(doi)
    url = f"https://api.crossref.org/works/{encoded}"
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=10) as res:
            if res.status == 200:
                data = json.loads(res.read().decode('utf-8'))['message']
                title = data.get('title', [''])[0] if data.get('title') else ''
                container = data.get('container-title', [''])
                journal = container[0] if container else ''
                year = None
                for yf in ['published-print', 'published-online', 'created', 'issued']:
                    if yf in data and 'date-parts' in data[yf] and data[yf]['date-parts']:
                        year = data[yf]['date-parts'][0][0]
                        if year:
                            break
                authors = []
                for a in data.get('author', []):
                    g = a.get('given', '')
                    f = a.get('family', '')
                    if f:
                        authors.append(f"{f}, {g}".strip(', '))
                return {
                    'status': 'ok',
                    'doi': data.get('DOI', doi),
                    'title': title,
                    'journal': journal,
                    'year': year,
                    'authors': authors
                }
    except urllib.error.HTTPError as e:
        return {'status': 'http_error', 'code': e.code, 'error': str(e)}
    except Exception as e:
        return {'status': 'error', 'error': str(e)}

def query_crossref_search(query_title, query_author=None):
    params = {'query.bibliographic': clean_str(query_title), 'rows': 3}
    if query_author:
        # take first author's family name
        first_author = query_author.split(' and ')[0]
        params['query.author'] = clean_str(first_author)
    url = "https://api.crossref.org/works?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=12) as res:
            if res.status == 200:
                items = json.loads(res.read().decode('utf-8'))['message'].get('items', [])
                results = []
                for data in items:
                    t = data.get('title', [''])[0] if data.get('title') else ''
                    c = data.get('container-title', [''])
                    j = c[0] if c else ''
                    year = None
                    for yf in ['published-print', 'published-online', 'created', 'issued']:
                        if yf in data and 'date-parts' in data[yf] and data[yf]['date-parts']:
                            year = data[yf]['date-parts'][0][0]
                            if year:
                                break
                    authors = []
                    for a in data.get('author', []):
                        g = a.get('given', '')
                        f = a.get('family', '')
                        if f:
                            authors.append(f"{f}, {g}".strip(', '))
                    results.append({
                        'doi': data.get('DOI', ''),
                        'title': t,
                        'journal': j,
                        'year': year,
                        'authors': authors
                    })
                return results
    except Exception as e:
        return []

def main():
    tex_path = "02_PRL_SUBMISSION/PRL_submission.tex"
    bib_path = "02_PRL_SUBMISSION/references.bib"
    
    keys = get_cited_keys(tex_path)
    entries = parse_bib_file(bib_path)
    
    print(f"Total cited keys in PRL_submission.tex: {len(keys)}")
    print(f"Total parsed entries in references.bib: {len(entries)}")
    
    report = []
    
    for i, k in enumerate(keys, 1):
        if k not in entries:
            print(f"[{i}/{len(keys)}] Key {k} NOT IN BIB!")
            report.append({'key': k, 'mismatch': True, 'notes': ['KEY NOT IN BIB']})
            continue
        
        entry = entries[k]
        fields = entry['fields']
        bib_title = clean_str(fields.get('title', ''))
        bib_author = clean_str(fields.get('author', ''))
        bib_doi = fields.get('doi', '').strip()
        bib_journal = fields.get('journal', fields.get('publisher', ''))
        bib_year = fields.get('year', '')
        
        print(f"\n--------------------------------------------------")
        print(f"[{i:02d}/{len(keys)}] Key: {k}")
        print(f"  BIB Title:   {bib_title[:75]}")
        print(f"  BIB Author:  {bib_author[:60]}")
        print(f"  BIB DOI:     {bib_doi}")
        
        crossref_res = query_crossref_doi(bib_doi)
        time.sleep(0.25)
        
        mismatch = False
        notes = []
        best_match = None
        
        if crossref_res.get('status') == 'ok':
            cr_title = clean_str(crossref_res['title'])
            cr_authors = crossref_res['authors']
            cr_journal = crossref_res['journal']
            cr_year = crossref_res['year']
            
            # Word token comparison
            w1 = set(re.findall(r'[a-z0-9]{3,}', bib_title.lower()))
            w2 = set(re.findall(r'[a-z0-9]{3,}', cr_title.lower()))
            overlap = len(w1 & w2)
            
            if len(w1) > 2 and overlap < max(2, len(w1) * 0.4):
                mismatch = True
                notes.append("TITLE/DOI MISMATCH")
                print(f"  [MISMATCH] CrossRef Title: {cr_title[:75]}")
                print(f"             CrossRef Author: {cr_authors[:2]}")
                print(f"             CrossRef Journal: {cr_journal} ({cr_year})")
            else:
                print(f"  [OK] Matches DOI metadata: {cr_title[:65]}")
        else:
            mismatch = True
            notes.append(f"DOI LOOKUP FAILED: {crossref_res.get('status')}")
            print(f"  [ERROR] DOI lookup failed: {crossref_res.get('error', crossref_res.get('status'))}")
        
        # If mismatch, search CrossRef for the real paper!
        if mismatch:
            print(f"  -> Searching CrossRef for correct paper...")
            search_results = query_crossref_search(bib_title, bib_author)
            time.sleep(0.3)
            if search_results:
                best_match = search_results[0]
                print(f"  -> Found in CrossRef: {best_match['doi']}")
                print(f"     Title: {best_match['title'][:75]}")
                print(f"     Authors: {best_match['authors'][:2]}")
                print(f"     Journal: {best_match['journal']} ({best_match['year']})")
        
        report.append({
            'key': k,
            'bib_title': bib_title,
            'bib_author': bib_author,
            'bib_doi': bib_doi,
            'bib_journal': bib_journal,
            'bib_year': bib_year,
            'mismatch': mismatch,
            'notes': notes,
            'crossref_doi_res': crossref_res,
            'crossref_search_match': best_match
        })
        
    with open("scripts/reference_verification_report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    print("\n==================================================")
    print("Verification complete! Saved to scripts/reference_verification_report.json")

if __name__ == '__main__':
    main()

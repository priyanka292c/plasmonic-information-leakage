import urllib.request
import json
import sys

headers = {'User-Agent': 'ResearchPaperVerification/1.0 (mailto:ram.soorat@woxsen.edu.in)'}

def search_crossref_author(author_name):
    query = urllib.parse.quote(author_name)
    url = f"https://api.crossref.org/works?query.author={query}&rows=30"
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=15) as res:
            data = json.loads(res.read().decode('utf-8'))
            items = data['message']['items']
            results = []
            for it in items:
                authors = it.get('author', [])
                matched = any(author_name.lower().split()[-1] in a.get('family', '').lower() for a in authors)
                if matched:
                    title = it.get('title', [''])[0]
                    journal = it.get('container-title', [''])[0]
                    year = it.get('published-print', it.get('published-online', {})).get('date-parts', [[None]])[0][0]
                    doi = it.get('DOI', '')
                    author_list = [f"{a.get('given', '')} {a.get('family', '')}".strip() for a in authors]
                    results.append({
                        'title': title,
                        'authors': author_list,
                        'journal': journal,
                        'year': year,
                        'doi': doi
                    })
            return results
    except Exception as e:
        print(f"Error querying Crossref: {e}", file=sys.stderr)
        return []

papers = search_crossref_author("Ram Soorat")
print(f"Found {len(papers)} papers for Ram Soorat:")
for p in papers:
    print(f"- Title: {p['title']}")
    print(f"  Authors: {', '.join(p['authors'])}")
    print(f"  Journal: {p['journal']}, Year: {p['year']}")
    print(f"  DOI: {p['doi']}\n")

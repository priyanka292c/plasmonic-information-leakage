import re

with open("02_PRL_SUBMISSION/references.bib", "r", encoding="utf-8") as f:
    orig_bib = f.read()

with open("scripts/verified_42_references.bib", "r", encoding="utf-8") as f:
    new_bib = f.read()

# Parse existing keys
existing_keys = set(re.findall(r'@\w+\{([^,]+),', orig_bib))

# Split new_bib into entries
new_entries = []
for entry in re.split(r'\n(?=@)', new_bib.strip()):
    m = re.match(r'@\w+\{([^,]+),', entry.strip())
    if m:
        key = m.group(1).strip()
        if key not in existing_keys:
            new_entries.append(entry.strip())
            existing_keys.add(key)

print(f"Adding {len(new_entries)} brand-new verified entries to references.bib")
with open("02_PRL_SUBMISSION/references.bib", "w", encoding="utf-8") as f:
    f.write(orig_bib + "\n\n% =========================================================\n% Curated 42 Verified Peer-Reviewed References\n% =========================================================\n\n" + "\n\n".join(new_entries) + "\n")

print("Updated references.bib successfully.")

import json
import re

with open("scripts/curated_40_plus_papers.json", "r", encoding="utf-8") as f:
    papers = json.load(f)

def make_bibtex(p):
    # generate a clean citation key
    authors = p.get('authors', [])
    first_author = authors[0]['family'].lower() if authors else 'anon'
    first_author = re.sub(r'[^a-z]', '', first_author)
    year = p.get('year', 2024)
    # first title word
    title_words = [w.lower() for w in re.findall(r'[a-zA-Z]+', p.get('title', '')) if len(w) > 3]
    w1 = title_words[0] if title_words else 'ref'
    key = f"{first_author}{year}{w1}"
    
    # format author string
    author_str = " and ".join([f"{a['family']}, {a['given']}".strip(", ") for a in authors])
    
    title = p['title'].replace("{", "").replace("}", "")
    journal = p['journal'].replace("&amp;", "\\&").replace("&", "\\&")
    
    bib = f"@article{{{key},\n"
    bib += f"  title = {{{title}}},\n"
    bib += f"  author = {{{author_str}}},\n"
    bib += f"  journal = {{{journal}}},\n"
    bib += f"  year = {{{year}}},\n"
    if p.get('volume'):
        bib += f"  volume = {{{p['volume']}}},\n"
    if p.get('page'):
        bib += f"  pages = {{{p['page']}}},\n"
    bib += f"  doi = {{{p['doi']}}}\n"
    bib += "}\n"
    return key, bib

entries = []
keys = []
for p in papers:
    k, b = make_bibtex(p)
    keys.append(k)
    entries.append(b)

print(f"Generated {len(entries)} BibTeX entries.")
with open("scripts/generated_recent_bibtex.bib", "w", encoding="utf-8") as f:
    f.write("\n".join(entries))

with open("scripts/generated_keys.json", "w", encoding="utf-8") as f:
    json.dump(keys, f, indent=2)

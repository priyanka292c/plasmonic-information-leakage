import urllib.request
import urllib.parse
import json
import time
import re

headers = {'User-Agent': 'PRLReferenceVerifier/1.0 (mailto:ram.soorat@woxsen.edu.in)'}

def verify_doi(doi):
    url = f"https://doi.org/{doi}"
    req = urllib.request.Request(url, headers={'User-Agent': headers['User-Agent'], 'Accept': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=10) as res:
            if res.status in [200, 301, 302]:
                data = json.loads(res.read().decode('utf-8'))
                title = data.get('title', '')
                if isinstance(title, list):
                    title = title[0]
                container = data.get('container-title', '')
                if isinstance(container, list):
                    container = container[0]
                year = None
                for yf in ['published-print', 'published-online', 'issued']:
                    if yf in data and 'date-parts' in data[yf]:
                        year = data[yf]['date-parts'][0][0]
                        if year:
                            break
                authors = []
                for a in data.get('author', []):
                    g = a.get('given', '')
                    f = a.get('family', '')
                    if f:
                        authors.append(f"{g} {f}".strip())
                return {
                    'valid': True,
                    'doi': doi,
                    'title': title,
                    'journal': container,
                    'year': year,
                    'volume': data.get('volume', ''),
                    'page': data.get('page', data.get('article-number', '')),
                    'authors': authors
                }
    except Exception as e:
        return {'valid': False, 'doi': doi, 'error': str(e)}

# Collect candidates from:
# 1) Ram Soorat papers
soorat_dois = [
    "10.1007/s10773-026-06369-3",
    "10.1007/s11468-026-03462-5",
    "10.1016/j.nwnano.2026.100233",
    "10.1007/s11128-026-05192-3",
    "10.32604/jqc.2024.054000",
    "10.17586/2220-8054-2017-8-5-600-605",
    "10.1007/s11128-020-02756-9",
    "10.1007/s12648-024-03112-8",
    "10.1016/j.ijleo.2016.05.046"
]

# 2) Key recent peer-reviewed QRNG, plasmonics, single-photon sources, nanophotonics literature (2018-2026)
literature_dois = [
    # Top-tier recent photonic QRNG / randomness certification
    "10.1103/PRXQuantum.1.010302",          # Drahi et al. PRX Quantum 2020
    "10.1038/s41467-018-07585-0",          # Avesani et al. Nat Commun 2018
    "10.1103/PhysRevLett.120.010503",      # Gehring et al. PRL 2018
    "10.1038/s41534-019-0144-8",           # Michel et al. npj Quantum Inf 2019
    "10.1007/s11128-020-02865-5",          # Di Ma et al. QIP 2020
    "10.1103/PhysRevApplied.15.064034",    # Gehring et al. PRApplied 2021
    "10.1103/PhysRevLett.126.100503",      # Bai et al. PRL 2021
    "10.1007/s11128-024-04593-6",          # Souza et al. QIP 2024
    "10.1364/opticaq.570625",              # Smith et al. Optica Quantum 2025
    "10.1038/s41598-019-48844-4",          # Sarkar et al. Sci Rep 2019
    "10.1063/5.0342762",                   # Shaliq et al. APL 2026
    "10.1007/s10773-026-06288-3",          # Mahato et al. IJTP 2026
    "10.1103/physrevresearch.2.043317",    # Adamson et al. PRResearch 2020
    "10.1038/s41578-022-00473-4",          # Mann et al. Nat Rev Mater 2022
    
    # Top-tier recent plasmonic Purcell enhancement & single photon sources
    "10.1038/s41565-020-00831-x",          # Tomm et al. Nat Nanotechnol 2021
    "10.1126/sciadv.abc8268",              # Uppu et al. Sci Adv 2020
    "10.1038/s41565-019-0551-x",           # Wang et al. Nat Nanotechnol 2019
    "10.1038/s41578-021-00346-6",          # Koenderink Nat Rev Phys 2021
    "10.1038/s41567-020-0935-z",           # Pelton et al. Nat Phys 2020
    "10.1103/PhysRevLett.124.033601",      # Flatten et al. PRL 2020
    "10.1103/PhysRevLett.128.083601",      # Gschwentner et al. PRL 2022
    "10.1103/PhysRevLett.125.153602",      # Luo et al. PRL 2020
    "10.1038/s41377-019-0241-z",           # Cao et al. Light Sci Appl 2020
    "10.1038/s41467-021-25597-4",          # Somaschi et al. Nat Commun 2021
    "10.1021/acs.nanolett.0c03632",        # Liu et al. Nano Lett 2020
    "10.1021/acsphotonics.8b00306",        # Zhang et al. ACS Photonics 2018
    "10.1364/optica.486167",               # Gritsch et al. Optica 2023
    "10.1039/c8nr01527a",                  # Pacheco-Pena et al. Nanoscale 2018
    "10.1088/1361-6455/abf6e1",            # Wang et al. J Phys B 2021
    "10.1140/epjd/s10053-026-01211-1",     # Kanli et al. EPJD 2026
    "10.1038/s41565-022-01187-0",          # Bogdanov et al. Nat Nanotechnol 2022
    "10.1021/acs.nanolett.2c02741",        # Zapf et al. Nano Lett 2022
    "10.1103/PhysRevLett.123.087401",      # Yang et al. PRL 2019
    "10.1126/science.aay9876",             # Bhaskar et al. Science 2020
    "10.1038/s41586-020-2374-1",           # Chen et al. Nature 2020
    "10.1038/s41565-021-00992-7",          # Rugar et al. Nat Nanotechnol 2021
    "10.1103/PhysRevX.10.021053",          # Knaut et al. PRX 2020
    "10.1038/s41467-022-31122-8",          # Bersin et al. Nat Commun 2022
    "10.1103/PhysRevLett.127.143603",      # Ding et al. PRL 2021
    "10.1021/acs.nanolett.1c02821",        # Nguyen et al. Nano Lett 2021
    "10.1038/s41565-023-01389-w"           # Wan et al. Nat Nanotechnol 2023
]

all_candidate_dois = list(dict.fromkeys(soorat_dois + literature_dois))

print(f"Verifying {len(all_candidate_dois)} DOIs directly via doi.org API...")
verified = []
for i, d in enumerate(all_candidate_dois):
    res = verify_doi(d)
    if res['valid']:
        print(f"[{i+1}/{len(all_candidate_dois)}] OK: {d} -> {res['title'][:50]}... ({res['year']}) in {res['journal']}")
        verified.append(res)
    else:
        print(f"[{i+1}/{len(all_candidate_dois)}] FAILED: {d} ({res.get('error')})")
    time.sleep(0.2)

print(f"\nTotal verified references: {len(verified)}")
with open("scripts/verified_40_references.json", "w", encoding="utf-8") as f:
    json.dump(verified, f, indent=2)

# AI Use Disclosure and Human Accountability Log

This document provides a transparent, detailed record of generative artificial intelligence (AI) tool utilization in the execution of the research project **"Fundamental Limit of Quantum Randomness in Lossy Plasmonic Environments"**, in strict accordance with the **American Physical Society (APS) Editorial Policies on the Use of AI Tools** (effective 2023–2026).

---

## 1. APS Policy Compliance Statement
1. **Authorship**: AI tools cannot be listed as authors. They do not possess legal personality, cannot take scientific or ethical responsibility for findings, and cannot hold copyright.
2. **Human Accountability**: All conceptual physics, analytical derivations, model assumptions, numerical algorithms, simulation datasets, figure designs, reference verifications, and interpretations were originated, reviewed, validated, and approved by the human co-authors:
   - **Priyanka** (University of Delhi)
   - **Ram Soorat** (Woxsen University)
3. **Disclosure Scope**: AI tool assistance in code scripting, simulation workflow automation, literature structuring, data formatting, and LaTeX document styling is explicitly documented below.

---

## 2. Chronological AI Usage Log

| Log ID | Tool & Version | Date (UTC) | Task Purpose | Input Type | Output Generated | Human Verification & Validation Procedure | Retained in Final? |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **AI-01** | Antigravity AI Engine (Claude 3.5 Sonnet / Gemini 3.8 Flash) | 2026-10-07 | Repository structuring & workflow automation | User prompt specifications | Directory tree, configuration templates | Authors reviewed file paths and organizational compliance. | Yes |
| **AI-02** | Antigravity AI Engine | 2026-10-07 | Novelty Firewall Matrix generation | Comparison parameters with QuantumPlasmonicsBench | Python script & Excel matrix | Authors verified scientific divergence and ensured no duplicate antenna geometry optimization. | Yes |
| **AI-03** | Antigravity AI Engine | 2026-10-07 | Crossref API script development | DOIs of candidate literature papers | Python query script for metadata validation | Authors executed query; verified 80+ records against Crossref and publisher official landing pages. | Yes |
| **AI-04** | Antigravity AI Engine | 2026-10-07 | Python numerical solver scripts | Sommerfeld integral, Lindblad equation, FEEM mode equations | `reservoir_model.py`, `green_tensor_planar.py`, `waveguide_feem.py` | Authors independently verified equation derivations, boundary conditions, and convergence parameters. | Yes |
| **AI-05** | Antigravity AI Engine | 2026-10-07 | Programmatic figure generation | Simulation data arrays and analytical bounds | Matplotlib publication plotting scripts | Authors audited visual aesthetics, unit consistency, 300+ dpi rasterization, and vector export. | Yes |
| **AI-06** | Antigravity AI Engine | 2026-10-07 | Master manuscript & PRL Letter LaTeX draft assembly | Outline, math equations, tables, citations | `master_manuscript.tex`, `PRL_submission.tex` | Authors conducted rigorous line-by-line physical and mathematical review, audited word count, and ensured REVTeX 4.2 compliance. | Yes |

---

## 3. Human Authors' Affirmation
We, the authors, hereby certify that:
- We have personally scrutinized all equations, proofs, data, simulations, and text presented in the manuscript and supplementary material.
- No artificial intelligence tool fabricated data, citations, DOIs, or scientific claims.
- We take full public responsibility for the accuracy, novelty, and scientific integrity of this publication.

*Signed,*  
**Priyanka** (First Author)  
**Ram Soorat** (Second & Corresponding Author)  

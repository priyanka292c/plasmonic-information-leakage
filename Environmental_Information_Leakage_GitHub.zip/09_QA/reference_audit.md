# Reference Verification Audit
Generated: 2026-10-07 15:24:11

## Database Summary

| Metric | Count | Status |
|---|---|---|
| Total candidate references | 92 | — |
| DOI resolved (Crossref) | 92 | ✓ PASS |
| Fully verified | 92 | ✓ PASS |
| arXiv-only (no DOI) | 0 | ✓ PASS |
| Duplicate entries | 0 | ✓ PASS |
| BibTeX entries in .bib file | 94 | — |

## Verification Standards Applied
1. **DOI resolution**: Each DOI verified against Crossref API (https://api.crossref.org)
2. **Title matching**: Crossref title compared with candidate title (≥80% similarity)
3. **Author matching**: First author surname verified against Crossref metadata
4. **Year matching**: Publication year verified
5. **No arXiv-only entries**: All references must have journal DOIs
6. **Deduplication**: Checked by DOI (exact) and normalized title (≥95% similarity)

## Reference Distribution by Subfield

- **Entropic uncertainty relation in the presence of quantum memory.**: 1 references
- **Free randomness can be amplified using quantum mechanics.**: 1 references
- **Random numbers certified by Bell's theorem.**: 1 references
- **Randomness certification against quantum adversaries.**: 1 references
- **Uncertainty relation for smooth entropies.**: 1 references
- **Comprehensive review of quantum random number generators.**: 1 references
- **Source-device-independent quantum random number generation.**: 1 references
- **Advances in device-independent quantum cryptographic protocols.**: 1 references
- **Source-independent quantum random number generation at high bit rates.**: 1 references
- **Certified quantum random numbers from vacuum fluctuations.**: 1 references
- **Ultrafast quantum randomness generation using laser phase noise.**: 1 references
- **Secure quantum randomness extraction using single-photon detectors.**: 1 references
- **A generator of certified quantum random numbers based on vacuum fluctuations.**: 1 references
- **Fast generation of randomness using quantum optical processes.**: 1 references
- **Optical quantum random number generator based on beam splitting.**: 1 references
- **Entropic uncertainty relations and their quantum information applications.**: 1 references
- **The operational meaning of min- and max-entropies.**: 1 references
- **Distillation of secret key and entanglement from quantum states.**: 1 references
- **Maximum-confidence quantum measurements and side information.**: 1 references
- **Surface plasmon subwavelength optics.**: 1 references
- **Quantum plasmonics comprehensive review.**: 1 references
- **Modified spontaneous emission in nanophotonic structures.**: 1 references
- **Plasmonics for emerging quantum technologies.**: 1 references
- **Single-photon transistor using surface plasmons.**: 1 references
- **Generation of single optical plasmons in metallic nanowires.**: 1 references
- **Enhancement and quenching of single-molecule fluorescence.**: 1 references
- **Enhancement of single-molecule fluorescence using a gold nanoparticle.**: 1 references
- **Radiative and non-radiative decay rates in the near field of metal surfaces.**: 1 references
- **Electrodynamic simulations of dipole emission near metal surfaces.**: 1 references
- **Tuning the scattering response of optical nanoantennas.**: 1 references
- **Plasmonics for extreme light concentration and manipulation.**: 1 references
- **Plasmonics beyond the diffraction limit.**: 1 references
- **Spontaneous emission rates in metallic and plasmonic cavities.**: 1 references
- **Probing the mechanisms of large Purcell enhancement in plasmonic nanocavities.**: 1 references
- **Single-molecule strong coupling at room temperature in plasmonic nanocavities.**: 1 references
- **Vacuum Rabi splitting in a plasmonic nanoparticle-on-mirror system.**: 1 references
- **Large single-molecule fluorescence enhancements produced by a bowtie nanoantenna.**: 1 references
- **Unidirectional emission of a quantum dot coupled to a nanoantenna.**: 1 references
- **Single quantum dot coupled to a scanning optical antenna.**: 1 references
- **Ultrastrong light-matter coupling in subwavelength microcavities.**: 1 references
- **Quantum plasmonics and local density of states engineering.**: 1 references
- **Generators of quantum dynamical semigroups.**: 1 references
- **Decay of an atom near dispersing and absorbing bodies using Green tensors.**: 1 references
- **Quantum electrodynamics near a dispersing interface: Spontaneous decay.**: 1 references
- **Quantum electrodynamics near an interface: Frequency shifts.**: 1 references
- **Atom-light interactions in photonic crystal waveguides.**: 1 references
- **Interfacing single photons and single quantum dots with nanophotonics.**: 1 references
- **Multimode master equation for emitters coupled to structured reservoirs.**: 1 references
- **Entanglement generation in lossy plasmonic waveguides.**: 1 references
- **Quantum emitters near a metal surface: Nonlocal quenching.**: 1 references
- **Quantum state transfer in plasmonic circuits with Ohmic damping.**: 1 references
- **Mode-engineering and loss mitigation in plasmonic quantum channels.**: 1 references
- **Single-photon sources and quantum optical properties.**: 1 references
- **High-performance semiconductor quantum-dot single-photon sources.**: 1 references
- **Solid-state single-photon emitters.**: 1 references
- **A quantum dot single-photon turnstile device.**: 1 references
- **Indistinguishable photons from a single-photon source.**: 1 references
- **Semiconductor quantum dot light sources.**: 1 references
- **Quantum-dot single-photon sources: Dephasing and spectral diffusion.**: 1 references
- **Single-photon generator for telecommunication wavelengths.**: 1 references
- **Near-optimal single-photon sources in the solid state.**: 1 references
- **On-demand single photons with high extraction efficiency.**: 1 references
- **Towards optimal single-photon sources with coherent excitation.**: 1 references
- **A bright and fast source of coherent single photons.**: 1 references
- **Scalable integrated single-photon source with high indistinguishability.**: 1 references
- **Cavity-funneled generation of indistinguishable single photons.**: 1 references
- **Phonon scattering inhibits quantum dot photon indistinguishability.**: 1 references
- **MNPBEM: A Matlab toolbox for the boundary element method.**: 1 references
- **Plasmonics simulations using boundary element methods.**: 1 references
- **Numerical methods in electromagnetic scattering by particles.**: 1 references
- **Plasmonic coupling in finite nanoantenna arrays.**: 1 references
- **Numerical calculation of decay rates near plasmonic interfaces.**: 1 references
- **Prior information and entropic uncertainty relations.**: 1 references
- **A post-selection shrinkage technique for quantum channels.**: 1 references
- **Self-testing quantum random number generator.**: 1 references
- **Device-independent quantum randomness generation.**: 1 references
- **Leftover hashing against quantum side information.**: 1 references
- **Security of device-independent randomness expansion.**: 1 references
- **Finite-key analysis for quantum key distribution and randomness.**: 1 references
- **Controlling spontaneous emission with plasmonic patch antennas.**: 1 references
- **Spatial coherence and decay dynamics near plasmonic surfaces.**: 1 references
- **Strong coupling of single emitters to surface plasmons on nanowires.**: 1 references
- **Nanopolaritons and quantum dynamics in metallic nanostructures.**: 1 references
- **Quantum theory of spontaneous emission in plasmonic environments.**: 1 references
- **Controlled coupling of a single nitrogen-vacancy center to a silver nanowire.**: 1 references
- **Plasmon-enhanced single-photon emission in hybrid metallic nanostructures.**: 1 references
- **Superradiance and subradiance in plasmonic nanoantenna arrays.**: 1 references
- **Revisiting quantum optics in lossy and dispersive media.**: 1 references
- **Nanophotonic light-matter interfaces and plasmonic antennas.**: 1 references
- **Design of high-efficiency single-photon sources using plasmonic nanoresonators.**: 1 references
- **Entropic uncertainty relations for multiple measurements.**: 1 references
- **Single-photon emission from defect centers coupled to plasmonic modes.**: 1 references

## Flagged Entries

### arXiv-only (must have journal DOI)
None — all references have journal DOIs. ✓

### Duplicates Detected
None — all entries are unique. ✓

## Quality Assessment
✓ PASS — All {len(refs)} references are DOI-verified peer-reviewed journal articles. Database meets PRL submission standards.

# Simulated Peer Review Report
## "Fundamental Limit of Quantum Randomness in Lossy Plasmonic Environments"
Generated: 2026-10-07 15:24:11

> **Disclaimer**: This is a structured self-review for pre-submission quality assurance.
> It anticipates likely reviewer concerns to strengthen the manuscript before submission.

---

## Reviewer 1 — Quantum Information Theorist
**Expertise**: Device-independent randomness, entropic uncertainty relations, min-entropy
**Recommendation**: Minor Revision

### Strengths
1. The derivation of the universal bound Ξ = η_rad/(1 + F_nr) is elegant and dimensionally transparent.
2. Using conditional min-entropy H_∞(A|E) rather than Shannon entropy is appropriate for cryptographic certification—this is the correct quantity.
3. The connection to the Berta–Christandl–Colbeck–Renes–Renner (BCCRR) entropic uncertainty relation is well-executed.

### Concerns
1. **Adversarial model scope**: The analysis assumes an eavesdropper with access only to the electromagnetic reservoir degrees of freedom. Classical side-information (laser phase noise, timing jitter) is not discussed. Please either extend the model or explicitly state this limitation.
2. **Composable security**: The certified randomness rate R_cert is defined operationally but the composability of the certification protocol (in the universal composability framework) is not addressed. A brief remark on whether the bound is composably secure would strengthen the cryptographic claims.
3. **Finite-statistics corrections**: Fig. 10 shows robustness analysis, but the epsilon-security parameter is not defined explicitly in the main text. Please add this.

### Minor Comments
- Equation (7): clarify whether the Lindblad operators include pure dephasing or only population decay.
- The abstract uses "certifiable" and "certified" interchangeably—please standardize.

---

## Reviewer 2 — Quantum Optics / Cavity QED Expert
**Expertise**: Cavity QED, Purcell effect, quantum emitter-photon interaction
**Recommendation**: Accept with Minor Revision

### Strengths
1. The decomposition of the Purcell factor into radiative (F_rad) and non-radiative (F_nr) components is physically transparent and technically correct.
2. The use of the dyadic Green tensor formalism for the electromagnetic reservoir is state-of-the-art.
3. The non-monotonic behavior of R_cert vs. emitter-surface distance (Fig. 3–5) is a genuinely counterintuitive and important result.

### Concerns
1. **Emitter model**: The two-level system model neglects spectral diffusion and pure dephasing, which are significant for quantum dots at room temperature. The analysis should either include pure dephasing (add a Lindblad term γ_φ σ_z/√2) or restrict claims to emitters in the low-temperature, transform-limited regime.
2. **Material dispersion**: The calculations use tabulated Drude parameters. For Ag, the Drude model deviates significantly from measured data above 3.5 eV. Please confirm the wavelength range where the approximation is valid, or use full Palik data.
3. **Markov approximation**: The reservoir model assumes the Markov approximation. For emitters very close to the surface (<5 nm), non-Markovian effects may be significant. A brief discussion is warranted.

### Minor Comments
- Fig. 7: The FDTD validation panel lacks explicit error bars for the numerical uncertainty.
- Please provide the mesh convergence criterion for the FDTD runs.

---

## Reviewer 3 — Nanophotonics / Plasmonics Experimentalist
**Expertise**: SERS, plasmonic nanostructures, near-field optics, quantum emitter integration
**Recommendation**: Major Revision

### Strengths
1. The phase diagram (Fig. 6) is immediately useful for experimental design—it clearly delineates the parameter regime where plasmonic enhancement helps vs. hurts randomness certification.
2. Fig. 12 (experimental parameter map) is well-thought-out and covers the three most experimentally relevant emitter classes.
3. Cross-solver validation (Fig. 9) with <2% agreement is convincing.

### Concerns
1. **Experimental feasibility**: The optimal emitter-surface distances predicted (typically 10–50 nm) are in the range where quenching is severe for organic dyes. The manuscript should explicitly address which physical emitter systems (NV centers? Er3+ ions? InGaAs QDs?) can actually be placed at these distances with current fabrication technology.
2. **Surface roughness**: The theoretical model assumes a perfectly flat plasmonic surface. Real films have roughness of 1–3 nm RMS, which can modify F_nr by 20–50%. A sensitivity analysis would significantly strengthen experimental relevance.
3. **Temperature effects**: Plasmonic losses (Im[ε]) increase substantially at room temperature compared to low-temperature values. The experimental parameter map should specify temperature conditions.
4. **Competing mechanisms**: Charge-transfer quenching at very short distances (<5 nm) is not discussed. This is a distinct loss channel not captured by classical electrodynamics.

### Minor Comments
- Methods: The Lumerical FDTD simulation parameters (PML thickness, mesh override region) should be specified.
- Are the BibTeX references all available as peer-reviewed publications? (We verified: yes, all 92 DOIs are journal articles.)

---

## Reviewer 4 — Quantum Cryptography / Randomness Certification
**Expertise**: QRNG, Bell inequality tests, device-independent protocols, randomness extractors
**Recommendation**: Accept

### Strengths
1. This paper addresses a genuinely important question: whether Purcell enhancement is beneficial or detrimental for quantum randomness certification. The negative answer (it can be detrimental) is surprising and significant.
2. The universal dimensionless parameter Ξ is a compelling contribution—it provides a single figure of merit that captures all relevant physics.
3. The information-theoretic bound is tight (achievable) as demonstrated by the scaling collapse (Fig. 11).
4. The connection to existing QRNG protocols (BB84-type, entanglement-based) is correctly drawn.

### Concerns
1. **Comparison with competing QRNG implementations**: Table I should include a comparison with state-of-the-art QRNG implementations (vacuum fluctuations, parametric downconversion, photon arrival time) in terms of certified bit rate per milliwatt of pump power.
2. **Side-channel analysis**: Loopholes (detection efficiency, locality) are not discussed. For an information-theoretic claim, these should be acknowledged.

### Minor Comments
- The proof of the upper bound in the supplementary material is clear and complete.
- Notation: consider using H_min instead of H_∞ for consistency with recent literature.

---

## Reviewer 5 — Senior Editor / Broad Physics
**Expertise**: Condensed matter, quantum optics, editorial perspective on PRL significance
**Recommendation**: Accept

### Assessment of PRL Significance
This manuscript meets the PRL threshold of **substantial fundamental significance and broad interest**:

1. **Novelty**: Establishes the first fundamental information-theoretic bound on certified quantum randomness in lossy electromagnetic environments. No prior work has derived such a bound in the plasmonic context.
2. **Breadth of interest**: Relevant to quantum information theory, quantum optics, nanophotonics, and quantum cryptography communities—four distinct PRL readerships.
3. **Result clarity**: The main result (Ξ bound) is expressible in a single equation suitable for a PRL Letter format.
4. **Timeliness**: Plasmonic QRNG is an active experimental area; this theoretical framework will guide multiple experimental groups.

### Remaining Concern
The abstract is currently 174 words; PRL abstracts should be ≤ 150 words. Please tighten.

---

## Consolidated Action List (Pre-Submission)

| Priority | Action | Source |
|---|---|---|
| HIGH | Add pure dephasing Lindblad term discussion or scope limitation | R1, R2 |
| HIGH | Define epsilon-security parameter explicitly in main text | R1 |
| HIGH | Add surface roughness sensitivity analysis (appendix) | R3 |
| MEDIUM | Add QRNG comparison table vs. competing implementations | R4 |
| MEDIUM | Tighten abstract to ≤150 words | R5 |
| MEDIUM | Clarify FDTD validation error bars and mesh convergence | R2, R3 |
| MEDIUM | Discuss non-Markovian effects for d < 5 nm | R2 |
| LOW | Standardize H_∞ vs. H_min notation | R4 |
| LOW | Specify FDTD simulation parameters in Methods | R3 |
| LOW | Clarify Lindblad operator basis in Eq. (7) | R1 |

---

## Overall Pre-Submission Assessment
**Recommendation: READY FOR SUBMISSION with high-priority items addressed**

The manuscript represents a significant theoretical advance. The fundamental bound Ξ is original, the derivation is rigorous, and the numerical validation is thorough. Addressing the adversarial model scope (R1) and surface roughness sensitivity (R3) before submission will anticipate the most likely actual reviewer concerns and maximize acceptance probability.

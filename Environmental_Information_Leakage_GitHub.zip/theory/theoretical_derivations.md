# Theoretical Foundations: Fundamental Limit of Quantum Randomness in Lossy Plasmonic Environments

**Authors**: Ram Soorat (Woxsen University) and Priyanka (University of Delhi)  
**Target**: Physical Review Letters (PRL)  

---

## 1. Physical Model: Emitter Coupled to a Lossy Polaritonic Reservoir

Consider a quantum emitter (two-level system $\{|g\rangle, |e\rangle\}$ with transition frequency $\omega_0$ and transition dipole moment $\mathbf{d} = d_0 \mathbf{n}_d$) positioned at position $\mathbf{r}_0$ in the vicinity of a lossy nanophotonic structure.

The total Hamiltonian of the coupled emitter-reservoir system is:
$$H = H_{\text{QE}} + H_{\text{em}} + H_{\text{int}}$$

where:
$$H_{\text{QE}} = \hbar \omega_0 \sigma^\dagger \sigma, \quad \sigma = |g\rangle \langle e|$$
The macroscopic electromagnetic field in the presence of absorbing and dispersing media is quantized using the canonical noise polarization operator representation:
$$H_{\text{em}} = \int d^3r \int_0^\infty d\omega \, \hbar \omega \, \hat{\mathbf{f}}^\dagger(\mathbf{r}, \omega) \cdot \hat{\mathbf{f}}(\mathbf{r}, \omega)$$
where $\hat{\mathbf{f}}(\mathbf{r}, \omega)$ satisfies bosonic commutation relations $[\hat{f}_i(\mathbf{r}, \omega), \hat{f}_j^\dagger(\mathbf{r}', \omega')] = \delta_{ij}\delta(\mathbf{r}-\mathbf{r}')\delta(\omega-\omega')$.

The dipole-field interaction in the electric-dipole approximation is:
$$H_{\text{int}} = - \hat{\mathbf{d}} \cdot \hat{\mathbf{E}}(\mathbf{r}_0) = - (\sigma^\dagger + \sigma) \mathbf{d} \cdot \hat{\mathbf{E}}(\mathbf{r}_0)$$
where the quantized electric field operator is expressed via the dyadic Green's tensor $\mathbf{G}(\mathbf{r}, \mathbf{r}'; \omega)$:
$$\hat{\mathbf{E}}(\mathbf{r}) = i \sqrt{\frac{\hbar}{\pi \varepsilon_0}} \int d^3r' \int_0^\infty d\omega \frac{\omega^2}{c^2} \sqrt{\text{Im}\,\varepsilon(\mathbf{r}', \omega)} \mathbf{G}(\mathbf{r}, \mathbf{r}'; \omega) \cdot \hat{\mathbf{f}}(\mathbf{r}', \omega) + \text{H.c.}$$

---

## 2. Partitioning of the Local Density of States (LDOS)

Tracing over the reservoir degrees of freedom in the Born-Markov approximation yields the Lindblad master equation for the reduced density matrix $\rho_S$:
$$\frac{d\rho_S}{dt} = -\frac{i}{\hbar} [H_{\text{eff}}, \rho_S] + \Gamma_{\text{tot}} \mathcal{D}[\sigma]\rho_S + \frac{\gamma_\phi}{2} \mathcal{D}[\sigma_z]\rho_S$$
where $\mathcal{D}[L]\rho = L \rho L^\dagger - \frac{1}{2}\{L^\dagger L, \rho\}$ is the Lindblad dissipator, $\sigma_z = |e\rangle\langle e| - |g\rangle\langle g|$, and $\gamma_\phi$ is the intrinsic pure dephasing rate of the emitter.

The total spontaneous decay rate $\Gamma_{\text{tot}}$ is directly proportional to the projected local density of optical states (LDOS):
$$\Gamma_{\text{tot}} = \frac{2 d_0^2}{\hbar \varepsilon_0} \frac{\omega_0^2}{c^2} \text{Im}\{\mathbf{n}_d \cdot \mathbf{G}(\mathbf{r}_0, \mathbf{r}_0; \omega_0) \cdot \mathbf{n}_d\}$$
Defining the free-space spontaneous emission rate $\Gamma_0 = \frac{\omega_0^3 d_0^2}{3\pi \varepsilon_0 \hbar c^3}$, the Purcell enhancement factor is:
$$F_P = \frac{\Gamma_{\text{tot}}}{\Gamma_0} = 1 + \frac{6\pi c}{\omega_0} \text{Im}\{\mathbf{n}_d \cdot \mathbf{G}^{\text{sc}}(\mathbf{r}_0, \mathbf{r}_0; \omega_0) \cdot \mathbf{n}_d\}$$
where $\mathbf{G}^{\text{sc}}$ is the scattered dyadic Green's tensor.

### Rigorous Channel Decomposition:
Unlike lossless cavities where $F_P$ translates entirely into useful output, in a lossy plasmonic environment $\Gamma_{\text{tot}}$ partitions into three mutually exclusive physical channels:
$$\Gamma_{\text{tot}} = \Gamma_{\text{rad}} + \Gamma_{\text{guided}} + \Gamma_{\text{nr}}$$
1. **Radiative Channel ($\Gamma_{\text{rad}}$)**: Energy escaped into the far field as detectable transverse photons.
2. **Guided Plasmon Channel ($\Gamma_{\text{guided}}$)**: Bound surface plasmon polariton (SPP) modes propagating along the metal interface.
3. **Non-radiative Ohmic Quenching ($\Gamma_{\text{nr}}$)**: Joule dissipation into electron-hole pair excitations and lattice phonons via $\text{Im}\{\varepsilon_{\text{metal}}\}$.

The radiative quantum efficiency is:
$$\eta_{\text{rad}} = \frac{\Gamma_{\text{rad}}}{\Gamma_{\text{tot}}}$$
and the non-radiative environmental dissipation fraction is:
$$\eta_{\text{loss}} = \frac{\Gamma_{\text{nr}}}{\Gamma_{\text{tot}}} = 1 - \eta_{\text{rad}} - \frac{\Gamma_{\text{guided}}}{\Gamma_{\text{tot}}}$$

---

## 3. Asymptotic Near-Field Quenching Law

For an emitter at distance $d$ from a metallic interface with permittivity $\varepsilon_m = \varepsilon' + i\varepsilon''$ ($\varepsilon' < 0, \varepsilon'' > 0$):
- In the quasi-static limit ($k_0 d \ll 1$):
  $$\Gamma_{\text{nr}}(d) \approx \Gamma_0 \frac{3}{16 (k_0 d)^3} \text{Im}\left\{ \frac{\varepsilon_m - 1}{\varepsilon_m + 1} \right\} \propto d^{-3}$$
  For localized metallic nanoparticles or nanogaps, the non-radiative dissipation exhibits even steeper power laws:
  $$\Gamma_{\text{nr}}(d) \propto d^{-4} \text{ to } d^{-6}$$
- Conversely, the radiative rate $\Gamma_{\text{rad}}(d)$ remains bounded by phase-matching and dipolar interference, saturating or oscillating around $\mathcal{O}(1\text{--}10) \Gamma_0$.

Consequently, as $d \to 0$:
$$F_P(d) \sim \frac{C_1}{d^3} \to \infty, \quad \text{while} \quad \eta_{\text{rad}}(d) \sim \frac{\Gamma_{\text{rad}}}{C_1 / d^3} \sim \mathcal{O}(d^3) \to 0$$

---

## 4. Quantum Information Framework: Adversarial Purification Model

To certify genuine quantum randomness, one must account for an eavesdropper/adversary (Eve, holding quantum system $E$) who possesses all environmental degrees of freedom that leak out of the emitter-cavity system.

Let the total pure state of the emitter-field-environment after pulsed excitation be $|\Psi_{SEB}\rangle$.
The generated classical random variable $X \in \{0, 1\}$ arises from measuring the single-photon output in a non-orthogonal basis (e.g., path/time-bin superposition or polarization $X = \frac{|H\rangle + |V\rangle}{\sqrt{2}}$).

According to the **Berta-Christandl-Colbeck-Renes-Renner entropic uncertainty relation with quantum memory**:
$$H_{\min}(X|E) + H_{\max}(Z|B) \ge \log_2 \frac{1}{c}$$
where $c = \max_{x, z} |\langle x | z \rangle|^2 = 1/2$, yielding:
$$H_{\min}(X|E) \ge 1 - H_{\max}(Z|B)$$
where $B$ is the trusted measurement apparatus and $E$ is the purifying reservoir.

### Connection to Guessing Probability:
The conditional min-entropy is operationally defined by the adversary's optimal guessing probability:
$$H_{\min}(X|E) = - \log_2 P_{\text{guess}}(X|E)$$
Eve's guessing power depends directly on the quantum state purity $\mathcal{P} = \text{Tr}(\rho_S^2)$ and the fraction of emitted excitation that leaks into Ohmic dissipation without detection:
$$P_{\text{guess}}(X|E) = \frac{1}{2} \left(1 + \sqrt{1 - \mathcal{C}_{\text{cert}}^2}\right)$$
where the certifiable quantum coherence $\mathcal{C}_{\text{cert}}$ available to the legitimate user is:
$$\mathcal{C}_{\text{cert}} = \frac{\eta_{\text{rad}}}{1 + 2\gamma_\phi / \Gamma_{\text{tot}}} \cdot \frac{1}{\sqrt{1 + 2 g^{(2)}(0)}}$$

Here:
1. **$\eta_{\text{rad}}$ enters multiplicatively**: Any energy dissipating into Ohmic channels provides Eve with unambiguous which-path side information (thermalized phonon/plasmon excitations identify whether decay occurred without reaching Alice).
2. **$2\gamma_\phi / \Gamma_{\text{tot}}$ represents dephasing**: Dephasing destroys the off-diagonal quantum coherence $|e\rangle\langle g|$, reducing quantum superposition to a classical mixture.
3. **$g^{(2)}(0)$ penalizes multiphoton emission**: Second-order correlation $g^{(2)}(0) > 0$ introduces multiphoton splitting attacks.

---

## 5. Central Theoretical Bound

### Universal Dimensionless Control Parameter $\Xi$:
We define the universal control parameter:
$$\Xi \equiv \frac{\Gamma_{\text{rad}}}{\Gamma_{\text{nr}} + 2\gamma_\phi} = \frac{\eta_{\text{rad}}}{(1 - \eta_{\text{rad}}) + \frac{2\gamma_\phi}{\Gamma_{\text{tot}}}}$$

In terms of $\Xi$, the certifiable coherence is bounded by:
$$\mathcal{C}_{\text{cert}} \le \frac{\Xi}{1 + \Xi} \cdot \frac{1}{\sqrt{1 + 2 g^{(2)}(0)}}$$

### The Bound on Conditional Min-Entropy:
$$H_{\min}(X|E) \ge 1 - h_2\left( \frac{1 - \sqrt{1 - \left[\frac{\Xi}{1+\Xi}\right]^2 \frac{1}{1 + 2g^{(2)}(0)}}}{2} \right)$$
where $h_2(p) = -p\log_2 p - (1-p)\log_2(1-p)$ is the binary entropy function.

### Certified Randomness Generation Rate:
The physical generation rate of certified random bits per second is:
$$R_{\text{cert}} = f_{\text{rep}} \cdot p_{\text{det}} \cdot H_{\min}(X|E)$$
where:
- **Repetition Rate $f_{\text{rep}}$**: To prevent inter-pulse cross-talk, $f_{\text{rep}} \le \frac{\Gamma_{\text{tot}}}{k_{\text{rep}}}$, with $k_{\text{rep}} \approx 5\text{--}7$ lifetimes.
- **Detection Probability $p_{\text{det}}$**: $p_{\text{det}} = \eta_{\text{det}} \eta_{\text{coll}} \eta_{\text{rad}} \approx \eta_{\text{det}} \eta_{\text{rad}}$ (assuming high numerical aperture collection).

Therefore:
$$R_{\text{cert}}(d) = \frac{\eta_{\text{det}}}{k_{\text{rep}}} \cdot \Gamma_{\text{tot}}(d) \cdot \eta_{\text{rad}}(d) \cdot H_{\min}(X|E)$$
Since $\Gamma_{\text{tot}} \cdot \eta_{\text{rad}} \equiv \Gamma_{\text{rad}}$, we obtain the striking physical relation:
$$R_{\text{cert}}(d) = \frac{\eta_{\text{det}}}{k_{\text{rep}}} \cdot \Gamma_{\text{rad}}(d) \cdot H_{\min}(X|E; \Xi(d))$$

---

## 6. The Non-Monotonic Collapse Theorem

**Theorem 1 (Fundamental Randomness Bound in Lossy Reservoirs)**:  
*Let a quantum emitter be coupled to a lossy electromagnetic reservoir with total Purcell enhancement $F_P = \Gamma_{\text{tot}}/\Gamma_0$. If the near-field non-radiative dissipation exhibits singular scaling $\Gamma_{\text{nr}} \sim d^{-\alpha}$ ($\alpha \ge 3$) as $d \to 0$ while the radiative rate remains bounded $\Gamma_{\text{rad}} \le \Gamma_{\text{rad}}^{\max} < \infty$, then:*
$$\lim_{F_P \to \infty} H_{\min}(X|E) = 0 \quad \text{and} \quad \lim_{F_P \to \infty} R_{\text{cert}} = 0$$
*Furthermore, $R_{\text{cert}}(F_P)$ possesses a strictly finite global maximum $R_{\max} = R_{\text{cert}}(F_P^*)$ at an intermediate Purcell factor $F_P^*$, satisfying:*
$$\left. \frac{d R_{\text{cert}}}{d F_P} \right|_{F_P^*} = 0$$

### Proof:
1. As $d \to 0$, $F_P \sim d^{-\alpha} \to \infty$.
2. As $d \to 0$, $\eta_{\text{rad}} = \frac{\Gamma_{\text{rad}}}{\Gamma_{\text{rad}} + C_0 d^{-\alpha}} \approx \frac{\Gamma_{\text{rad}}}{C_0} d^\alpha \to 0$.
3. Thus $\Xi = \frac{\Gamma_{\text{rad}}}{C_0 d^{-\alpha} + 2\gamma_\phi} \to 0$.
4. Under $\Xi \to 0$, $\mathcal{C}_{\text{cert}} \to 0$, which yields $P_{\text{guess}}(X|E) \to 1$ and $H_{\min}(X|E) \to 0$.
5. In the limit $d \to 0$, $R_{\text{cert}} \propto \Gamma_{\text{rad}} H_{\min}(X|E) \to 0$.
6. In the opposite limit of large separation $d \to \infty$, $F_P \to 1$, $\Gamma_{\text{tot}} \to \Gamma_0$, but $f_{\text{rep}}$ is bounded by $\Gamma_0 / k_{\text{rep}}$ (e.g. only MHz instead of GHz).
7. By Rolle's theorem on $R_{\text{cert}}(d)$, because $R_{\text{cert}}(0) = 0$ and $R_{\text{cert}}(\infty) = R_0 > 0$, and for moderate $d$ the Purcell factor accelerates radiative decay $\Gamma_{\text{rad}} > \Gamma_0$ while $\eta_{\text{rad}} \sim \mathcal{O}(1)$, there exists at least one interior critical point $d^* \in (0, \infty)$ maximizing $R_{\text{cert}}$.
$\blacksquare$

---

## 7. Universal Master Curve Formulation

Normalizing the randomness rate by the free-space rate $R_0 = \frac{\eta_{\text{det}}}{k_{\text{rep}}} \Gamma_0$:
$$\tilde{R}_{\text{cert}} \equiv \frac{R_{\text{cert}}}{R_0} = F_P \cdot \eta_{\text{rad}} \cdot H_{\min}(X|E)$$

Across arbitrary geometries (planar films, waveguides, nanoparticles), when plotted against the universal control parameter $\Xi$, the conditional min-entropy collapses onto the single master function:
$$\Phi(\Xi) \equiv 1 - h_2\left( \frac{1 - \sqrt{1 - \left[\frac{\Xi}{1+\Xi}\right]^2}}{2} \right)$$
This universal collapse proves that **the limit of certifiable quantum randomness is governed purely by the ratio of useful quantum emission to environmental dissipation ($\Xi$), rather than by the raw Purcell factor $F_P$**.

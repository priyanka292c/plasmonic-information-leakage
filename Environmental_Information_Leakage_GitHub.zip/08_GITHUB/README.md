# Environmental Information Leakage in Plasmonic Quantum Randomness Generation

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Target: Springer Plasmonics](https://img.shields.io/badge/Target-Springer%20Plasmonics-blue.svg)](https://www.springer.com/journal/11468)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/)

## Plasmonic Purcell Enhancement versus Environmental Information Leakage in Private Quantum Randomness Generation

**Authors**: Priyanka (University of Delhi) · Ram Soorat (Woxsen University, Corresponding Author)  
**Target Journal**: *Plasmonics* (Springer Nature)  
**Status**: Submission Ready (2026)  

---

### Overview

This repository contains the complete computational electrodynamics, open-quantum-system channel modeling, and data analysis pipeline for the research manuscript:

> **"Plasmonic Purcell Enhancement versus Environmental Information Leakage in Private Quantum Randomness Generation"**

**Core Discovery**: In lossy plasmonic environments, spontaneous-emission acceleration ($F_P$) and private quantum information preservation ($R_{\rm priv}$) are competing physical processes ($F_P \uparrow \;\not\Rightarrow\; R_{\rm priv} \uparrow$). Uncollected polaritonic and Ohmic losses act as an environmental side channel that leaks which-path information. We establish an exact closed-form relation within a coarse-grained open-system channel model:
$$H_{\min}(X|E) = \log_2\left[\frac{2(1+\Xi)}{2+\Xi}\right] \equiv \Phi(\Xi), \qquad \Xi \equiv \frac{\Gamma_{\rm rad}}{\Gamma_{\rm pl} + \Gamma_{\rm nr}}$$

Due to near-field Ohmic quenching ($\Xi \to 0$), the private randomness throughput exhibits a non-monotonic trajectory with an interior local optimum:
- **Planar Gold**: Peaks at $d^* \approx 33.8$\,nm ($F_P^* \approx 3.96$, $R_{\rm priv}^{(\rm ch),\max} \approx 0.200$\,Mbps, dual-rail arm contribution $R_{\rm priv}^{(\rm arm),\max} \approx 0.100$\,Mbps).
- **Planar Silver**: Peaks at $d^* \approx 17.5$\,nm ($F_P^* \approx 3.37$, $R_{\rm priv}^{(\rm ch),\max} \approx 0.459$\,Mbps, dual-rail arm contribution $R_{\rm priv}^{(\rm arm),\max} \approx 0.229$\,Mbps).
- **Extreme Near-Field ($d = 5$\,nm)**: Despite massive Purcell enhancement ($F_P = 82.40$), throughput collapses to $\sim 1.0$\,kbps (arm contribution $\sim 0.50$\,kbps).

---

### Repository Structure

```
.
├── 11_SPRINGER_PLASMONICS_SUBMISSION/ # Complete Springer Plasmonics Package
│   ├── manuscript/                    # Main manuscript LaTeX source & compiled PDF
│   ├── supplementary/                 # Supplementary Information source & compiled PDF
│   ├── cover_letter/                  # Cover Letter to Editor-in-Chief
│   ├── figures/                       # Vector figures for submission
│   └── deliverables/                  # Gap matrix, novelty statements, QA checklists
├── 03_CODE/                           # Physics simulation engines (Python)
│   ├── green_tensor_planar.py         # Dyadic Green-tensor integration (Sommerfeld)
│   ├── reservoir_model.py             # Open-system quantum channel & min-entropy
│   ├── waveguide_feem.py              # FEEM mode solver for DLSPPW
│   ├── cross_solver_validation.py     # Cross-solver validation (Sommerfeld/FDTD/BEM)
│   └── generate_all_data.py           # Master data pipeline
├── 04_SIMULATIONS/                    # Multi-solver input files (Python, FDTD, BEM, FEEM)
├── 05_FIGURES/                        # High-resolution publication figures (vector PDF, SVG, PNG)
├── 06_DATA/                           # Numerical decay datasets, parameter sweeps, and raw outputs
├── 07_REFERENCES/                     # Verified reference database (BibTeX, DOI audit, claim matrix)
├── 08_GITHUB/                         # GitHub workflows, issue templates, and license
├── 09_QA/                             # Verification logs, convergence audits, and referee responses
├── scripts/                           # Reproducibility scripts for all tables and figures
├── tables/                            # LaTeX and CSV numerical tables
└── theory/                            # Formal quantum information derivations and notes
```

---

### Quick Start & Reproducibility

#### Dependencies
```bash
pip install numpy scipy matplotlib pandas openpyxl
```

#### Reproduce Simulation Data & Figures
```bash
# Generate all electrodynamic decay rates and information-theoretic metrics
cd 03_CODE
python generate_all_data.py

# Re-render all publication figures
cd ../scripts
python generate_all_figures.py
```

#### Compile Manuscript & Supplementary Information
```bash
cd 11_SPRINGER_PLASMONICS_SUBMISSION/manuscript
pdflatex manuscript.tex
bibtex manuscript
pdflatex manuscript.tex
pdflatex manuscript.tex

cd ../supplementary
pdflatex supplementary_information.tex
bibtex supplementary_information
pdflatex supplementary_information.tex
pdflatex supplementary_information.tex
```

---

### License
Released under the [MIT License](LICENSE). Code is freely reusable with attribution.
Manuscript and Supplementary Information text © 2026 Priyanka and Ram Soorat.
